import os, json, re, zipfile, xml.etree.ElementTree as ET

def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml_content = z.read("word/document.xml")
            tree = ET.fromstring(xml_content)
            paras = []
            for p in tree.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
                texts = [node.text for node in p.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t") if node.text]
                if texts:
                    t = "".join(texts).strip()
                    if t:
                        paras.append(t)
            return paras
    except Exception as e:
        return []

text_dir = "/tmp/nasr_repo/متن"

with open(os.path.join(text_dir, "متن-ویرایش-شده-سخنرانی-ایمان-به-غیب.txt"), "r", encoding="utf-8") as f:
    s1_text = f.read()

with open(os.path.join(text_dir, "متن-ویرایش-شده-سخنرانی-جلسه-دوم نسخه دوم.txt"), "r", encoding="utf-8") as f:
    s2_text = f.read()

freq_paras = extract_docx(os.path.join(text_dir, "00-«قانون فرکانس».docx"))
bavars_paras = extract_docx(os.path.join(text_dir, "01-3 باور.docx"))
hamd_paras = extract_docx(os.path.join(text_dir, "1-باورها و عمل هاي سوره حمد را بررسي ميكنيم.docx"))
eraz_paras = extract_docx(os.path.join(text_dir, "جدید 2/مفهوم آیه های «اعراض» در قرآن.docx"))
khasteh_paras = extract_docx(os.path.join(text_dir, "جدید 1/خواسته داشتن.docx"))
words_paras = extract_docx(os.path.join(text_dir, "جدید 1/معنی کلمات.docx"))
hadaf_paras = extract_docx(os.path.join(text_dir, "هدف.docx"))
tozihat_paras = extract_docx(os.path.join(text_dir, "03-توضیحات.docx"))
shokr_paras = extract_docx(os.path.join(text_dir, "جدید 3/همه شكر و سپاس ها مخصوص خداست.docx"))

# Clean up s1 and s2 into sections
def parse_transcript_sections(txt):
    lines = txt.split("\n")
    sections = []
    current_title = "مقدمه"
    current_body = []
    for line in lines:
        line_s = line.strip()
        if line_s.startswith("■") or line_s.startswith("بخش") or line_s.startswith("فصل"):
            if current_body:
                sections.append({"title": current_title, "text": "\n".join(current_body)})
                current_body = []
            current_title = line_s.replace("■", "").strip()
        elif line_s:
            # clean timestamp brackets for reading if desired, but keep text natural
            cleaned = re.sub(r"^\[\d{2}:\d{2}\]\s*", "", line_s)
            if cleaned and not cleaned.startswith("=======") and not cleaned.startswith("-------"):
                current_body.append(cleaned)
    if current_body:
        sections.append({"title": current_title, "text": "\n".join(current_body)})
    return sections

s1_sections = parse_transcript_sections(s1_text)
s2_sections = parse_transcript_sections(s2_text)

print(f"Parsed {len(s1_sections)} sections from Session 1, {len(s2_sections)} sections from Session 2.")
