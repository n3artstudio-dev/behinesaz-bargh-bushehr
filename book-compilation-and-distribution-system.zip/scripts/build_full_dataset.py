import os, json, re, zipfile, xml.etree.ElementTree as ET

def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml_content = z.read("word/document.xml")
            tree = ET.fromstring(xml_content)
            paras = []
            for p in tree.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
                texts = [node.text for node in p.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t") if node.text]
                if texts:
                    t = "".join(texts).strip()
                    if t:
                        paras.append(t)
            return paras
    except Exception as e:
        return []

text_dir = "/tmp/nasr_repo/متن"

with open(os.path.join(text_dir, "متن-ویرایش-شده-سخنرانی-ایمان-به-غیب.txt"), "r", encoding="utf-8") as f:
    s1_text = f.read()

with open(os.path.join(text_dir, "متن-ویرایش-شده-سخنرانی-جلسه-دوم نسخه دوم.txt"), "r", encoding="utf-8") as f:
    s2_text = f.read()

freq_paras = extract_docx(os.path.join(text_dir, "00-«قانون فرکانس».docx"))
bavars_paras = extract_docx(os.path.join(text_dir, "01-3 باور.docx"))
hamd_paras = extract_docx(os.path.join(text_dir, "1-باورها و عمل هاي سوره حمد را بررسي ميكنيم.docx"))
eraz_paras = extract_docx(os.path.join(text_dir, "جدید 2/مفهوم آیه های «اعراض» در قرآن.docx"))
khasteh_paras = extract_docx(os.path.join(text_dir, "جدید 1/خواسته داشتن.docx"))
words_paras = extract_docx(os.path.join(text_dir, "جدید 1/معنی کلمات.docx"))
hadaf_paras = extract_docx(os.path.join(text_dir, "هدف.docx"))
tozihat_paras = extract_docx(os.path.join(text_dir, "03-توضیحات.docx"))
shokr_paras = extract_docx(os.path.join(text_dir, "جدید 3/همه شكر و سپاس ها مخصوص خداست.docx"))

# Clean transcript lines into clean paragraphs
def clean_transcript(raw):
    paras = []
    lines = raw.split("\n")
    cur = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("===") or line.startswith("---"):
            if cur:
                paras.append(" ".join(cur))
                cur = []
            continue
        if line.startswith("■") or line.startswith("بخش") or line.startswith("موضوع") or line.startswith("فایل"):
            if cur:
                paras.append(" ".join(cur))
                cur = []
            cleaned_title = line.replace("■", "").strip()
            paras.append(f"### {cleaned_title}")
            continue
        cleaned = re.sub(r"^\[\d{2}:\d{2}\]\s*", "", line).strip()
        if cleaned:
            cur.append(cleaned)
    if cur:
        paras.append(" ".join(cur))
    return paras

s1_clean = clean_transcript(s1_text)
s2_clean = clean_transcript(s2_text)

# We will create 100 pages carefully assigned to each chapter!
chapters_config = [
    {
        "id": 0,
        "title": "مقدمات و شناسنامه",
        "startPage": 1,
        "endPage": 4,
        "description": "شناسنامه، فیپا، یادداشت ویراستار و فهرست اجمالی ۱۰۰ صفحه‌ای کتاب"
    },
    {
        "id": 0.5,
        "title": "پیشگفتار استاد حاج نصرالله باستین",
        "startPage": 5,
        "endPage": 8,
        "description": "بیداری از وهم شانس و تصادف؛ کشف نظام قانونمند نور و آفرینش"
    },
    {
        "id": 1,
        "title": "فصل اول: قانون بنیادین فرکانس و مدارها در جهان هستی",
        "startPage": 9,
        "endPage": 16,
        "description": "امواج فکر، ورودی‌های ذهن، گفتگوهای درونی و مسئولیت صددرصدی سرنوشت"
    },
    {
        "id": 2,
        "title": "فصل دوم: ایمان به غیب و دو ساحت فیزیک و متافیزیک عالم",
        "startPage": 17,
        "endPage": 24,
        "description": "نیروهای نامرئی، ۲۶۰ داستان پیامبران، حقیقت انرژی و جهان نادیدنی"
    },
    {
        "id": 3,
        "title": "فصل سوم: کانون توجه، کنترل ذهن و قانون قرآنی «اعراض»",
        "startPage": 25,
        "endPage": 32,
        "description": "مهندسی کانون توجه، نادیده گرفتن ناخواسته‌ها و هدایت ذهن به سمت خیر مطلق"
    },
    {
        "id": 4,
        "title": "فصل چهارم: شرح و تدبر فرکانسی در سوره مبارکه حمد",
        "startPage": 33,
        "endPage": 42,
        "description": "حرکت از متافیزیک به فیزیک؛ تحلیل آیه به آیه ام القرآن از منظر باورها"
    },
    {
        "id": 5,
        "title": "فصل پنجم: مدارهای دوقلوی هستی؛ تحلیل سوره مبارکه لیل",
        "startPage": 43,
        "endPage": 50,
        "description": "تسهیل برای آسانی در برابر تسهیل برای دشواری؛ دو مسیر ناگزیر در هستی"
    },
    {
        "id": 6,
        "title": "فصل ششم: توحید ناب، باور به فراوانی و درمان ریشه‌ای شرک خفی",
        "startPage": 51,
        "endPage": 59,
        "description": "خداوند به مثابه تنها منبع، دستان غیبی پروردگار و نجات از تکیه بر انسان‌ها"
    },
    {
        "id": 7,
        "title": "فصل هفتم: مراتب سه‌گانه یقین در قرآن کریم",
        "startPage": 60,
        "endPage": 66,
        "description": "علم‌الیقین، عین‌الیقین و حق‌الیقین؛ تمثیل دود، آتش و سوختن در حقیقت"
    },
    {
        "id": 8,
        "title": "فصل هشتم: عزت‌نفس توحیدی و احساس لیاقت بی‌قیدوشرط",
        "startPage": 67,
        "endPage": 74,
        "description": "کرامت ذاتی انسان، رهایی از کمال‌گرایی فلج‌کننده و زدودن احساس گناه"
    },
    {
        "id": 9,
        "title": "فصل نهم: هنر رهایی، خواسته داشتن و عدم وابستگی به نتایج",
        "startPage": 75,
        "endPage": 82,
        "description": "چرا چسبیدن به خواسته مانع رسیدن است؟ تسلیم در مدار توکل و آرامش قلبی"
    },
    {
        "id": 10,
        "title": "فصل دهم: فرهنگ واژگان و ریشه‌شناسی مفاهیم قرآنی استاد",
        "startPage": 83,
        "endPage": 89,
        "description": "تحلیل واژگان کلیدی وحی: اثم، ذنب، صلات، انفاق، افتری، تاویل، شقاوت و ذکر"
    },
    {
        "id": 11,
        "title": "فصل یازدهم: پرسش‌ها، پاسخ‌ها و آزمون‌های تحلیلی کلاس‌های استاد",
        "startPage": 90,
        "endPage": 95,
        "description": "گزیده‌ای از مباحثات علمی شاگردان، پرسش‌های شبانه و تحلیل دلایل قرآنی"
    },
    {
        "id": 12,
        "title": "فصل دوازدهم: منشور باورهای دوازده‌گانه، نقشه راه روزانه و سخن پایانی",
        "startPage": 96,
        "endPage": 100,
        "description": "۱۲ اصل بنیادین دگرگونی فرکانس، برنامه گام‌به‌گام و مانیفست نشر بین‌المللی"
    }
]

print("Configured chapters:", len(chapters_config))
