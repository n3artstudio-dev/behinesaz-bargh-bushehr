import os, json, re, zipfile, xml.etree.ElementTree as ET

def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml_content = z.read("word/document.xml")
            tree = ET.fromstring(xml_content)
            paras = []
            for p in tree.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
                texts = [node.text for node in p.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t") if node.text]
                if texts:
                    t = "".join(texts).strip()
                    if t:
                        paras.append(t)
            return paras
    except Exception as e:
        return []

text_dir = "/tmp/nasr_repo/متن"

with open(os.path.join(text_dir, "متن-ویرایش-شده-سخنرانی-ایمان-به-غیب.txt"), "r", encoding="utf-8") as f:
    s1_text = f.read()

with open(os.path.join(text_dir, "متن-ویرایش-شده-سخنرانی-جلسه-دوم نسخه دوم.txt"), "r", encoding="utf-8") as f:
    s2_text = f.read()

freq_paras = extract_docx(os.path.join(text_dir, "00-«قانون فرکانس».docx"))
bavars_paras = extract_docx(os.path.join(text_dir, "01-3 باور.docx"))
hamd_paras = extract_docx(os.path.join(text_dir, "1-باورها و عمل هاي سوره حمد را بررسي ميكنيم.docx"))
eraz_paras = extract_docx(os.path.join(text_dir, "جدید 2/مفهوم آیه های «اعراض» در قرآن.docx"))
khasteh_paras = extract_docx(os.path.join(text_dir, "جدید 1/خواسته داشتن.docx"))
words_paras = extract_docx(os.path.join(text_dir, "جدید 1/معنی کلمات.docx"))
hadaf_paras = extract_docx(os.path.join(text_dir, "هدف.docx"))
tozihat_paras = extract_docx(os.path.join(text_dir, "03-توضیحات.docx"))
shokr_paras = extract_docx(os.path.join(text_dir, "جدید 3/همه شكر و سپاس ها مخصوص خداست.docx"))

# Clean transcript lines into clean paragraphs
def clean_transcript(raw):
    paras = []
    lines = raw.split("\n")
    cur = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("===") or line.startswith("---"):
            if cur:
                paras.append(" ".join(cur))
                cur = []
            continue
        if line.startswith("■") or line.startswith("بخش") or line.startswith("موضوع") or line.startswith("فایل"):
            if cur:
                paras.append(" ".join(cur))
                cur = []
            cleaned_title = line.replace("■", "").strip()
            paras.append(f"### {cleaned_title}")
            continue
        cleaned = re.sub(r"^\[\d{2}:\d{2}\]\s*", "", line).strip()
        if cleaned:
            cur.append(cleaned)
    if cur:
        paras.append(" ".join(cur))
    return paras

s1_clean = clean_transcript(s1_text)
s2_clean = clean_transcript(s2_text)

print(f"s1_clean paras: {len(s1_clean)}, s2_clean paras: {len(s2_clean)}")
print(f"freq_paras: {len(freq_paras)}, bavars_paras: {len(bavars_paras)}")
