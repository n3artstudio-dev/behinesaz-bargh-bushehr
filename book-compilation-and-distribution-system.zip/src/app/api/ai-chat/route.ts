import { BOOK_PAGES } from "@/data/bookData";
import { QURANIC_LEXICON } from "@/data/lexiconData";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const { query } = await req.json();

    if (!query || typeof query !== "string") {
      return NextResponse.json(
        { ok: false, error: "متن پرسش الزامی است." },
        { status: 400 }
      );
    }

    const cleanQuery = query.trim().toLowerCase();

    // Semantic search across the 100 book pages
    const matches = BOOK_PAGES.map((page) => {
      let score = 0;
      const textToSearch = (
        page.pageTitle +
        " " +
        page.sectionTitle +
        " " +
        page.chapterTitle +
        " " +
        page.paragraphs.join(" ") +
        " " +
        page.takeaways.join(" ")
      ).toLowerCase();

      // Check keywords
      const terms = cleanQuery.split(/\s+/).filter((t: string) => t.length > 1);
      for (const term of terms) {
        if (textToSearch.includes(term)) {
          score += 2;
        }
      }

      if (cleanQuery.includes("فرکانس") && textToSearch.includes("فرکانس")) score += 3;
      if (cleanQuery.includes("حمد") && textToSearch.includes("حمد")) score += 4;
      if (cleanQuery.includes("لیل") && textToSearch.includes("لیل")) score += 4;
      if (cleanQuery.includes("غیب") && textToSearch.includes("غیب")) score += 3;
      if (cleanQuery.includes("اعراض") && textToSearch.includes("اعراض")) score += 4;
      if (cleanQuery.includes("شرک") && textToSearch.includes("شرک")) score += 3;
      if (cleanQuery.includes("یقین") && textToSearch.includes("یقین")) score += 4;
      if (cleanQuery.includes("خواسته") && textToSearch.includes("خواسته")) score += 3;
      if (cleanQuery.includes("شکر") && textToSearch.includes("شکر")) score += 3;
      if (cleanQuery.includes("دستان خدا") && textToSearch.includes("دستان خدا")) score += 5;
      if (cleanQuery.includes("نوح") && textToSearch.includes("نوح")) score += 5;
      if (cleanQuery.includes("یوسف") && textToSearch.includes("یوسف")) score += 5;

      return { page, score };
    })
      .filter((m) => m.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    // Also check lexicon
    const matchedLexicon = QURANIC_LEXICON.filter(
      (item) =>
        cleanQuery.includes(item.word) ||
        cleanQuery.includes(item.root) ||
        item.summary.includes(cleanQuery)
    );

    let answerText = "";
    let primaryPage = matches[0]?.page || BOOK_PAGES[8]; // default page 9 (Ch 1)

    if (cleanQuery.includes("فرکانس") || cleanQuery.includes("امواج")) {
      answerText = `سلام و درود بر شما رهروی جویای حقیقت. 
بر اساس بیانات و جهان‌بینی استاد حاج نصرالله باستین، «قانون فرکانس» اساسی‌ترین و بنیادین‌ترین قانون جهان هستی است که زیربنای تمام اتفاقات، شرایط و تجربیات زندگی بشر را تشکیل می‌دهد. ما در هر لحظه درست مانند یک دستگاه فرستنده امواج، در حال ارسال فرکانس‌هایی به جهان هستی هستیم. جنس این فرکانس‌ها را ورودی‌های ذهن (دیده‌ها، شنیده‌ها) و گفتگوهای درونی ما تعیین می‌کنند. 
جهان واکنشی به کلمات ظاهری نشان نمی‌دهد، بلکه به احساس و ارتعاش غالب شما پاسخ عینی می‌دهد. وقتی با «الحمدلله» و باور فراوانی فرکانستان را ارتقا دهید، در مدار برکت مستقر می‌شوید.`;
    } else if (cleanQuery.includes("اعراض") || cleanQuery.includes("توجه") || cleanQuery.includes("تمرکز")) {
      answerText = `استاد باستین «قانون اعراض» را الگوی بلامنازع در جهت‌دهی آگاهانه به کانون توجه معرفی می‌کنند.
اعراض یعنی روی برگرداندن هوشیارانه از چیزهایی که شما را مضطرب یا ناامید می‌سازند (مانند اخبار جنگ، شایعات گرانی، یا خطاهای دیگران). در قرآن می‌فرماید: «فَأَعْرِضْ عَنْهُمْ وَتَوَكَّلْ عَلَى اللَّهِ». 
شما نباید با تاریکی بجنگید؛ جنگیدن با تاریکی یعنی غرق شدن در همان مدار! فقط کافی است چراغ شکر و توجه به نعمات را روشن کنید تا ناخواسته‌ها خودبه‌خود محو گردند.`;
    } else if (cleanQuery.includes("حمد") || cleanQuery.includes("سوره حمد")) {
      answerText = `سوره مبارکه حمد در تحلیل فرکانسی استاد باستین، نقشه سفر از متافیزیک و غیب به ساحت فیزیک و ماده است.
با «بسم الله الرحمن الرحیم» به منبع فراوانی وصل می‌شویم؛ با «الحمدلله رب العالمین» شکرگزاری خالصانه و نفی شرک را در ذهن مستقر می‌کنیم؛ با «الرحمن الرحیم» ترسمان از ربوبیت محو می‌شود؛ با «مالک یوم الدین» از چسبیدن به دنیا رها می‌شویم؛ در «ایاک نعبد و ایاک نستعین» بندگی و یاری‌خواهی را انحصاراً از او می‌دانیم؛ با «اهدنا الصراط المستقیم» درخواست کوتاه‌ترین مدار هدایت غیبی را داریم و در نهایت در «صراط الذین انعمت علیهم» به تجلی فیزیکی نعمات در زندگی دست می‌یابیم.`;
    } else if (cleanQuery.includes("لیل") || cleanQuery.includes("سوره لیل") || cleanQuery.includes("مدار آسانی")) {
      answerText = `در سوره مبارکه لیل، استاد به زیبایی قانون دو مدار متضاد جهان را تشریح می‌کنند:
۱. مدار یسری (آسانی): با فرمول «فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ وَصَدَّقَ بِالْحُسْنَىٰ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ». هر کس بخشش کند، ذهنش را از نجواهای شیطان کنترل کند (تقوا) و به نیکویی نهایی خداوند حسن ظن داشته باشد، وجودش برای دریافت آسانی‌ها روان و مجهز می‌شود.
۲. مدار عسرت: با فرمول «وَأَمَّا مَن بَخِلَ وَاسْتَغْنَىٰ وَكَذَّبَ بِالْحُسْنَىٰ فَسَنُيَسِّرُهُ لِلْعُسْرَىٰ». کسی که از سر ترس کمبود بخل بورزد و خود را بی‌نیاز از خدا بداند، کائنات او را در شیب تند سختی‌ها و بن‌بست‌ها هدایت خواهد کرد.`;
    } else if (cleanQuery.includes("شرک") || cleanQuery.includes("یوسف") || cleanQuery.includes("دستان خدا")) {
      answerText = `شرک خفی یعنی برای انسان‌ها، موقعیت‌ها یا حساب بانکی در قلبتان قدرتی مستقل از خدا قائل شوید.
همان‌طور که استاد در ماجرای حضرت یوسف(ع) توضیح می‌دهند، یوسف به ساقی گفت «اذکرنی عند ربک» (مرا نزد فرعونت یاد کن)، و به خاطر همین تکیه کلامی به غیر خدا سال‌ها در زندان ماندگار شد. 
انسان‌ها تنها «دستان خدا» هستند؛ ما باید از واسطه‌ها سپاسگزار باشیم، اما قلب و توکلمان را فقط به منبع لایزال ببندیم. به محض اینکه از انسان‌ها قطع امید کنید و به سوی خدا فرار کنید («فَفِرُّوا إِلَى اللَّهِ»)، درهای رحمت گشوده خواهد شد.`;
    } else if (cleanQuery.includes("یقین") || cleanQuery.includes("مراتب")) {
      answerText = `مراتب سه‌گانه یقین در قرآن بر اساس تمثیل زیبای استاد باستین:
۱. علم‌الیقین: دیدن دود از فاصله دور؛ استدلال عقلی بر وجود آتش.
۲. عین‌الیقین: دیدن شعله‌های درخشان آتش از نزدیک با چشم سر و تجربه نشانه‌های عینی در زندگی.
۳. حق‌الیقین: لمس مستقیم حرارت و ورود به درون آتش؛ یکی شدن با قانون توحید و رسیدن به آرامش ابدی که بالاترین مرتبه است.
راه رسیدن از علم‌الیقین به عین‌الیقین، «تکرار پیوسته آموزه‌ها و ثبت نشانه‌های روزانه» است.`;
    } else if (cleanQuery.includes("خواسته") || cleanQuery.includes("رهایی") || cleanQuery.includes("چسبیدن")) {
      answerText = `استاد در رساله «خواسته داشتن» جمله‌ای طلایی دارند: «قرار نیست برای رسیدن به نعمت‌های خداوند خودتان را تکه‌پاره کنید؛ باید در مدار دریافت آنها قرار بگیرید!».
خواسته داشتن عالی است، اما مقاومت از جایی آغاز می‌شود که خوشبختی‌تان را به رسیدن به آن خواسته گره بزنید. وقتی به خواسته‌ای بچسبید، ترس از نرسیدن آن در ذهنتان امواج کمبود ساطع می‌کند. آرام شوید، به خدا توکل کنید، و با نرسیدن به صلح برسید؛ دقیقاً در لحظه‌ای که رها می‌کنید، درهای تجلی باز می‌شوند.`;
    } else {
      // General synthesis from the top matching pages
      const p = matches[0]?.page || BOOK_PAGES[4];
      answerText = `سلام و درود بر شما دوست عزیز.
در منظومه فکری و تدریس‌های استاد حاج نصرالله باستین در زمینه موضوع «${query}»:
${p.paragraphs.slice(0, 2).join("\n\n")}

کلید رهایی در این است که بدانیم خداوند این جهان را با سیستم تغییرناپذیر، ریاضی‌وار و بر پایه رحمت بی‌انتها آفریده است. با هدایت کانون توجه، اجرای فریضه اعراض از ناخواسته‌ها، و شکرگزاری قلبی، فرکانس شما به مدار فراوانی ارتقا خواهد یافت.`;
    }

    return NextResponse.json({
      ok: true,
      answer: answerText,
      referencedPage: {
        pageNumber: primaryPage.pageNumber,
        chapterTitle: primaryPage.chapterTitle,
        pageTitle: primaryPage.pageTitle,
      },
      lexiconMatches: matchedLexicon,
      matchedPages: matches.map((m) => ({
        pageNumber: m.page.pageNumber,
        chapterTitle: m.page.chapterTitle,
        pageTitle: m.page.pageTitle,
      })),
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "AI service error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
