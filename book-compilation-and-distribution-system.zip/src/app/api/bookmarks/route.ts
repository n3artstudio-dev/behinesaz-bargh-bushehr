import { db } from "@/db";
import { readingBookmarks } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const bookmarks = await db
      .select()
      .from(readingBookmarks)
      .orderBy(desc(readingBookmarks.createdAt))
      .limit(50);
    return NextResponse.json({ ok: true, data: bookmarks });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Bookmark error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { pageNumber, chapterId, title, note } = body;

    if (!pageNumber || !title) {
      return NextResponse.json(
        { ok: false, error: "شماره صفحه و عنوان الزامی است." },
        { status: 400 }
      );
    }

    const [saved] = await db
      .insert(readingBookmarks)
      .values({
        pageNumber: Number(pageNumber),
        chapterId: Number(chapterId || 0),
        title,
        note: note || "",
      })
      .returning();

    return NextResponse.json({ ok: true, data: saved });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to bookmark";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ ok: false, error: "شناسه الزامی است." }, { status: 400 });
    }
    await db.delete(readingBookmarks).where(eq(readingBookmarks.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to delete";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
