import { db } from "@/db";
import { journalEntries } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const list = await db
      .select()
      .from(journalEntries)
      .orderBy(desc(journalEntries.createdAt))
      .limit(50);
    return NextResponse.json({ ok: true, data: list });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Database query failed";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { title, content, frequencyFocus, gratitudeItems, moodRating } = body;

    if (!title || !content || !frequencyFocus) {
      return NextResponse.json(
        { ok: false, error: "فیلدهای عنوان، متن و کانون فرکانس الزامی است." },
        { status: 400 }
      );
    }

    const [newEntry] = await db
      .insert(journalEntries)
      .values({
        title,
        content,
        frequencyFocus,
        gratitudeItems: Array.isArray(gratitudeItems) ? gratitudeItems : [],
        moodRating: typeof moodRating === "number" ? moodRating : 5,
      })
      .returning();

    return NextResponse.json({ ok: true, data: newEntry });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Failed to save journal";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
