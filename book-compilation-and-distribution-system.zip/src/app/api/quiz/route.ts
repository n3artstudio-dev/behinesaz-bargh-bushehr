import { db } from "@/db";
import { quizSubmissions } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const submissions = await db
      .select()
      .from(quizSubmissions)
      .orderBy(desc(quizSubmissions.createdAt))
      .limit(30);

    return NextResponse.json({ ok: true, data: submissions });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Database error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { userName, sessionName, score, totalQuestions, userAnswers } = body;

    if (!userName || score === undefined || !totalQuestions) {
      return NextResponse.json(
        { ok: false, error: "نام، امتیاز و تعداد سوالات الزامی است." },
        { status: 400 }
      );
    }

    const [saved] = await db
      .insert(quizSubmissions)
      .values({
        userName,
        sessionName: sessionName || "آزمون کلاسی",
        score: Number(score),
        totalQuestions: Number(totalQuestions),
        userAnswers: userAnswers || {},
      })
      .returning();

    return NextResponse.json({ ok: true, data: saved });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Submission error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
