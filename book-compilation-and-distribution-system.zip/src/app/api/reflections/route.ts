import { db } from "@/db";
import { communityReflections } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const list = await db
      .select()
      .from(communityReflections)
      .orderBy(desc(communityReflections.createdAt))
      .limit(50);
    return NextResponse.json({ ok: true, data: list });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Database error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { authorName, countryOrCity, message, favoriteQuote } = body;

    if (!authorName || !message) {
      return NextResponse.json(
        { ok: false, error: "نام و پیام الزامی است." },
        { status: 400 }
      );
    }

    const [saved] = await db
      .insert(communityReflections)
      .values({
        authorName,
        countryOrCity: countryOrCity || "جهانی",
        message,
        favoriteQuote: favoriteQuote || "",
      })
      .returning();

    return NextResponse.json({ ok: true, data: saved });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Submission error";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
