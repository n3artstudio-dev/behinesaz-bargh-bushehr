import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "پلتفرم جامع آثار استاد حاج نصرالله باستین | کتاب ۱۰۰ صفحه‌ای مدار فرکانسی جهان",
  description:
    "سامانه بین‌المللی نشر آثار، تدریس‌ها، صوت‌ها و کتاب جامع ۱۰۰ صفحه‌ای مدار فرکانسی جهان بر پایه آموزه‌ها و بیانات ثبت‌شده استاد حاج نصرالله باستین.",
  keywords: [
    "استاد حاج نصرالله باستین",
    "مدار فرکانسی جهان",
    "کتاب ۱۰۰ صفحه‌ای",
    "ایمان به غیب",
    "سوره حمد",
    "سوره لیل",
    "قانون فرکانس",
    "قانون اعراض",
    "توحید قرآنی",
  ],
  authors: [{ name: "استاد حاج نصرالله باستین" }],
  openGraph: {
    title: "کتاب جامع مدار فرکانسی جهان | استاد حاج نصرالله باستین",
    description: "تنظیم نظام‌مند جلسات صوتی و تدبرهای قرآنی استاد حاج نصرالله باستین در قالب کتاب ۱۰۰ صفحه‌ای مستند و قابل چاپ.",
    type: "website",
    locale: "fa_IR",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&family=Amiri:ital,wght@0,400;0,700;1,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased selection:bg-amber-500 selection:text-black">
        {children}
      </body>
    </html>
  );
}
