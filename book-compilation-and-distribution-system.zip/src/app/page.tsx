"use client";

import React, { useState } from "react";
import { Navbar, ActiveTab, ReadingTheme } from "@/components/Navbar";
import { HeroBanner } from "@/components/HeroBanner";
import { BookReader } from "@/components/BookReader";
import { PrintableBook } from "@/components/PrintableBook";
import { AudioPlayerSection } from "@/components/AudioPlayerSection";
import { AiCompanionSection } from "@/components/AiCompanionSection";
import { QuizSection } from "@/components/QuizSection";
import { LexiconSection } from "@/components/LexiconSection";
import { JournalSection } from "@/components/JournalSection";
import { CommunitySection } from "@/components/CommunitySection";
import { WisdomQuotesSection } from "@/components/WisdomQuotesSection";
import { GlobalReachModal } from "@/components/GlobalReachModal";
import { BOOK_META } from "@/data/bookData";
import { AUDIO_TRACKS } from "@/data/audioData";
import { BookOpen, Headphones, ShieldCheck, Heart, Sparkles } from "lucide-react";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("book");
  const [readingTheme, setReadingTheme] = useState<ReadingTheme>("dark");
  const [targetBookPage, setTargetBookPage] = useState<number>(1);
  const [isGlobalModalOpen, setIsGlobalModalOpen] = useState(false);
  const [selectedAudioTrackId, setSelectedAudioTrackId] = useState<string>("p1");

  // Handler to jump to book page from audio, AI, or TOC
  const handleGoToBookPage = (pageNum: number) => {
    setTargetBookPage(pageNum);
    setActiveTab("book");
    window.scrollTo({ top: 400, behavior: "smooth" });
  };

  // Handler to play audio for a specific book page
  const handlePlayAudioForPage = (audioRef: string, pageNum: number) => {
    const matchedTrack = AUDIO_TRACKS.find(
      (t) =>
        t.id === audioRef.replace(".mp3", "") ||
        t.title.includes(audioRef) ||
        t.audioUrl.includes(audioRef)
    );
    if (matchedTrack) {
      setSelectedAudioTrackId(matchedTrack.id);
    }
    setActiveTab("audio");
    window.scrollTo({ top: 300, behavior: "smooth" });
  };

  // If print mode is active, render the dedicated PrintableBook component
  if (activeTab === "print") {
    return <PrintableBook onBackToReader={() => setActiveTab("book")} />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      readingTheme === "dark"
        ? "bg-slate-950 text-slate-100"
        : readingTheme === "sepia"
        ? "bg-[#f8f1e3] text-[#2d2214]"
        : "bg-slate-100 text-slate-900"
    }`}>
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        readingTheme={readingTheme}
        setReadingTheme={setReadingTheme}
        onOpenPrint={() => setActiveTab("print")}
        onOpenGlobal={() => setIsGlobalModalOpen(true)}
        activeAudioTitle="جلسه اول: ایمان به غیب"
      />

      {/* Hero Section */}
      <HeroBanner
        setActiveTab={setActiveTab}
        onOpenPrint={() => setActiveTab("print")}
      />

      {/* Main Content Area Based on Active Tab */}
      <main className="pb-24">
        {activeTab === "book" && (
          <section className="py-6">
            <BookReader
              readingTheme={readingTheme}
              initialPage={targetBookPage}
              onPlayAudioForPage={handlePlayAudioForPage}
              onOpenPrintAll={() => setActiveTab("print")}
            />
          </section>
        )}

        {activeTab === "audio" && (
          <section className="py-6">
            <AudioPlayerSection
              onGoToBookPage={handleGoToBookPage}
              externalActiveTrackId={selectedAudioTrackId}
            />
          </section>
        )}

        {activeTab === "ai" && (
          <section className="py-6">
            <AiCompanionSection onGoToBookPage={handleGoToBookPage} />
          </section>
        )}

        {activeTab === "quizzes" && (
          <section className="py-6">
            <QuizSection />
          </section>
        )}

        {activeTab === "lexicon" && (
          <section className="py-6">
            <LexiconSection />
          </section>
        )}

        {activeTab === "journal" && (
          <section className="py-6">
            <JournalSection />
          </section>
        )}

        {activeTab === "community" && (
          <section className="py-6">
            <CommunitySection />
          </section>
        )}

        {/* Global Wisdom Flashcards Section (shown on reader and home) */}
        {activeTab === "book" && (
          <div className="mt-12 border-t border-slate-800/80 pt-12">
            <WisdomQuotesSection />
          </div>
        )}
      </main>

      {/* Global Mission Modal */}
      <GlobalReachModal
        isOpen={isGlobalModalOpen}
        onClose={() => setIsGlobalModalOpen(false)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-12 px-4 text-xs text-slate-400 sm:px-6">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-amber-500" />
                <span className="font-black text-sm text-white">
                  {BOOK_META.title}
                </span>
              </div>
              <p className="leading-relaxed text-slate-400">
                تنظیم جامع کتاب ۱۰۰ صفحه‌ای مستند و قابل چاپ بر پایه متن‌ها و صوت‌های رسمی جلسات استاد حاج نصرالله باستین.
              </p>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-white block">روش تدوین و اصالت متن:</span>
              <p className="leading-relaxed text-slate-400 text-justify">
                «این کتاب تماماً از متن‌های ثبت‌شدهٔ جلسات استاد تنظیم شده و هیچ دخل و تصرفی در جهان‌بینی توحیدی ایشان صورت نگرفته است».
              </p>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-white block">دسترسی سریع به فصول:</span>
              <ul className="space-y-1 text-slate-400">
                <li
                  onClick={() => handleGoToBookPage(9)}
                  className="cursor-pointer hover:text-amber-400 transition"
                >
                  فصل ۱: قانون بنیادین فرکانس
                </li>
                <li
                  onClick={() => handleGoToBookPage(17)}
                  className="cursor-pointer hover:text-amber-400 transition"
                >
                  فصل ۲: ایمان به غیب و دو ساحت جهان
                </li>
                <li
                  onClick={() => handleGoToBookPage(33)}
                  className="cursor-pointer hover:text-amber-400 transition"
                >
                  فصل ۴: تحلیل فرکانسی سوره حمد
                </li>
                <li
                  onClick={() => handleGoToBookPage(43)}
                  className="cursor-pointer hover:text-amber-400 transition"
                >
                  فصل ۵: مدارهای دوقلوی سوره لیل
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <span className="font-bold text-white block">رسالت بین‌المللی:</span>
              <p className="text-slate-400 leading-relaxed">
                طراحی‌شده برای متفکران و جویندگان حقیقت در شرق و غرب گیتی. نسخه دیجیتال و باز برای تمام انسان‌ها.
              </p>
              <button
                onClick={() => setIsGlobalModalOpen(true)}
                className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-amber-400 font-bold hover:bg-slate-800 transition"
              >
                مانیفست جهانی (EN / AR / FA)
              </button>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-between border-t border-slate-800/80 pt-6 text-[11px] text-slate-500">
            <div>
              © ۱۴۰۴ / ۲۰۲۶ — کلیه حقوق معنوی متعلق به آموزه‌های توحیدی استاد حاج نصرالله باستین است.
            </div>
            <div className="flex items-center gap-1">
              <span>طراحی و استقرار پلتفرم جهانی جهت نشر آگاهی</span>
              <Heart className="h-3 w-3 text-red-500 fill-current" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
