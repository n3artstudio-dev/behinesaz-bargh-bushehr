"use client";

import React, { useState } from "react";
import { Bot, Send, Sparkles, BookOpen, HelpCircle, Loader2 } from "lucide-react";

interface AiCompanionSectionProps {
  onGoToBookPage: (pageNum: number) => void;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  referencedPage?: {
    pageNumber: number;
    chapterTitle: string;
    pageTitle: string;
  };
  matchedPages?: Array<{
    pageNumber: number;
    chapterTitle: string;
    pageTitle: string;
  }>;
}

export function AiCompanionSection({ onGoToBookPage }: AiCompanionSectionProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "سلام و درود بر شما رهروی حقیقت‌جو. من دستیار هوشمند دانشنامه استاد حاج نصرالله باستین هستم. هر پرسشی پیرامون قوانین فرکانسی، ایمان به غیب، کنترل کانون توجه، تدبر در سوره حمد و سوره لیل، یا رهایی از شرک خفی دارید بفرمایید تا با استناد مستقیم به صفحات کتاب ۱۰۰ صفحه‌ای استاد پاسخ دهم.",
      referencedPage: {
        pageNumber: 5,
        chapterTitle: "پیشگفتار استاد",
        pageTitle: "بیداری از وهم شانس و تصادف",
      },
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const presets = [
    "قانون فرکانس در سوره حمد چگونه تبیین شده است؟",
    "علت ضربه خوردن حضرت یوسف از برادرانش چه بود؟",
    "تفاوت مدار آسانی (یسری) و مدار سختی (عسری) در سوره لیل چیست؟",
    "قانون اعراض چیست و چگونه اجرا می‌شود؟",
    "چرا چسبیدن به خواسته مانع رسیدن به آن است؟",
    "مراتب سه‌گانه یقین (علم، عین، حق) را با مثال آتش توضیح دهید.",
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: "user", content: textToSend };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: textToSend }),
      });
      const data = await res.json();

      if (data.ok) {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: data.answer,
            referencedPage: data.referencedPage,
            matchedPages: data.matchedPages,
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "متأسفانه در پاسخ‌دهی خطایی رخ داد؛ لطفاً دوباره تلاش کنید.",
          },
        ]);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "خطا در برقراری ارتباط با سامانه هوشمند.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <Bot className="h-3.5 w-3.5 text-amber-400" />
          <span>هوش مصنوعی و دانشنامه تطبیقی استاد باستین</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          کاوشگر معرفت قرآنی و قوانین الهی
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          پاسخ فوری به پرسش‌های شما بر اساس متن کامل جلسات و کتاب ۱۰۰ صفحه‌ای
        </p>
      </div>

      {/* Preset Questions Chips */}
      <div className="mb-6">
        <div className="mb-2 text-xs font-bold text-slate-400">
          پرسش‌های متداول شاگردان (کلیک کنید):
        </div>
        <div className="flex flex-wrap gap-2">
          {presets.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              disabled={isLoading}
              className="rounded-xl border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs text-slate-300 transition hover:border-amber-500/50 hover:bg-slate-800 hover:text-amber-300 disabled:opacity-50 text-right"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="mb-4 min-h-[420px] max-h-[550px] space-y-4 overflow-y-auto rounded-3xl border border-slate-800 bg-slate-950/80 p-4 sm:p-6 shadow-inner">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex flex-col ${
              msg.role === "user" ? "items-start" : "items-end"
            }`}
          >
            <div
              className={`max-w-[90%] sm:max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-amber-500 text-slate-950 font-semibold shadow-md"
                  : "border border-slate-800 bg-slate-900 text-slate-200"
              }`}
            >
              {msg.role === "assistant" && (
                <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold text-amber-400 border-b border-slate-800 pb-1.5">
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>دیدگاه استاد حاج نصرالله باستین:</span>
                </div>
              )}
              <div className="whitespace-pre-line">{msg.content}</div>

              {/* Page Citation Reference */}
              {msg.referencedPage && (
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 pt-2 text-[11px]">
                  <span className="text-slate-400">
                    مرجع در کتاب:{" "}
                    <strong className="text-amber-300">
                      {msg.referencedPage.chapterTitle}
                    </strong>
                  </span>
                  <button
                    onClick={() => onGoToBookPage(msg.referencedPage!.pageNumber)}
                    className="flex items-center gap-1 rounded bg-amber-500/20 px-2 py-0.5 font-bold text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition"
                  >
                    <BookOpen className="h-3 w-3" />
                    <span>مطالعه صفحه {msg.referencedPage.pageNumber}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-end">
            <div className="flex items-center gap-2 rounded-2xl border border-slate-800 bg-slate-900 p-4 text-xs text-amber-400">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>در حال جستجو در کتاب ۱۰۰ صفحه‌ای و صوت‌های استاد...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="هر سوالی پیرامون فرکانس، آیات قرآن، یا زندگی روزمره دارید بنویسید..."
          disabled={isLoading}
          className="flex-1 rounded-2xl border border-slate-800 bg-slate-900/90 px-4 py-3 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 transition hover:bg-amber-400 disabled:opacity-40"
        >
          <Send className="h-5 w-5" />
        </button>
      </form>
    </div>
  );
}
