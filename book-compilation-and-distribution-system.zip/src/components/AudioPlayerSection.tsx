"use client";

import React, { useState, useRef, useEffect } from "react";
import { AUDIO_TRACKS, AudioTrack } from "@/data/audioData";
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  BookOpen,
  Headphones,
  Search,
  Sparkles,
  Clock,
  Radio,
} from "lucide-react";

interface AudioPlayerSectionProps {
  onGoToBookPage: (pageNum: number) => void;
  externalActiveTrackId?: string;
}

export function AudioPlayerSection({
  onGoToBookPage,
  externalActiveTrackId,
}: AudioPlayerSectionProps) {
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Sync external track if requested
  useEffect(() => {
    if (externalActiveTrackId) {
      const idx = AUDIO_TRACKS.findIndex((t) => t.id === externalActiveTrackId);
      if (idx !== -1 && idx !== currentTrackIndex) {
        setCurrentTrackIndex(idx);
        setIsPlaying(true);
      }
    }
  }, [externalActiveTrackId, currentTrackIndex]);

  const currentTrack: AudioTrack = AUDIO_TRACKS[currentTrackIndex] || AUDIO_TRACKS[0];

  // Categories
  const categories = ["all", "ایمان به غیب", "قانون فرکانس", "سوره حمد و توحید", "سوره لیل", "کنترل ذهن"];

  const filteredTracks = AUDIO_TRACKS.filter((t) => {
    const matchCat = selectedCategory === "all" || t.category.includes(selectedCategory);
    const matchSearch =
      !searchQuery.trim() ||
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  // Play / Pause toggle
  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleTrackChange = (index: number) => {
    setCurrentTrackIndex(index);
    setIsPlaying(true);
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      setTimeout(() => {
        audioRef.current?.play().catch(() => {});
      }, 50);
    }
  };

  const skipSeconds = (seconds: number) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = Math.max(
      0,
      Math.min(audioRef.current.currentTime + seconds, duration)
    );
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = Number(e.target.value);
    setCurrentTime(targetTime);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return "00:00";
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      {/* Hidden Native Audio Element */}
      <audio
        ref={audioRef}
        src={currentTrack.audioUrl}
        onTimeUpdate={() => {
          if (audioRef.current) setCurrentTime(audioRef.current.currentTime);
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) setDuration(audioRef.current.duration);
        }}
        onEnded={() => {
          if (currentTrackIndex < AUDIO_TRACKS.length - 1) {
            handleTrackChange(currentTrackIndex + 1);
          } else {
            setIsPlaying(false);
          }
        }}
      />

      {/* Hero Header */}
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <Radio className="h-3.5 w-3.5 text-amber-400 animate-pulse" />
          <span>آرشیو رسمی جلسات صوتی استاد حاج نصرالله باستین</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          صوت کامل سخنرانی‌ها و کلاس‌های قرآن
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          فایل‌های صوتی دست اول با امکان پرش به صفحه متناظر در کتاب ۱۰۰ صفحه‌ای
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-12">
        {/* Main Audio Player Card */}
        <div className="lg:col-span-7 space-y-6">
          <div className="relative overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 p-6 sm:p-8 shadow-2xl">
            {/* Ambient Background Glow */}
            <div className="pointer-events-none absolute -top-16 -right-16 h-64 w-64 rounded-full bg-amber-500/10 blur-3xl" />

            {/* Track Info */}
            <div className="relative z-10 flex items-start justify-between gap-4">
              <div>
                <span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-400">
                  {currentTrack.category}
                </span>
                <h3 className="mt-3 text-lg font-black text-white sm:text-xl">
                  {currentTrack.title}
                </h3>
                <p className="mt-1 text-xs text-slate-400 font-medium">
                  سخنران: {currentTrack.speaker} • مدت: {currentTrack.duration}
                </p>
              </div>

              <button
                onClick={() => onGoToBookPage(currentTrack.bookPage)}
                className="flex flex-shrink-0 items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs font-bold text-amber-300 transition hover:bg-amber-500 hover:text-slate-950"
                title="مشاهده متن این صوت در صفحه کتاب"
              >
                <BookOpen className="h-4 w-4" />
                <span>صفحه {currentTrack.bookPage} کتاب</span>
              </button>
            </div>

            <p className="mt-4 text-xs sm:text-sm leading-relaxed text-slate-300">
              {currentTrack.description}
            </p>

            {/* Waveform / Visualizer Bar */}
            <div className="my-6 flex items-center justify-between gap-1 h-10 px-2 rounded-xl bg-slate-950/60 border border-slate-800">
              {Array.from({ length: 36 }).map((_, i) => {
                const height = isPlaying
                  ? Math.sin((currentTime * 3 + i) * 0.4) * 14 + 18
                  : (i % 5) * 4 + 8;
                return (
                  <div
                    key={i}
                    className={`w-1 rounded-full transition-all duration-150 ${
                      i / 36 <= currentTime / (duration || 1)
                        ? "bg-amber-400"
                        : "bg-slate-700"
                    }`}
                    style={{ height: `${height}px` }}
                  />
                );
              })}
            </div>

            {/* Time & Progress Slider */}
            <div className="space-y-1.5">
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={currentTime}
                onChange={handleSeek}
                className="h-2 w-full cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-xs font-medium text-slate-400">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Main Player Buttons */}
            <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-slate-800/80 pt-6">
              {/* Skip Buttons */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => skipSeconds(-10)}
                  className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white"
                  title="۱۰ ثانیه به عقب"
                >
                  <RotateCcw className="h-5 w-5" />
                </button>

                {/* Big Play/Pause Button */}
                <button
                  onClick={togglePlay}
                  className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 shadow-xl shadow-amber-500/25 transition hover:scale-105"
                >
                  {isPlaying ? (
                    <Pause className="h-6 w-6 fill-current" />
                  ) : (
                    <Play className="h-6 w-6 fill-current translate-x-[-1px]" />
                  )}
                </button>

                <button
                  onClick={() => skipSeconds(10)}
                  className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white"
                  title="۱۰ ثانیه به جلو"
                >
                  <RotateCw className="h-5 w-5" />
                </button>
              </div>

              {/* Speed Controller */}
              <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-950 p-1 text-xs">
                {[0.75, 1, 1.25, 1.5].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => {
                      setPlaybackRate(rate);
                      if (audioRef.current) audioRef.current.playbackRate = rate;
                    }}
                    className={`rounded px-2 py-1 font-bold transition ${
                      playbackRate === rate
                        ? "bg-amber-500 text-slate-950"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>

              {/* Volume */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const nextMute = !isMuted;
                    setIsMuted(nextMute);
                    if (audioRef.current) audioRef.current.muted = nextMute;
                  }}
                  className="text-slate-400 hover:text-white"
                >
                  {isMuted ? (
                    <VolumeX className="h-4 w-4 text-red-400" />
                  ) : (
                    <Volume2 className="h-4 w-4" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    setVolume(v);
                    setIsMuted(false);
                    if (audioRef.current) {
                      audioRef.current.volume = v;
                      audioRef.current.muted = false;
                    }
                  }}
                  className="h-1.5 w-16 cursor-pointer accent-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Ostad's Session Note */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4 text-xs text-slate-300">
            <span className="font-bold text-amber-400">پیام استاد درباره شنیدن صوت‌ها:</span>
            <p className="mt-1 leading-relaxed text-slate-400">
              «تکرار، پاشنه آشیل ضمیر ناخودآگاه است. همان‌طور که روزها و ماه‌ها ورودی‌های نامناسب در ذهن رسوب کرده، با چندین بار شنیدن این صوت‌ها و تثبیت مدار کلام در گوش جان، سیم‌کشی مغز به سمت باور فراوانی و توحید تغییر می‌یابد».
            </p>
          </div>
        </div>

        {/* Playlist & Tracks List */}
        <div className="lg:col-span-5 space-y-4">
          {/* Filter & Search */}
          <div className="space-y-3 rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="relative">
              <Search className="absolute right-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="جستجو در نام یا مبحث جلسات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-8 w-full rounded-lg border border-slate-800 bg-slate-950 pr-8 pl-3 text-xs text-slate-200 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            {/* Category Pills */}
            <div className="flex flex-wrap gap-1.5">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setSelectedCategory(c)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold transition ${
                    selectedCategory === c
                      ? "bg-amber-500 text-slate-950 font-bold"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  {c === "all" ? "همه جلسات" : c}
                </button>
              ))}
            </div>
          </div>

          {/* Tracks List */}
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredTracks.map((track, i) => {
              const originalIndex = AUDIO_TRACKS.findIndex((t) => t.id === track.id);
              const isCurrent = originalIndex === currentTrackIndex;
              return (
                <div
                  key={track.id}
                  onClick={() => handleTrackChange(originalIndex)}
                  className={`cursor-pointer rounded-2xl border p-3.5 transition-all ${
                    isCurrent
                      ? "border-amber-500 bg-amber-500/10 shadow-md shadow-amber-500/10"
                      : "border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-3">
                      <div
                        className={`mt-0.5 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                          isCurrent
                            ? "bg-amber-500 text-slate-950"
                            : "bg-slate-800 text-slate-400"
                        }`}
                      >
                        {isCurrent && isPlaying ? (
                          <Radio className="h-4 w-4 animate-pulse" />
                        ) : (
                          i + 1
                        )}
                      </div>
                      <div>
                        <h4
                          className={`text-xs sm:text-sm font-bold ${
                            isCurrent ? "text-amber-400" : "text-white"
                          }`}
                        >
                          {track.title}
                        </h4>
                        <p className="mt-0.5 text-[11px] text-slate-400 line-clamp-1">
                          {track.description}
                        </p>
                      </div>
                    </div>

                    <div className="text-left flex-shrink-0">
                      <span className="block text-[11px] font-semibold text-slate-400">
                        {track.duration}
                      </span>
                      <span className="mt-1 block rounded bg-slate-800 px-1.5 py-0.5 text-[10px] text-amber-300">
                        ص {track.bookPage}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
