"use client";

import React, { useState, useMemo, useEffect } from "react";
import {
  BOOK_META,
  CHAPTERS_CONFIG,
  BOOK_PAGES,
  BookPage,
} from "@/data/bookData";
import { ReadingTheme } from "./Navbar";
import {
  ChevronRight,
  ChevronLeft,
  Bookmark,
  Share2,
  Search,
  BookOpen,
  Volume2,
  Printer,
  List,
  Sparkles,
  CheckCircle,
  Copy,
  Check,
  ZoomIn,
  ZoomOut,
  Maximize2,
} from "lucide-react";

interface BookReaderProps {
  readingTheme: ReadingTheme;
  onPlayAudioForPage?: (audioRef: string, pageNumber: number) => void;
  onOpenPrintAll: () => void;
  initialPage?: number;
}

export function BookReader({
  readingTheme,
  onPlayAudioForPage,
  onOpenPrintAll,
  initialPage = 1,
}: BookReaderProps) {
  const [currentPageNum, setCurrentPageNum] = useState<number>(initialPage);
  const [searchQuery, setSearchQuery] = useState("");
  const [showToc, setShowToc] = useState(false);
  const [fontSize, setFontSize] = useState<"sm" | "base" | "lg" | "xl">("base");
  const [copiedQuote, setCopiedQuote] = useState(false);
  const [bookmarkSaved, setBookmarkSaved] = useState(false);
  const [bookmarkNote, setBookmarkNote] = useState("");
  const [showBookmarkModal, setShowBookmarkModal] = useState(false);

  // Sync initialPage if updated from outside
  useEffect(() => {
    if (initialPage && initialPage >= 1 && initialPage <= 100) {
      setCurrentPageNum(initialPage);
    }
  }, [initialPage]);

  // Current page object
  const currentPage: BookPage = useMemo(() => {
    const found = BOOK_PAGES.find((p) => p.pageNumber === currentPageNum);
    return found || BOOK_PAGES[0];
  }, [currentPageNum]);

  // Search results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim() || searchQuery.length < 2) return [];
    const q = searchQuery.toLowerCase();
    return BOOK_PAGES.filter((p) => {
      const allText = (
        p.pageTitle +
        " " +
        p.sectionTitle +
        " " +
        p.chapterTitle +
        " " +
        p.paragraphs.join(" ") +
        " " +
        p.takeaways.join(" ")
      ).toLowerCase();
      return allText.includes(q);
    }).slice(0, 15);
  }, [searchQuery]);

  // Chapter navigation
  const goToNextPage = () => {
    if (currentPageNum < 100) setCurrentPageNum((p) => p + 1);
  };
  const goToPrevPage = () => {
    if (currentPageNum > 1) setCurrentPageNum((p) => p - 1);
  };

  // Save bookmark to API
  const handleSaveBookmark = async () => {
    try {
      await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pageNumber: currentPage.pageNumber,
          chapterId: Math.floor(currentPage.chapterId),
          title: currentPage.pageTitle,
          note: bookmarkNote,
        }),
      });
      setBookmarkSaved(true);
      setShowBookmarkModal(false);
      setTimeout(() => setBookmarkSaved(false), 3000);
    } catch {
      // Local fallback
      setBookmarkSaved(true);
      setShowBookmarkModal(false);
    }
  };

  const handleCopyPageText = () => {
    const textToCopy = `«${currentPage.pageTitle}»\nکتاب مدار فرکانسی جهان — استاد حاج نصرالله باستین (صفحه ${currentPage.pageNumber})\n\n${currentPage.paragraphs.join("\n\n")}`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedQuote(true);
    setTimeout(() => setCopiedQuote(false), 2000);
  };

  // Font size classes
  const fontClass = {
    sm: "text-sm sm:text-base leading-relaxed sm:leading-loose",
    base: "text-base sm:text-lg leading-relaxed sm:leading-loose",
    lg: "text-lg sm:text-xl leading-relaxed sm:leading-loose",
    xl: "text-xl sm:text-2xl leading-relaxed sm:leading-loose",
  }[fontSize];

  // Theme container classes
  const themeContainerClass = {
    dark: "bg-slate-900/90 text-slate-100 border-slate-800",
    light: "bg-white text-slate-900 border-slate-200 shadow-xl shadow-slate-200/50",
    sepia: "bg-[#fcf6e9] text-[#2c2214] border-[#ebdcc1] shadow-xl shadow-amber-900/5",
  }[readingTheme];

  const themeInnerCard = {
    dark: "bg-slate-950/60 border-slate-800/80 text-slate-200",
    light: "bg-amber-50/70 border-amber-200/60 text-slate-800",
    sepia: "bg-[#f4ebd6] border-[#dfceaf] text-[#3d2e1b]",
  }[readingTheme];

  return (
    <div className="relative mx-auto max-w-5xl px-4 py-6 sm:px-6">
      {/* Top Controller Bar */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-950/80 p-3 shadow-lg backdrop-blur">
        {/* TOC Toggle & Jump to Chapter */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowToc(!showToc)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 transition hover:border-amber-500/50 hover:text-amber-400"
          >
            <List className="h-4 w-4 text-amber-400" />
            <span>فهرست فصول ({CHAPTERS_CONFIG.length})</span>
          </button>

          {/* Direct Page Input */}
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <span>صفحه</span>
            <input
              type="number"
              min={1}
              max={100}
              value={currentPageNum}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                if (val >= 1 && val <= 100) setCurrentPageNum(val);
              }}
              className="h-7 w-14 rounded-md border border-slate-800 bg-slate-900 px-1 text-center font-bold text-amber-400 focus:border-amber-500 focus:outline-none"
            />
            <span>از ۱۰۰</span>
          </div>
        </div>

        {/* Quick Search */}
        <div className="relative flex-1 max-w-xs min-w-[160px]">
          <Search className="absolute right-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="جستجو در کل کتاب ۱۰۰ صفحه‌ای..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8 w-full rounded-lg border border-slate-800 bg-slate-900 pr-8 pl-3 text-xs text-slate-200 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute left-2.5 top-2 text-xs text-slate-400 hover:text-slate-200"
            >
              ✕
            </button>
          )}
        </div>

        {/* Font Size & Utilities */}
        <div className="flex items-center gap-1.5">
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900 p-0.5 text-xs">
            <button
              onClick={() =>
                setFontSize((prev) =>
                  prev === "xl" ? "lg" : prev === "lg" ? "base" : "sm"
                )
              }
              className="rounded px-2 py-1 text-slate-300 hover:bg-slate-800"
              title="کوچک‌تر"
            >
              <ZoomOut className="h-3 w-3" />
            </button>
            <span className="px-1 text-[11px] font-bold text-amber-400">
              قلم
            </span>
            <button
              onClick={() =>
                setFontSize((prev) =>
                  prev === "sm" ? "base" : prev === "base" ? "lg" : "xl"
                )
              }
              className="rounded px-2 py-1 text-slate-300 hover:bg-slate-800"
              title="بزرگ‌تر"
            >
              <ZoomIn className="h-3 w-3" />
            </button>
          </div>

          <button
            onClick={() => setShowBookmarkModal(true)}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 transition hover:text-amber-400"
            title="نشانه‌گذاری و یادداشت این صفحه"
          >
            <Bookmark
              className={`h-3.5 w-3.5 ${
                bookmarkSaved ? "fill-amber-400 text-amber-400" : ""
              }`}
            />
          </button>

          <button
            onClick={handleCopyPageText}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 transition hover:text-amber-400"
            title="کپی متن صفحه"
          >
            {copiedQuote ? (
              <Check className="h-3.5 w-3.5 text-emerald-400" />
            ) : (
              <Copy className="h-3.5 w-3.5" />
            )}
          </button>

          <button
            onClick={onOpenPrintAll}
            className="flex items-center gap-1 rounded-lg border border-amber-500/40 bg-amber-500/10 px-2.5 py-1.5 text-xs font-semibold text-amber-300 transition hover:bg-amber-500 hover:text-slate-950"
            title="نمای چاپ کامل ۱۰۰ صفحه‌ای"
          >
            <Printer className="h-3.5 w-3.5" />
            <span className="hidden md:inline">چاپ ۱۰۰ ص</span>
          </button>
        </div>
      </div>

      {/* Search Results Dropdown Overlay */}
      {searchResults.length > 0 && (
        <div className="mb-6 rounded-2xl border border-amber-500/30 bg-slate-900 p-4 shadow-2xl">
          <div className="mb-3 flex items-center justify-between text-xs font-bold text-amber-400">
            <span>یافته‌ها برای: «{searchQuery}» ({searchResults.length} صفحه)</span>
            <button
              onClick={() => setSearchQuery("")}
              className="text-slate-400 hover:text-white"
            >
              بستن
            </button>
          </div>
          <div className="grid max-h-72 gap-2 overflow-y-auto pr-1">
            {searchResults.map((res) => (
              <div
                key={res.pageNumber}
                onClick={() => {
                  setCurrentPageNum(res.pageNumber);
                  setSearchQuery("");
                }}
                className="cursor-pointer rounded-lg border border-slate-800 bg-slate-950/70 p-2.5 transition hover:border-amber-500/60 hover:bg-slate-800/80"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs sm:text-sm">
                    {res.pageTitle}
                  </span>
                  <span className="rounded bg-amber-500/10 px-2 py-0.5 text-[11px] font-bold text-amber-300">
                    صفحه {res.pageNumber}
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-slate-400 line-clamp-2">
                  {res.paragraphs[0]}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Table of Contents Drawer */}
      {showToc && (
        <div className="mb-6 rounded-2xl border border-slate-800 bg-slate-900/95 p-5 shadow-2xl backdrop-blur">
          <div className="mb-4 flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-amber-400" />
              <h3 className="font-bold text-white text-sm sm:text-base">
                فهرست تفصیلی فصول کتاب (۱۰۰ صفحه)
              </h3>
            </div>
            <button
              onClick={() => setShowToc(false)}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white text-xs font-bold"
            >
              بستن ✕
            </button>
          </div>

          <div className="grid gap-2 max-h-96 overflow-y-auto sm:grid-cols-2">
            {CHAPTERS_CONFIG.map((chap) => {
              const isCurrent =
                currentPageNum >= chap.startPage &&
                currentPageNum <= chap.endPage;
              return (
                <div
                  key={chap.id}
                  onClick={() => {
                    setCurrentPageNum(chap.startPage);
                    setShowToc(false);
                  }}
                  className={`cursor-pointer rounded-xl border p-3 transition-all ${
                    isCurrent
                      ? "border-amber-500 bg-amber-500/10 shadow-md shadow-amber-500/10"
                      : "border-slate-800 bg-slate-950/50 hover:border-slate-700 hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs sm:text-sm text-amber-300">
                      {chap.title}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-400">
                      ص {chap.startPage} - {chap.endPage}
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-slate-400 line-clamp-1">
                    {chap.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* THE 100-PAGE PHYSICAL BOOK SIMULATION CONTAINER */}
      <div
        className={`relative min-h-[750px] rounded-3xl border p-6 sm:p-10 transition-all ${themeContainerClass}`}
      >
        {/* Book Running Header */}
        <div className="mb-8 flex items-center justify-between border-b pb-4 text-xs font-semibold opacity-75">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-500">
              {BOOK_META.title}
            </span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden text-slate-400 sm:inline">
              {currentPage.chapterTitle}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="rounded bg-amber-500/15 px-2 py-0.5 text-amber-400 font-bold">
              صفحه {currentPage.pageNumber} از ۱۰۰
            </span>
          </div>
        </div>

        {/* Page Titles */}
        <div className="mb-6 space-y-1 text-center">
          <div className="text-xs font-bold uppercase tracking-wider text-amber-500">
            {currentPage.sectionTitle}
          </div>
          <h2 className="text-xl font-black sm:text-2xl lg:text-3xl">
            {currentPage.pageTitle}
          </h2>
          <div className="mx-auto mt-2 h-1 w-16 rounded-full bg-gradient-to-r from-amber-500 to-amber-700" />
        </div>

        {/* Audio Lecture Link if available */}
        {currentPage.audioReference && (
          <div className="mb-6 flex items-center justify-between rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-300">
            <div className="flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-amber-400 animate-pulse" />
              <span>
                این بخش به صورت صوتی در سخنرانی{" "}
                <strong className="font-bold text-white">
                  {currentPage.audioReference}
                </strong>{" "}
                توسط استاد تدریس شده است.
              </span>
            </div>
            {onPlayAudioForPage && (
              <button
                onClick={() =>
                  onPlayAudioForPage(
                    currentPage.audioReference || "",
                    currentPage.pageNumber
                  )
                }
                className="rounded-lg bg-amber-500 px-3 py-1 font-bold text-slate-950 transition hover:bg-amber-400"
              >
                پخش مستقیم صوت
              </button>
            )}
          </div>
        )}

        {/* Quran Verses Section (if present on page) */}
        {currentPage.verses && currentPage.verses.length > 0 && (
          <div className="my-6 space-y-4">
            {currentPage.verses.map((v, i) => (
              <div
                key={i}
                className="quran-verse-box rounded-2xl border border-amber-500/40 bg-amber-500/5 p-5 text-center shadow-inner"
              >
                <div className="font-quran text-lg sm:text-2xl font-bold leading-loose text-amber-400">
                  «{v.arabic}»
                </div>
                <div className="mt-2 text-xs sm:text-sm font-medium leading-relaxed opacity-90">
                  {v.translation}
                </div>
                <div className="mt-2 text-[11px] font-bold text-amber-500/80">
                  سوره مبارکه {v.surah}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Main Body Paragraphs */}
        <div className={`space-y-4 text-justify ${fontClass}`}>
          {currentPage.paragraphs.map((para, idx) => {
            // Check if paragraph is a special heading
            if (para.startsWith("###")) {
              return (
                <h3
                  key={idx}
                  className="pt-3 pb-1 text-base font-black text-amber-400 sm:text-lg"
                >
                  {para.replace("###", "").trim()}
                </h3>
              );
            }
            return (
              <p key={idx} className="indent-4 sm:indent-6">
                {para}
              </p>
            );
          })}
        </div>

        {/* Key Takeaways Card */}
        {currentPage.takeaways && currentPage.takeaways.length > 0 && (
          <div className={`mt-8 rounded-2xl border p-4 sm:p-5 ${themeInnerCard}`}>
            <div className="mb-2 flex items-center gap-2 text-xs font-black text-amber-400">
              <Sparkles className="h-4 w-4" />
              <span>نکات کلیدی و باورهای این صفحه:</span>
            </div>
            <ul className="space-y-1.5 text-xs sm:text-sm">
              {currentPage.takeaways.map((point, pIdx) => (
                <li key={pIdx} className="flex items-start gap-2">
                  <CheckCircle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-emerald-400" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Footnote if present */}
        {currentPage.footnote && (
          <div className="mt-8 border-t pt-4 text-xs opacity-75">
            <span className="font-bold">پاورقی:</span> {currentPage.footnote}
          </div>
        )}

        {/* Running Footer with Page Number */}
        <div className="mt-12 flex items-center justify-between border-t pt-4 text-xs opacity-70">
          <div>
            <span>روش تنظیم: پیاده‌سازی رسمی از کلام استاد نصرالله باستین</span>
          </div>
          <div className="font-black text-base text-amber-500">
            - {currentPage.pageNumber} -
          </div>
          <div>
            <span>نشر آثار بین‌المللی</span>
          </div>
        </div>
      </div>

      {/* Bottom Pager Controls */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-800 bg-slate-950/80 p-4 shadow-xl backdrop-blur">
        <button
          onClick={goToPrevPage}
          disabled={currentPageNum === 1}
          className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs sm:text-sm font-bold text-slate-200 transition hover:bg-slate-700 disabled:opacity-40"
        >
          <ChevronRight className="h-4 w-4" />
          <span>صفحه قبلی</span>
        </button>

        {/* Page Slider */}
        <div className="flex flex-1 items-center gap-3 max-w-md mx-2">
          <span className="text-xs font-bold text-slate-400">۱</span>
          <input
            type="range"
            min={1}
            max={100}
            value={currentPageNum}
            onChange={(e) => setCurrentPageNum(parseInt(e.target.value, 10))}
            className="h-2 w-full cursor-pointer accent-amber-500"
          />
          <span className="text-xs font-bold text-slate-400">۱۰۰</span>
        </div>

        <button
          onClick={goToNextPage}
          disabled={currentPageNum === 100}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-4 py-2 text-xs sm:text-sm font-bold text-slate-950 transition hover:from-amber-400 hover:to-amber-500 disabled:opacity-40"
        >
          <span>صفحه بعدی</span>
          <ChevronLeft className="h-4 w-4" />
        </button>
      </div>

      {/* Bookmark Modal */}
      {showBookmarkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white">
              نشانه‌گذاری صفحه {currentPage.pageNumber}
            </h3>
            <p className="mt-1 text-xs text-slate-400">
              «{currentPage.pageTitle}»
            </p>
            <div className="mt-4">
              <label className="text-xs text-slate-300 font-medium">
                یادداشت یا نکته شخصی شما:
              </label>
              <textarea
                value={bookmarkNote}
                onChange={(e) => setBookmarkNote(e.target.value)}
                placeholder="مثلاً: این صفحه در مورد قانون اعراض را مجدداً مرور کنم..."
                rows={3}
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-3 text-xs text-slate-200 focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                onClick={() => setShowBookmarkModal(false)}
                className="rounded-lg px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
              >
                انصراف
              </button>
              <button
                onClick={handleSaveBookmark}
                className="rounded-lg bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400"
              >
                ذخیره نشانک
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
