"use client";

import React, { useState, useEffect } from "react";
import { Heart, Globe, Send, Quote, Sparkles, Check } from "lucide-react";

interface Reflection {
  id: number;
  authorName: string;
  countryOrCity: string | null;
  message: string;
  favoriteQuote: string | null;
  createdAt: string;
}

export function CommunitySection() {
  const [reflections, setReflections] = useState<Reflection[]>([]);
  const [authorName, setAuthorName] = useState("");
  const [countryOrCity, setCountryOrCity] = useState("");
  const [message, setMessage] = useState("");
  const [favoriteQuote, setFavoriteQuote] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const fetchReflections = async () => {
    try {
      const res = await fetch("/api/reflections");
      const data = await res.json();
      if (data.ok && data.data) {
        setReflections(data.data);
      }
    } catch {}
  };

  useEffect(() => {
    fetchReflections();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !message.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/reflections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorName,
          countryOrCity: countryOrCity || "ایران",
          message,
          favoriteQuote,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSubmittedSuccess(true);
        setAuthorName("");
        setCountryOrCity("");
        setMessage("");
        setFavoriteQuote("");
        fetchReflections();
        setTimeout(() => setSubmittedSuccess(false), 4000);
      }
    } catch {}
    setIsSubmitting(false);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <Globe className="h-3.5 w-3.5 text-emerald-400" />
          <span>طنین کلام استاد در سراسر جهان</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          دیدگاه‌ها و بازتاب‌های جهانیان
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          تجربیات جویندگان حقیقت از تحول زندگی با پیاده‌سازی قوانین کتاب و صوت‌های استاد
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-12">
        {/* Submission Form */}
        <div className="lg:col-span-5">
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-2xl space-y-4"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-400" />
              <span>ثبت دیدگاه یا تحول شخصی شما</span>
            </h3>

            <div>
              <label className="text-xs font-medium text-slate-300">نام شما:</label>
              <input
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="مثلاً: احمد رضایی"
                required
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300">
                شهر یا کشور محل سکونت:
              </label>
              <input
                type="text"
                value={countryOrCity}
                onChange={(e) => setCountryOrCity(e.target.value)}
                placeholder="مثلاً: شیراز / برلین / تورنتو"
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300">
                جمله یا کلام مورد علاقه از استاد:
              </label>
              <input
                type="text"
                value={favoriteQuote}
                onChange={(e) => setFavoriteQuote(e.target.value)}
                placeholder="مثلاً: قرار نیست خودتان را تکه‌پاره کنید..."
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300">
                پیام و تجربه شما از آموزه‌ها:
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
                placeholder="چگونه نگرش شما به زندگی و قرآن تغییر کرد..."
                required
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 py-3 text-xs font-bold text-slate-950 transition hover:from-amber-400 hover:to-amber-500 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              <span>{isSubmitting ? "در حال ثبت..." : "ارسال پیام برای جهانیان"}</span>
            </button>

            {submittedSuccess && (
              <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-center text-xs font-bold text-emerald-300">
                پیام شما با موفقیت ثبت شد و در سامانه جهانی به نمایش درآمد.
              </div>
            )}
          </form>
        </div>

        {/* Testimonials Stream */}
        <div className="lg:col-span-7 space-y-4">
          <h4 className="text-xs font-bold text-slate-400 mb-1">
            پیام‌های دریافتی از سراسر جهان ({reflections.length}):
          </h4>

          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {reflections.map((ref) => (
              <div
                key={ref.id}
                className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-3"
              >
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs sm:text-sm text-white">
                      {ref.authorName}
                    </span>
                    <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-400">
                      {ref.countryOrCity}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500">
                    {new Date(ref.createdAt).toLocaleDateString("fa-IR")}
                  </span>
                </div>

                {ref.favoriteQuote && (
                  <div className="flex items-start gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-xs text-amber-300 italic">
                    <Quote className="h-4 w-4 flex-shrink-0 text-amber-400 opacity-60" />
                    <span>«{ref.favoriteQuote}»</span>
                  </div>
                )}

                <p className="text-xs leading-relaxed text-slate-300 text-justify">
                  {ref.message}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
