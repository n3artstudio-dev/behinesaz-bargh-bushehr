"use client";

import React, { useState } from "react";
import { Globe, X, Check, Copy, Share2, Sparkles, BookOpen, Layers } from "lucide-react";

interface GlobalReachModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function GlobalReachModal({ isOpen, onClose }: GlobalReachModalProps) {
  const [activeLang, setActiveLang] = useState<"fa" | "en" | "ar">("fa");
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const contentFa = {
    title: "سامانهٔ جهانی رساندن پیام استاد حاج نصرالله باستین به گوش بشریت",
    subtitle: "طرح استراتژیک بزرگ‌ترین شرکت‌ها و پلتفرم‌های تراز اول برای توزیع بین‌المللی",
    pillars: [
      {
        title: "۱. کتاب جامع ۱۰۰ صفحه‌ای استاندارد بین‌المللی",
        desc: "تنظیم نظام‌مند بر پایه جلسات صوتی و مکتوبات استاد با ذکر صادقانه روش تدوین؛ قابل چاپ، ترجمه‌پذیر، و مستند به آیات قرآن.",
      },
      {
        title: "۲. پلتفرم هوشمند چندرسانه‌ای (Web, Audio & AI)",
        desc: "ارائه صدای اصلی استاد، همگام‌سازی لحظه‌ای متن و صوت، آزمون‌های تعاملی شبانه، و موتور پاسخگویی هوشمند به زبان‌های زنده دنیا.",
      },
      {
        title: "۳. ترجمه فلسفی و علمی به زبان‌های بین‌المللی",
        desc: "برگردان واژگانی نظیر فرکانس، ایمان به غیب، اعراض و صلات با اتکا بر زبان فیزیک کوانتوم و روانشناسی شناختی برای جذب متفکران جهان.",
      },
      {
        title: "۴. دسترسی آزاد و نامحدود در سراسر کره زمین",
        desc: "بدون حصار جغرافیایی یا اقتصادی، تا هر جوینده حقیقتی بتواند با اتصال به مدار فراوانی، از رنج فقر و اضطراب رهایی یابد.",
      },
    ],
    manifesto:
      "«اگر بنا بود بزرگ‌ترین جهان‌بینی جهان را به گوش همگان برسانیم، آن را در قالبی پیراسته، آزاد از تعصب، همراه با آزمایش‌های عملی (نظیر سوره حمد و لیل) و با عشق نامشروط الهی عرضه می‌کردیم تا انسان سرگشته امروز بفهمد هیچ چیزی اتفاقی نیست و خدا او را برای مدار آسانی آفریده است».",
  };

  const contentEn = {
    title: "Global Manifesto: Delivering Master Nasrollah Bastin's Message to the World",
    subtitle: "A World-Class Platform Architecture for Quranic Frequency & Metaphysical Laws",
    pillars: [
      {
        title: "1. The 100-Page Verified Master Text",
        desc: "Arranged with strict editorial integrity based solely on Master Bastin's transcribed audio discourses; standard book format, print-ready, and fully annotated with Quranic Arabic text.",
      },
      {
        title: "2. The Law of Universal Frequency & Mental Orbitals",
        desc: "Human thoughts and emotions broadcast continuous vibrations into a responsive cosmos. Coincidence is an illusion; the universe is an immutable mathematical system designed by the Lord of all Worlds (Rabb al-Alamin).",
      },
      {
        title: "3. The Quranic Art of Focus (I'radh) & Non-Attachment",
        desc: "Overcoming scarcity mindset, shifting focus from lack to abundance, and liberating the soul from dependency on human causes through the philosophy of Surah Al-Fatiha and Surah Al-Layl.",
      },
      {
        title: "4. Global Multilingual Open-Access Distribution",
        desc: "Empowering 8 billion human beings with cognitive tools to transition from struggle (Usra) to effortless ease (Yusra).",
      },
    ],
    manifesto:
      '"Nothing in this universe happens by chance. We do not need to tear ourselves apart to receive divine blessings; we simply need to align our frequency with the orbital of abundance."',
  };

  const contentAr = {
    title: "المنظومة العالمية لإيصال تعاليم الأستاذ الحاج نصر الله باستين إلى العالم",
    subtitle: "بناء منصة معرفية شاملة تشرح قوانين التردد الكوني وسنن القرآن الثابتة",
    pillars: [
      {
        title: "١. الكتاب المنهجي المائة صفحة المعتمد",
        desc: "مستخرج بأمانة مطلقة من تسجيلات ودروس الأستاذ نصر الله باستین، موثق بالآيات الكريمة، وجاهز للطباعة والنشر الأكاديمي والفكري.",
      },
      {
        title: "٢. حقيقة الإيمان بالغيب وقانون التردد",
        desc: "الماديات تستند على الميتافيزياء، والكون لا يعرف الصدفة. المشاعر والتركيز هي التي تصنع مسارات الحياة وفق سنن الله الرياضية الدقيقة.",
      },
      {
        title: "٣. فقه الإعراض ومسار اليسرى في سورة الليل",
        desc: "الانتقال الحتمي من التشبث المنهك بالنتائج إلى فضاء التوكل والإنفاق واليقين (فسنيسره لليسرى).",
      },
      {
        title: "٤. رسالة التوحيد الخالص لجميع البشر",
        desc: "تطهير العقل من الشرك الخفي في الأسباب، والارتقاء بالنفس الإنسانية إلى مدار العزة والوفرة الإلهية.",
      },
    ],
    manifesto:
      "«لا صدفة في هذا الوجود؛ كل حدث هو انعكاس لترددات العقل والقلب. ومن تعلم توجيه انتباهه إلى فضل الله، يسره الله لليسرى في كل خطوة».",
  };

  const activeContent =
    activeLang === "fa" ? contentFa : activeLang === "en" ? contentEn : contentAr;

  const handleCopy = () => {
    const text = `${activeContent.title}\n\n${activeContent.subtitle}\n\n${activeContent.manifesto}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-3xl rounded-3xl border border-slate-800 bg-slate-900 p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute left-6 top-6 rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Language Tabs */}
        <div className="flex items-center gap-2 mb-6">
          <button
            onClick={() => setActiveLang("fa")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              activeLang === "fa"
                ? "bg-amber-500 text-slate-950"
                : "bg-slate-800 text-slate-300 hover:text-white"
            }`}
          >
            فارسی (اصل کلام)
          </button>
          <button
            onClick={() => setActiveLang("en")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              activeLang === "en"
                ? "bg-amber-500 text-slate-950"
                : "bg-slate-800 text-slate-300 hover:text-white"
            }`}
          >
            English (International)
          </button>
          <button
            onClick={() => setActiveLang("ar")}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              activeLang === "ar"
                ? "bg-amber-500 text-slate-950"
                : "bg-slate-800 text-slate-300 hover:text-white"
            }`}
          >
            العربية (التأصيل القرآني)
          </button>
        </div>

        {/* Header */}
        <div className="mb-6 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
            <Globe className="h-4 w-4" />
            <span>رسالت جهانی سامانه</span>
          </div>
          <h3 className="text-lg sm:text-2xl font-black text-white leading-snug">
            {activeContent.title}
          </h3>
          <p className="text-xs sm:text-sm text-slate-400">
            {activeContent.subtitle}
          </p>
        </div>

        {/* Pillars Grid */}
        <div className="grid gap-3 sm:grid-cols-2 mb-6">
          {activeContent.pillars.map((pillar, i) => (
            <div
              key={i}
              className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4 space-y-1.5"
            >
              <h4 className="text-xs sm:text-sm font-bold text-amber-300">
                {pillar.title}
              </h4>
              <p className="text-xs leading-relaxed text-slate-400 text-justify">
                {pillar.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Manifesto Quote */}
        <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5 text-center text-xs sm:text-sm font-bold leading-relaxed text-amber-200">
          {activeContent.manifesto}
        </div>

        {/* Footer Actions */}
        <div className="mt-6 flex items-center justify-between border-t border-slate-800 pt-4">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-bold text-slate-200 hover:bg-slate-700"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 text-emerald-400" />
                <span>کپی شد!</span>
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" />
                <span>کپی چکیده بین‌المللی</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="rounded-xl bg-amber-500 px-5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400"
          >
            متوجه شدم
          </button>
        </div>
      </div>
    </div>
  );
}
