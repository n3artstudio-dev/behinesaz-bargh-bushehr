"use client";

import React from "react";
import Image from "next/image";
import { BookOpen, Headphones, ShieldCheck, Award, Sparkles, CheckCircle2 } from "lucide-react";
import { ActiveTab } from "./Navbar";

interface HeroBannerProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenPrint: () => void;
}

export function HeroBanner({ setActiveTab, onOpenPrint }: HeroBannerProps) {
  return (
    <div className="relative overflow-hidden border-b border-slate-800 bg-gradient-to-b from-slate-900/80 via-slate-950 to-slate-950 px-4 py-8 sm:px-6 sm:py-12">
      {/* Background Glows */}
      <div className="pointer-events-none absolute -top-24 right-1/4 h-96 w-96 rounded-full bg-amber-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-1/4 h-96 w-96 rounded-full bg-blue-600/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl">
        <div className="grid items-center gap-8 lg:grid-cols-12 lg:gap-12">
          {/* Main Text Content */}
          <div className="space-y-6 lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>ویرایش استنادیافته و جامع — قطع ۱۰۰ صفحه‌ای استاندارد</span>
            </div>

            <h1 className="text-2xl font-black leading-tight text-white sm:text-4xl lg:text-5xl">
              مدار فرکانسی جهان و <span className="text-transparent bg-clip-text bg-gradient-to-l from-amber-300 via-amber-400 to-amber-500">حکمت‌های قرآنی</span>
            </h1>

            <p className="text-base font-medium leading-relaxed text-slate-300 sm:text-lg">
              کتاب و سامانه جامع تنظیم‌شده از روی متن ویرایش‌شدهٔ جلسات، تدریس‌ها و صوت‌های رسمی{" "}
              <strong className="text-amber-300 font-bold">استاد حاج نصرالله باستین</strong>؛ تبیین قوانین تغییرناپذیر آفرینش، ایمان به غیب، کنترل ذهن و حرکت از متافیزیک به فیزیک.
            </p>

            {/* Editorial Authenticity Badge */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4 text-xs sm:text-sm text-slate-300">
              <div className="flex items-start gap-3">
                <ShieldCheck className="mt-0.5 h-5 w-5 flex-shrink-0 text-emerald-400" />
                <div>
                  <span className="font-bold text-white">ذکر صادقانه روش تنظیم:</span>
                  <p className="mt-1 leading-relaxed text-slate-400">
                    این کتاب و سامانه تماماً بر پایهٔ متن‌های ثبت‌شده و پیاده‌سازی‌شدهٔ جلسات آموزشی خودِ استاد تنظیم گردیده و خط به خط آموزه‌ها، استدلال‌ها و تمثیل‌های ایشان بدون تحریف یا افزودن آرای شخصی تدوین شده است.
                  </p>
                </div>
              </div>
            </div>

            {/* Key Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setActiveTab("book")}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-3 text-sm font-bold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:from-amber-400 hover:to-amber-500"
              >
                <BookOpen className="h-4 w-4" />
                <span>شروع مطالعه کتاب (صفحات ۱ تا ۱۰۰)</span>
              </button>

              <button
                onClick={() => setActiveTab("audio")}
                className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-5 py-3 text-sm font-semibold text-slate-200 transition hover:border-slate-600 hover:bg-slate-700"
              >
                <Headphones className="h-4 w-4 text-amber-400" />
                <span>شنیدن جلسات صوتی استاد</span>
              </button>

              <button
                onClick={onOpenPrint}
                className="flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm font-semibold text-amber-300 transition hover:bg-amber-500/20"
              >
                <Award className="h-4 w-4" />
                <span>خروجی چاپ استاندارد و PDF</span>
              </button>
            </div>

            {/* Key Stats Bar */}
            <div className="grid grid-cols-2 gap-3 pt-4 sm:grid-cols-4">
              <div className="rounded-lg border border-slate-800/80 bg-slate-900/60 p-3">
                <div className="text-xl font-black text-amber-400">۱۰۰</div>
                <div className="text-xs text-slate-400">صفحه استاندارد کتاب</div>
              </div>
              <div className="rounded-lg border border-slate-800/80 bg-slate-900/60 p-3">
                <div className="text-xl font-black text-emerald-400">۱۲</div>
                <div className="text-xs text-slate-400">فصل جامع آموزشی</div>
              </div>
              <div className="rounded-lg border border-slate-800/80 bg-slate-900/60 p-3">
                <div className="text-xl font-black text-blue-400">۹</div>
                <div className="text-xs text-slate-400">سخنرانی صوتی اصلی</div>
              </div>
              <div className="rounded-lg border border-slate-800/80 bg-slate-900/60 p-3">
                <div className="text-xl font-black text-purple-400">۱۰۰٪</div>
                <div className="text-xs text-slate-400">مبتنی بر کلام استاد</div>
              </div>
            </div>
          </div>

          {/* Master Portrait & Visual Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-sm rounded-2xl border border-amber-500/30 bg-gradient-to-b from-slate-900 to-slate-950 p-4 shadow-2xl shadow-amber-500/10">
              {/* Outer decorative ring */}
              <div className="relative aspect-[4/5] overflow-hidden rounded-xl border border-slate-800 bg-slate-950">
                <Image
                  src="/images/ostad-bastin.jpg"
                  alt="استاد حاج نصرالله باستین"
                  fill
                  className="object-cover object-top filter brightness-95 contrast-105"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                <div className="absolute bottom-4 right-4 left-4 rounded-lg border border-slate-800/90 bg-slate-950/80 p-3 backdrop-blur-md">
                  <div className="text-xs font-bold text-amber-400">استاد حاج نصرالله باستین</div>
                  <div className="text-[11px] text-slate-300">مدرس دوره‌های تأثیر قرآن بر زندگی و قوانین الهی</div>
                </div>
              </div>

              {/* Highlights below photo */}
              <div className="mt-4 space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                  <span>بررسی موشکافانه سوره حمد و سوره لیل</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                  <span>حل معمای شرک خفی و دل بستن به اسباب</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                  <span>واژه‌شناسی قرآنی: اثم، ذنب، صلات و اعراض</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
