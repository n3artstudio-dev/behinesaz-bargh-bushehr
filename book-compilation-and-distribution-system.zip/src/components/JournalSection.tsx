"use client";

import React, { useState, useEffect } from "react";
import { Bookmark, Sparkles, Plus, Trash2, Calendar, CheckCircle2 } from "lucide-react";

interface JournalEntry {
  id: number;
  title: string;
  content: string;
  frequencyFocus: string;
  gratitudeItems: string[] | null;
  moodRating: number | null;
  createdAt: string;
}

export function JournalSection() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [frequencyFocus, setFrequencyFocus] = useState("باور فراوانی");
  const [gratitude1, setGratitude1] = useState("");
  const [gratitude2, setGratitude2] = useState("");
  const [gratitude3, setGratitude3] = useState("");
  const [moodRating, setMoodRating] = useState(5);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const focusOptions = [
    "باور فراوانی",
    "شکرگزاری قلبی و صلات",
    "قانون اعراض از ناخواسته‌ها",
    "ایمان به غیب و رهایی از تقلا",
    "عدم شرک به اسباب و دستان خدا",
    "عزت‌نفس و احساس لیاقت ذاتی",
  ];

  const fetchEntries = async () => {
    try {
      const res = await fetch("/api/journal");
      const data = await res.json();
      if (data.ok && data.data) {
        setEntries(data.data);
      }
    } catch {}
  };

  useEffect(() => {
    fetchEntries();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setIsLoading(true);
    try {
      const gratitudeItems = [gratitude1, gratitude2, gratitude3].filter((g) => g.trim().length > 0);
      const res = await fetch("/api/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          content,
          frequencyFocus,
          gratitudeItems,
          moodRating,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSavedSuccess(true);
        setTitle("");
        setContent("");
        setGratitude1("");
        setGratitude2("");
        setGratitude3("");
        fetchEntries();
        setTimeout(() => setSavedSuccess(false), 3000);
      }
    } catch {}
    setIsLoading(false);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <Bookmark className="h-3.5 w-3.5 text-amber-400" />
          <span>تمرین روزانه کالیبراسیون ذهن و ثبت شکرگزاری</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          دفترچه روزانه فرکانس و هدایت توجه
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          دستورالعمل استاد باستین: ذهن تا نوشته نشود، باور نمی‌سازد
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-12">
        {/* Entry Form */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-2xl backdrop-blur space-y-4"
          >
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-400" />
              <span>ثبت تمرین امروز</span>
            </h3>

            <div>
              <label className="text-xs font-medium text-slate-300">
                کانون توجه و مدار فرکانسی امروز:
              </label>
              <select
                value={frequencyFocus}
                onChange={(e) => setFrequencyFocus(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-amber-300 focus:border-amber-500 focus:outline-none"
              >
                {focusOptions.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300">
                عنوان یادداشت:
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثلاً: تجربه اعراض در محل کار..."
                required
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            {/* Three Gratitude Items */}
            <div className="space-y-1.5 rounded-2xl border border-slate-800/80 bg-slate-950/60 p-3.5">
              <span className="text-[11px] font-bold text-amber-400 block mb-1">
                سه نعمتی که امروز قلباً بابت آنها شاکر پروردگارم:
              </span>
              <input
                type="text"
                value={gratitude1}
                onChange={(e) => setGratitude1(e.target.value)}
                placeholder="۱. نعمت اول..."
                className="w-full rounded-lg border border-slate-800 bg-slate-900 p-2 text-xs text-slate-200 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
              />
              <input
                type="text"
                value={gratitude2}
                onChange={(e) => setGratitude2(e.target.value)}
                placeholder="۲. نعمت دوم..."
                className="w-full rounded-lg border border-slate-800 bg-slate-900 p-2 text-xs text-slate-200 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
              />
              <input
                type="text"
                value={gratitude3}
                onChange={(e) => setGratitude3(e.target.value)}
                placeholder="۳. نعمت سوم..."
                className="w-full rounded-lg border border-slate-800 bg-slate-900 p-2 text-xs text-slate-200 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300">
                شرح احوال درونی و کنترل ذهن:
              </label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={4}
                placeholder="چگونه توانستم امروز ورودی‌های منفی را مهار کنم و به نعمات نگاه کنم..."
                required
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-950 p-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">سطح آرامش درونی:</span>
                <input
                  type="range"
                  min={1}
                  max={10}
                  value={moodRating}
                  onChange={(e) => setMoodRating(Number(e.target.value))}
                  className="w-24 accent-amber-500"
                />
                <span className="text-xs font-bold text-amber-400">{moodRating}/۱۰</span>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-5 py-2.5 text-xs font-bold text-slate-950 transition hover:from-amber-400 hover:to-amber-500 disabled:opacity-50"
              >
                {isLoading ? "در حال ثبت..." : "ثبت در دفترچه"}
              </button>
            </div>

            {savedSuccess && (
              <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-2.5 text-center text-xs font-bold text-emerald-300">
                تمرین شما با موفقیت در دیتابیس ثبت گردید.
              </div>
            )}
          </form>
        </div>

        {/* Entries List */}
        <div className="lg:col-span-5 space-y-3">
          <h4 className="text-xs font-bold text-slate-400 mb-2">
            تاریخچه تمرین‌های ثبت‌شده شما ({entries.length}):
          </h4>
          {entries.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-800 p-8 text-center text-xs text-slate-500">
              هنوز تمرینی ثبت نشده است. اولین تمرین خود را با شکرگزاری آغاز کنید.
            </div>
          ) : (
            <div className="space-y-3 max-h-[550px] overflow-y-auto pr-1">
              {entries.map((entry) => (
                <div
                  key={entry.id}
                  className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="rounded-md bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold text-amber-400">
                      {entry.frequencyFocus}
                    </span>
                    <span className="text-[10px] text-slate-500 flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(entry.createdAt).toLocaleDateString("fa-IR")}
                    </span>
                  </div>

                  <h5 className="font-bold text-xs sm:text-sm text-white">{entry.title}</h5>
                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                    {entry.content}
                  </p>

                  {entry.gratitudeItems && entry.gratitudeItems.length > 0 && (
                    <div className="rounded-lg bg-slate-950/60 p-2.5 text-[11px] space-y-1 text-slate-300 border border-slate-800">
                      <span className="font-bold text-amber-400 block text-[10px]">
                        نعمات سپاسگزاری‌شده:
                      </span>
                      {entry.gratitudeItems.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1.5">
                          <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
