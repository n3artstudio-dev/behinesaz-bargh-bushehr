"use client";

import React, { useState } from "react";
import { QURANIC_LEXICON, LexiconItem } from "@/data/lexiconData";
import { Sparkles, Search, BookMarked, Bookmark } from "lucide-react";

export function LexiconSection() {
  const [search, setSearch] = useState("");
  const [selectedWord, setSelectedWord] = useState<LexiconItem | null>(null);

  const filtered = QURANIC_LEXICON.filter(
    (item) =>
      item.word.includes(search) ||
      item.root.includes(search) ||
      item.summary.includes(search) ||
      item.fullExplanation.includes(search)
  );

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <Sparkles className="h-3.5 w-3.5 text-amber-400" />
          <span>زبان‌شناسی و ریشه‌شناسی توحیدی واژگان وحی</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          فرهنگ واژگان فرکانسی استاد حاج نصرالله باستین
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          بازخوانی علمی و روانشناختی مفاهیم قرآن به دور از ترجمه‌های سطحی و سنتی
        </p>
      </div>

      {/* Search Input */}
      <div className="mx-auto mb-8 max-w-md">
        <div className="relative">
          <Search className="absolute right-3.5 top-3 h-4 w-4 text-slate-500" />
          <input
            type="text"
            placeholder="جستجوی واژه (مثلاً: اثم، اعراض، انفاق، صلات)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-2xl border border-slate-800 bg-slate-900/90 py-2.5 pr-10 pl-4 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Grid of Lexicon Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((item, idx) => (
          <div
            key={idx}
            onClick={() => setSelectedWord(item)}
            className="cursor-pointer group relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/60 p-5 transition-all hover:border-amber-500/50 hover:bg-slate-900 hover:shadow-xl hover:shadow-amber-500/5"
          >
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <span className="font-quran text-xl font-bold text-amber-400">
                {item.word}
              </span>
              <span className="rounded-md bg-slate-800 px-2 py-0.5 text-[11px] font-mono font-medium text-slate-400">
                ریشه: {item.root}
              </span>
            </div>

            <p className="mt-3 text-xs font-semibold leading-relaxed text-slate-200">
              {item.summary}
            </p>

            <p className="mt-2 text-[11px] leading-relaxed text-slate-400 line-clamp-3">
              {item.fullExplanation}
            </p>

            <div className="mt-4 flex items-center justify-between text-[10px] text-amber-500/80 border-t border-slate-800/50 pt-2">
              <span className="truncate">{item.quranReference}</span>
              <span className="font-bold text-amber-400 group-hover:translate-x-[-2px] transition-transform">
                مشاهده کامل ←
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Modal */}
      {selectedWord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-3xl border border-slate-800 bg-slate-900 p-6 sm:p-8 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <span className="font-quran text-3xl font-black text-amber-400">
                  {selectedWord.word}
                </span>
                <span className="rounded-lg bg-amber-500/15 px-2.5 py-1 text-xs font-mono font-bold text-amber-300">
                  ریشه سه حرفی: {selectedWord.root}
                </span>
              </div>
              <button
                onClick={() => setSelectedWord(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div>
                <span className="text-xs font-bold text-slate-400">خلاصه مفهوم:</span>
                <p className="mt-1 text-sm font-bold text-white">
                  {selectedWord.summary}
                </p>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-400">
                  تحلیل و شرح موشکافانه استاد حاج نصرالله باستین:
                </span>
                <p className="mt-1.5 text-xs sm:text-sm leading-loose text-slate-300 whitespace-pre-line text-justify">
                  {selectedWord.fullExplanation}
                </p>
              </div>

              <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-center">
                <span className="block text-[11px] font-bold text-amber-400 mb-1">
                  شاهد مثال قرآنی:
                </span>
                <span className="font-quran text-sm sm:text-base font-bold text-slate-100">
                  {selectedWord.quranReference}
                </span>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedWord(null)}
                className="rounded-xl bg-slate-800 px-5 py-2 text-xs font-bold text-white hover:bg-slate-700"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
