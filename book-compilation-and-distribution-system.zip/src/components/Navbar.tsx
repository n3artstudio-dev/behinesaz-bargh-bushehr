"use client";

import React from "react";
import {
  BookOpen,
  Headphones,
  Bot,
  HelpCircle,
  Bookmark,
  Sparkles,
  Printer,
  Globe,
  Sun,
  Moon,
  Coffee,
  Heart,
  Volume2,
} from "lucide-react";

export type ActiveTab =
  | "book"
  | "audio"
  | "ai"
  | "quizzes"
  | "lexicon"
  | "journal"
  | "community"
  | "print";

export type ReadingTheme = "dark" | "light" | "sepia";

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  readingTheme: ReadingTheme;
  setReadingTheme: (theme: ReadingTheme) => void;
  onOpenPrint: () => void;
  onOpenGlobal: () => void;
  activeAudioTitle?: string;
  isPlayingAudio?: boolean;
  onTogglePlayAudio?: () => void;
}

export function Navbar({
  activeTab,
  setActiveTab,
  readingTheme,
  setReadingTheme,
  onOpenPrint,
  onOpenGlobal,
  activeAudioTitle,
  isPlayingAudio,
  onTogglePlayAudio,
}: NavbarProps) {
  const tabs = [
    { id: "book" as ActiveTab, label: "کتاب ۱۰۰ صفحه‌ای", icon: BookOpen, badge: "کامل" },
    { id: "audio" as ActiveTab, label: "صوت و تدریس‌ها", icon: Headphones, badge: "۹ جلسه" },
    { id: "ai" as ActiveTab, label: "کاوشگر هوشمند", icon: Bot, badge: "هوشمند" },
    { id: "quizzes" as ActiveTab, label: "آزمون باورها", icon: HelpCircle, badge: "شبانه" },
    { id: "lexicon" as ActiveTab, label: "واژه‌نامه قرآنی", icon: Sparkles },
    { id: "journal" as ActiveTab, label: "دفترچه فرکانس", icon: Bookmark },
    { id: "community" as ActiveTab, label: "دیدگاه جهانیان", icon: Heart },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div
            onClick={() => setActiveTab("book")}
            className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 shadow-lg shadow-amber-500/20 transition-transform hover:scale-105"
          >
            <BookOpen className="h-6 w-6 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black tracking-wide text-amber-400 sm:text-base">
                استاد حاج نصرالله باستین
              </span>
              <span className="hidden rounded-full bg-amber-500/10 px-2 py-0.5 text-xs font-medium text-amber-300 ring-1 ring-amber-500/30 sm:inline-block">
                کتاب ۱۰۰ صفحه‌ای
              </span>
            </div>
            <p className="text-xs text-slate-400">سامانه بین‌المللی نشر قوانین الهی و مدار فرکانسی جهان</p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Active Audio Quick Pill */}
          {activeAudioTitle && (
            <button
              onClick={onTogglePlayAudio}
              className="hidden items-center gap-2 rounded-full border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 text-xs text-amber-300 transition-all hover:bg-amber-500/20 md:flex"
              title="کنترل پخش صوت جاری"
            >
              <Volume2
                className={`h-4 w-4 text-amber-400 ${isPlayingAudio ? "animate-pulse" : ""}`}
              />
              <span className="max-w-[120px] truncate">{activeAudioTitle}</span>
              <span className="font-bold text-amber-400">
                {isPlayingAudio ? "❚❚" : "▶"}
              </span>
            </button>
          )}

          {/* Theme Switcher */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs">
            <button
              onClick={() => setReadingTheme("dark")}
              className={`rounded p-1.5 transition-colors ${
                readingTheme === "dark"
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="تم تیره (شب)"
            >
              <Moon className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setReadingTheme("sepia")}
              className={`rounded p-1.5 transition-colors ${
                readingTheme === "sepia"
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="تم کاغذی (کرم Sepia)"
            >
              <Coffee className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setReadingTheme("light")}
              className={`rounded p-1.5 transition-colors ${
                readingTheme === "light"
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="تم روشن (روز)"
            >
              <Sun className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Print Book Action */}
          <button
            onClick={onOpenPrint}
            className="flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 text-xs font-semibold text-amber-300 transition hover:bg-amber-500 hover:text-slate-950"
            title="آماده‌سازی برای چاپ و دانلود PDF کتاب ۱۰۰ صفحه‌ای"
          >
            <Printer className="h-4 w-4" />
            <span className="hidden sm:inline">چاپ / PDF کتاب</span>
          </button>

          {/* Global Reach Button */}
          <button
            onClick={onOpenGlobal}
            className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 transition hover:border-slate-700 hover:text-white"
            title="پیام به جهانیان (EN / AR / FA)"
          >
            <Globe className="h-4 w-4 text-emerald-400" />
            <span className="hidden sm:inline">جهانیان</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="no-scrollbar border-t border-slate-800/80 bg-slate-900/50 px-4">
        <div className="mx-auto flex max-w-7xl items-center gap-1 overflow-x-auto py-1 sm:gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex flex-shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium transition-all sm:text-sm ${
                  isActive
                    ? "bg-amber-500/15 font-bold text-amber-400"
                    : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200"
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? "text-amber-400" : "text-slate-400"}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`rounded-full px-1.5 py-0.2 text-[10px] ${
                      isActive
                        ? "bg-amber-500 text-slate-950 font-black"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
                {isActive && (
                  <span className="absolute bottom-0 right-2 left-2 h-0.5 rounded-full bg-amber-500" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
