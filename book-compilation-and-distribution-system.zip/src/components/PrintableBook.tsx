"use client";

import React from "react";
import { BOOK_META, CHAPTERS_CONFIG, BOOK_PAGES } from "@/data/bookData";
import { Printer, Download, ArrowRight, BookOpen, ShieldCheck } from "lucide-react";

interface PrintableBookProps {
  onBackToReader: () => void;
}

export function PrintableBook({ onBackToReader }: PrintableBookProps) {
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadTxt = () => {
    let fullText = `${BOOK_META.title}\n${BOOK_META.subtitle}\nمؤلف: ${BOOK_META.author}\n${BOOK_META.publisher}\n\n`;
    BOOK_PAGES.forEach((page) => {
      fullText += `=================================================\n`;
      fullText += `صفحه ${page.pageNumber} — ${page.chapterTitle}\n`;
      fullText += `${page.pageTitle} (${page.sectionTitle})\n`;
      fullText += `=================================================\n\n`;
      page.paragraphs.forEach((p) => {
        fullText += `${p}\n\n`;
      });
      if (page.verses.length > 0) {
        page.verses.forEach((v) => {
          fullText += `«${v.arabic}»\n${v.translation} (سوره ${v.surah})\n\n`;
        });
      }
      if (page.takeaways.length > 0) {
        fullText += `نکات کلیدی:\n`;
        page.takeaways.forEach((t) => {
          fullText += `- ${t}\n`;
        });
        fullText += `\n`;
      }
    });

    const blob = new Blob([fullText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "کتاب-مدار-فرکانسی-جهان-استاد-باستین-۱۰۰صفحه.txt";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-slate-100 sm:px-6">
      {/* Top action toolbar (Hidden when printing via CSS @media print) */}
      <div className="no-print mx-auto mb-8 max-w-5xl rounded-2xl border border-amber-500/40 bg-slate-900/90 p-4 shadow-xl backdrop-blur">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToReader}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-slate-200 transition hover:bg-slate-700 hover:text-white"
            >
              <ArrowRight className="h-4 w-4" />
              <span>بازگشت به کتاب‌خوان دیجیتال</span>
            </button>
            <div>
              <h2 className="text-sm font-bold text-white sm:text-base">
                آماده‌سازی نسخه چاپی کتاب ۱۰۰ صفحه‌ای
              </h2>
              <p className="text-xs text-slate-400">
                فرمت استاندارد قطع کتاب با صفحه آرایی دقیق و شماره صفحات ۱ تا ۱۰۰
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadTxt}
              className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-200 transition hover:bg-slate-700"
              title="دانلود فایل متنی یکپارچه کل ۱۰۰ صفحه"
            >
              <Download className="h-4 w-4" />
              <span>دانلود فایل متنی (TXT)</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-5 py-2 text-xs sm:text-sm font-bold text-slate-950 shadow-lg shadow-amber-500/25 transition hover:from-amber-400 hover:to-amber-500"
            >
              <Printer className="h-4 w-4" />
              <span>چاپ مستقیم یا ذخیره به صورت PDF</span>
            </button>
          </div>
        </div>

        <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-xs text-slate-300">
          <div className="flex items-start gap-2">
            <ShieldCheck className="h-4 w-4 flex-shrink-0 text-emerald-400 mt-0.5" />
            <span>
              نکته برای چاپ: در پنجره چاپگر، گزینه <strong>Destination</strong> را روی <strong>Save as PDF</strong> یا چاپگر فیزیکی خود بگذارید، و گزینه <strong>Margins</strong> را روی <strong>Default</strong> قرار دهید تا هر ۱۰۰ صفحه دقیقاً در صفحات مستقل چاپ شوند.
            </span>
          </div>
        </div>
      </div>

      {/* RENDER ALL 100 PAGES SEQUENTIALLY FOR DIRECT PRINTING */}
      <div className="book-print-container mx-auto max-w-4xl space-y-8">
        {BOOK_PAGES.map((page) => (
          <div
            key={page.pageNumber}
            className="printable-page relative rounded-2xl border border-slate-800 bg-white p-8 sm:p-12 text-slate-900 shadow-md"
            style={{ minHeight: "297mm", color: "#111827", backgroundColor: "#ffffff" }}
          >
            {/* Running Header */}
            <div className="print-running-head mb-6 flex items-center justify-between border-b pb-3 text-[10pt] text-slate-500">
              <span className="font-bold text-amber-700">{BOOK_META.title}</span>
              <span>{page.chapterTitle}</span>
            </div>

            {/* Title Section */}
            <div className="mb-6 text-center">
              <div className="text-[9pt] font-bold text-amber-700 tracking-wider">
                {page.sectionTitle}
              </div>
              <h2 className="mt-1 text-[16pt] font-black leading-tight text-slate-900">
                {page.pageTitle}
              </h2>
              <div className="mx-auto mt-2 h-0.5 w-12 bg-amber-600" />
            </div>

            {/* Quran Verses if present */}
            {page.verses && page.verses.length > 0 && (
              <div className="my-5 space-y-3">
                {page.verses.map((v, vIdx) => (
                  <div
                    key={vIdx}
                    className="quran-verse-box rounded-lg border border-amber-200 bg-amber-50/60 p-4 text-center"
                  >
                    <div className="font-quran text-[13pt] font-bold leading-loose text-amber-900">
                      «{v.arabic}»
                    </div>
                    <div className="mt-1 text-[10pt] text-slate-700">
                      {v.translation}
                    </div>
                    <div className="mt-1 text-[8pt] font-bold text-amber-800">
                      سوره مبارکه {v.surah}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Paragraphs */}
            <div className="space-y-3.5 text-justify text-[10.5pt] leading-[1.8] text-slate-800">
              {page.paragraphs.map((para, pIdx) => {
                if (para.startsWith("###")) {
                  return (
                    <h3
                      key={pIdx}
                      className="pt-2 pb-1 text-[12pt] font-black text-amber-900"
                    >
                      {para.replace("###", "").trim()}
                    </h3>
                  );
                }
                return (
                  <p key={pIdx} className="indent-6">
                    {para}
                  </p>
                );
              })}
            </div>

            {/* Key Takeaways */}
            {page.takeaways && page.takeaways.length > 0 && (
              <div className="mt-6 rounded-lg border border-slate-200 bg-slate-50 p-4 text-[9.5pt]">
                <div className="mb-1 font-bold text-amber-900">
                  نکات کلیدی و تثبیت فرکانس:
                </div>
                <ul className="list-disc pr-5 space-y-1 text-slate-700">
                  {page.takeaways.map((point, ptIdx) => (
                    <li key={ptIdx}>{point}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Footnote if any */}
            {page.footnote && (
              <div className="mt-4 border-t pt-2 text-[8.5pt] text-slate-500">
                پاورقی: {page.footnote}
              </div>
            )}

            {/* Footer with Page Number */}
            <div className="print-page-number mt-8 border-t pt-3 text-center text-[10pt] font-bold text-slate-600">
              - صفحه {page.pageNumber} -
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
