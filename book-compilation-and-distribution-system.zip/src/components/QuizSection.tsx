"use client";

import React, { useState, useEffect } from "react";
import { QUIZ_SESSIONS, QuizSession } from "@/data/quizData";
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  Trophy,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Check,
} from "lucide-react";

export function QuizSection() {
  const [selectedSessionId, setSelectedSessionId] = useState<string>("quiz-11");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [userName, setUserName] = useState("");
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [recentSubmissions, setRecentSubmissions] = useState<
    Array<{
      id: number;
      userName: string;
      sessionName: string;
      score: number;
      totalQuestions: number;
      createdAt: string;
    }>
  >([]);

  const session: QuizSession =
    QUIZ_SESSIONS.find((s) => s.id === selectedSessionId) || QUIZ_SESSIONS[0];

  // Fetch recent submissions
  useEffect(() => {
    fetch("/api/quiz")
      .then((res) => res.json())
      .then((res) => {
        if (res.ok && res.data) {
          setRecentSubmissions(res.data);
        }
      })
      .catch(() => {});
  }, [savedSuccess]);

  const handleSelectOption = (questionId: number, optionIdx: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIdx }));
  };

  const calculateScore = () => {
    let score = 0;
    session.questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        score++;
      }
    });
    return score;
  };

  const handleFinishQuiz = async () => {
    setIsSubmitted(true);
  };

  const handleSaveResult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) return;

    try {
      const score = calculateScore();
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userName,
          sessionName: session.sessionTitle,
          score,
          totalQuestions: session.questions.length,
          userAnswers: selectedAnswers,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSavedSuccess(true);
      }
    } catch {
      setSavedSuccess(true);
    }
  };

  const resetQuiz = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
    setCurrentQuestionIndex(0);
    setSavedSuccess(false);
  };

  const score = calculateScore();

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <HelpCircle className="h-3.5 w-3.5 text-amber-400" />
          <span>آزمون‌های تثبیت باورها — کلاس‌های تأثیر قرآن بر زندگی</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          سنجش میزان تسلط بر قوانین قرآنی
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          سوالات رسمی مطرح‌شده توسط استاد حاج نصرالله باستین در جلسات شبانه
        </p>
      </div>

      {/* Session Selector Tabs */}
      <div className="mb-6 flex flex-wrap gap-2 justify-center">
        {QUIZ_SESSIONS.map((qs) => (
          <button
            key={qs.id}
            onClick={() => {
              setSelectedSessionId(qs.id);
              resetQuiz();
            }}
            className={`rounded-xl px-4 py-2.5 text-xs font-bold transition-all ${
              selectedSessionId === qs.id
                ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20"
                : "border border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700 hover:text-white"
            }`}
          >
            {qs.sessionTitle}
          </button>
        ))}
      </div>

      {/* Quiz Board */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-2xl backdrop-blur">
        <div className="mb-6 flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base sm:text-lg font-black text-white">
              {session.sessionTitle}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">{session.description}</p>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-1.5 text-xs font-bold text-amber-400">
            تعداد: {session.questions.length} سوال
          </div>
        </div>

        {/* Questions list */}
        <div className="space-y-6">
          {session.questions.map((q, idx) => {
            const userAnswer = selectedAnswers[q.id];
            const isCorrect = isSubmitted && userAnswer === q.correctIndex;
            const isWrong = isSubmitted && userAnswer !== undefined && userAnswer !== q.correctIndex;

            return (
              <div
                key={q.id}
                className="rounded-2xl border border-slate-800/80 bg-slate-950/60 p-5"
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-xs font-black text-amber-400">
                    {idx + 1}
                  </span>
                  <div className="flex-1">
                    <h4 className="text-xs sm:text-sm font-bold text-slate-100 leading-relaxed">
                      {q.text}
                    </h4>

                    {/* Options */}
                    <div className="mt-3 grid gap-2 sm:grid-cols-2">
                      {q.options.map((opt, optIdx) => {
                        const isChosen = userAnswer === optIdx;
                        let optionStyle =
                          "border-slate-800 bg-slate-900/80 text-slate-300 hover:border-slate-700 hover:bg-slate-800";

                        if (isChosen && !isSubmitted) {
                          optionStyle =
                            "border-amber-500 bg-amber-500/15 text-amber-300 font-bold";
                        } else if (isSubmitted) {
                          if (optIdx === q.correctIndex) {
                            optionStyle =
                              "border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold";
                          } else if (isChosen && optIdx !== q.correctIndex) {
                            optionStyle =
                              "border-red-500 bg-red-500/20 text-red-300 line-through";
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            type="button"
                            onClick={() => handleSelectOption(q.id, optIdx)}
                            className={`flex items-center gap-2 rounded-xl border p-3 text-right text-xs transition ${optionStyle}`}
                          >
                            <span className="h-2 w-2 rounded-full border border-current flex-shrink-0" />
                            <span>{opt}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation if submitted */}
                    {isSubmitted && (
                      <div className="mt-4 rounded-xl border border-slate-800 bg-slate-900 p-3.5 text-xs leading-relaxed text-slate-300">
                        <div className="flex items-center gap-2 font-bold mb-1">
                          {isCorrect ? (
                            <span className="text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 className="h-4 w-4" /> پاسخ صحیح است
                            </span>
                          ) : (
                            <span className="text-red-400 flex items-center gap-1">
                              <XCircle className="h-4 w-4" /> پاسخ نادرست
                            </span>
                          )}
                        </div>
                        <p className="text-slate-400">
                          <strong className="text-amber-400">شرح استاد:</strong> {q.explanation}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Submit or Score Banner */}
        <div className="mt-8 border-t border-slate-800 pt-6">
          {!isSubmitted ? (
            <div className="flex justify-end">
              <button
                onClick={handleFinishQuiz}
                disabled={Object.keys(selectedAnswers).length === 0}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-3 text-xs sm:text-sm font-bold text-slate-950 shadow-lg shadow-amber-500/20 transition hover:from-amber-400 hover:to-amber-500 disabled:opacity-50"
              >
                <span>مشاهده نتایج و تحلیل استاد</span>
                <Check className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 p-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 font-black text-lg">
                    <Trophy className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white">
                      امتیاز شما: {score} از {session.questions.length}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {score === session.questions.length
                        ? "فوق‌العاده! شما مدار قوانین الهی را با عمق جان درک کرده‌اید."
                        : "خوب است! نکات و شرح هر سوال را مجدداً مرور فرمایید."}
                    </p>
                  </div>
                </div>

                <button
                  onClick={resetQuiz}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>آزمون مجدد</span>
                </button>
              </div>

              {/* Save submission form */}
              {!savedSuccess ? (
                <form
                  onSubmit={handleSaveResult}
                  className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-800/80 pt-4"
                >
                  <input
                    type="text"
                    placeholder="نام یا نام‌خانوادگی خود را وارد کنید..."
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    required
                    className="flex-1 rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400"
                  >
                    ثبت نتیجه در جدول شاگردان
                  </button>
                </form>
              ) : (
                <div className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs font-bold text-emerald-300">
                  نتیجه شما با موفقیت در سامانه ثبت شد!
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Leaderboard / Recent participants */}
      {recentSubmissions.length > 0 && (
        <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-900/50 p-6">
          <h4 className="text-xs font-bold text-amber-400 mb-3">
            نتایج ثبت‌شده اخیر توسط جویندگان حقیقت:
          </h4>
          <div className="grid gap-2 sm:grid-cols-3">
            {recentSubmissions.slice(0, 6).map((sub) => (
              <div
                key={sub.id}
                className="flex items-center justify-between rounded-xl border border-slate-800/80 bg-slate-950/50 p-3 text-xs"
              >
                <div>
                  <span className="font-bold text-white block">{sub.userName}</span>
                  <span className="text-[11px] text-slate-400">{sub.sessionName}</span>
                </div>
                <div className="rounded-lg bg-amber-500/15 px-2 py-1 font-black text-amber-400">
                  {sub.score} / {sub.totalQuestions}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
