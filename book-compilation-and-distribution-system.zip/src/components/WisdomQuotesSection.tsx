"use client";

import React, { useState } from "react";
import { WISDOM_QUOTES, WisdomQuote } from "@/data/quotesData";
import { Quote, Copy, Check, Share2, Sparkles } from "lucide-react";

export function WisdomQuotesSection() {
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<string>("all");

  const topics = ["all", "قانون فرکانس", "هنر رهایی", "عدم وابستگی", "ایمان به غیب", "شکرگزاری", "باور فراوانی", "قانون اعراض"];

  const filtered = WISDOM_QUOTES.filter(
    (q) => selectedTopic === "all" || q.topic === selectedTopic
  );

  const handleCopy = (quote: WisdomQuote) => {
    const text = `«${quote.text}»\n— ${quote.author} (مبحث ${quote.topic})`;
    navigator.clipboard.writeText(text);
    setCopiedId(quote.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <div className="mb-8 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
          <Sparkles className="h-3.5 w-3.5 text-amber-400" />
          <span>کارت‌های حکمت روزانه و جملات زرین استاد باستین</span>
        </div>
        <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          جرعه‌های نور برای بازتنظیم فوری فرکانس
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-slate-400">
          گزیده‌ای از اثرگذارترین عبارات جلسات رسمی برای تأمل، نشر و بازنشر
        </p>
      </div>

      {/* Topics pills */}
      <div className="mb-6 flex flex-wrap gap-1.5 justify-center">
        {topics.map((t) => (
          <button
            key={t}
            onClick={() => setSelectedTopic(t)}
            className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
              selectedTopic === t
                ? "bg-amber-500 text-slate-950 font-bold"
                : "border border-slate-800 bg-slate-900 text-slate-400 hover:text-white"
            }`}
          >
            {t === "all" ? "تمام موضوعات" : t}
          </button>
        ))}
      </div>

      {/* Quotes Cards Grid */}
      <div className="grid gap-4 sm:grid-cols-2">
        {filtered.map((quote) => (
          <div
            key={quote.id}
            className="relative flex flex-col justify-between rounded-3xl border border-slate-800 bg-gradient-to-b from-slate-900/80 to-slate-950 p-6 shadow-xl transition-all hover:border-amber-500/40"
          >
            <div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <span className="rounded-md bg-amber-500/15 px-2.5 py-0.5 text-[11px] font-bold text-amber-400">
                  {quote.topic}
                </span>
                {quote.verse && (
                  <span className="text-[11px] text-slate-400 font-medium">
                    سوره {quote.verse}
                  </span>
                )}
              </div>

              <div className="my-4">
                <Quote className="h-5 w-5 text-amber-500/40 mb-2" />
                <p className="text-xs sm:text-sm font-bold leading-loose text-white text-justify">
                  {quote.text}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-slate-800/80 pt-3 text-xs text-slate-400">
              <span className="font-semibold text-amber-300">{quote.author}</span>
              <button
                onClick={() => handleCopy(quote)}
                className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1 text-[11px] font-bold text-slate-300 transition hover:bg-slate-800 hover:text-amber-400"
              >
                {copiedId === quote.id ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-400" />
                    <span>کپی شد</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" />
                    <span>کپی کارت</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
