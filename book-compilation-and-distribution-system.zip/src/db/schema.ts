import { pgTable, serial, text, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  frequencyFocus: text("frequency_focus").notNull(), // e.g. "فراوانی", "شکرگزاری", "اعراض", "ایمان به غیب"
  gratitudeItems: jsonb("gratitude_items").$type<string[]>(),
  moodRating: integer("mood_rating").default(5),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const quizSubmissions = pgTable("quiz_submissions", {
  id: serial("id").primaryKey(),
  userName: text("user_name").notNull(),
  sessionName: text("session_name").notNull(),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  userAnswers: jsonb("user_answers").$type<Record<string, number>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const readingBookmarks = pgTable("reading_bookmarks", {
  id: serial("id").primaryKey(),
  pageNumber: integer("page_number").notNull(),
  chapterId: integer("chapter_id").notNull(),
  title: text("title").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const communityReflections = pgTable("community_reflections", {
  id: serial("id").primaryKey(),
  authorName: text("author_name").notNull(),
  countryOrCity: text("country_or_city").default("جهانی"),
  message: text("message").notNull(),
  favoriteQuote: text("favorite_quote"),
  isApproved: boolean("is_approved").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type JournalEntry = typeof journalEntries.$inferSelect;
export type QuizSubmission = typeof quizSubmissions.$inferSelect;
export type ReadingBookmark = typeof readingBookmarks.$inferSelect;
export type CommunityReflection = typeof communityReflections.$inferSelect;
