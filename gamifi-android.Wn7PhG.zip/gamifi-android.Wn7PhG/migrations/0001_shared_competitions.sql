-- Additive only: preserve all existing questions, accounts, tribes and tournaments.
CREATE TABLE IF NOT EXISTS shared_competitions (
  id text PRIMARY KEY,
  kind text NOT NULL CHECK (kind IN ('league', 'event')),
  title text NOT NULL,
  category text NOT NULL REFERENCES categories(id),
  org_id text NOT NULL DEFAULT '',
  starts_at bigint NOT NULL,
  ends_at bigint NOT NULL,
  question_count integer NOT NULL DEFAULT 7 CHECK (question_count BETWEEN 1 AND 100),
  seconds integer NOT NULL DEFAULT 25 CHECK (seconds BETWEEN 5 AND 120),
  active boolean NOT NULL DEFAULT true,
  created_by text NOT NULL REFERENCES users(id),
  created_at bigint NOT NULL,
  CHECK (ends_at > starts_at)
);
CREATE INDEX IF NOT EXISTS shared_competitions_kind_org ON shared_competitions(kind, org_id, starts_at);
