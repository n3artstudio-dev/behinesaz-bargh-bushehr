CREATE TABLE IF NOT EXISTS story_views (
  story_id text NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  viewed_at bigint NOT NULL,
  PRIMARY KEY (story_id, user_id)
);
CREATE INDEX IF NOT EXISTS story_views_user ON story_views(user_id, story_id);
CREATE INDEX IF NOT EXISTS stories_active_expiry ON stories(status, expires_at, created_at);
