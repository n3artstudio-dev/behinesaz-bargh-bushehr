CREATE TABLE IF NOT EXISTS account_passwords(user_id text PRIMARY KEY REFERENCES users(id), password_hash text NOT NULL, failed_attempts integer NOT NULL DEFAULT 0, locked_until bigint NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS account_logins(identifier text PRIMARY KEY, user_id text NOT NULL REFERENCES users(id),kind text NOT NULL);
CREATE INDEX IF NOT EXISTS account_logins_user ON account_logins(user_id);
