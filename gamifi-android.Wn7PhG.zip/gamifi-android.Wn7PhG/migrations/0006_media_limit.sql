ALTER TABLE post_media DROP CONSTRAINT IF EXISTS post_media_duration_check;
ALTER TABLE post_media ADD CONSTRAINT post_media_duration_check CHECK(duration > 0 AND duration <= 60);
