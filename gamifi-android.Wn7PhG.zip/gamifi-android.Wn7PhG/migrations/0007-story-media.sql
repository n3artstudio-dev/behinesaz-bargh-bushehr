CREATE TABLE IF NOT EXISTS story_media (
 id text PRIMARY KEY, story_id text NOT NULL REFERENCES stories(id),
 owner_id text NOT NULL REFERENCES users(id), filename text NOT NULL,
 mime text NOT NULL, bytes bigint NOT NULL, duration double precision NOT NULL CHECK(duration>0 AND duration<=60), created_at bigint NOT NULL
);
CREATE INDEX IF NOT EXISTS story_media_story_idx ON story_media(story_id);