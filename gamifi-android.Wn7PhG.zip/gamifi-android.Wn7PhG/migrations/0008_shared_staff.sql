-- Add shared identities for the existing six staff characters, never a real user.
-- Existing account IDs, scores, memberships and content are not modified.
INSERT INTO users(id,name,avatar,bio,provider,role,is_demo,banned,created_at,extra)
SELECT 'server-staff-' || n, name, jsonb_build_object('seed',n,'img',n),
       'کادر رایانه‌ای گیمیفای', 'bot', 'player', true, false,
       (extract(epoch FROM clock_timestamp())*1000)::bigint,
       '{"sharedStaff":true}'::jsonb
FROM (VALUES (1,'سارا مهندس'),(2,'امید رهنما'),(3,'مریم دانش'),
             (4,'علی پیشرو'),(5,'زهرا نوری'),(6,'محمد آزما')) AS staff(n,name)
ON CONFLICT (id) DO NOTHING;
