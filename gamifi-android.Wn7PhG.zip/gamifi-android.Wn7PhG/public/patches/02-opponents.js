(function(root){
  'use strict';
  root.__gamifyPickOpponents=function(players,me,visible,limit){
    var time=Date.now(),interests=(me&&me.interests)||[];
    var candidates=(players||[]).filter(function(p){return p&&p.id!==(me&&me.id)&&!p.banned&&visible(p);});
    function real(p){return p.isReal===true||p.kind==='real';}
    function online(p){return p.online===true&&time-Number(p.lastSeen||0)<120000;}
    function overlap(p){return (p.interests||[]).filter(function(c){return interests.indexOf(c)>=0;}).length;}
    var humans=candidates.filter(function(p){return real(p)&&online(p);});
    humans.sort(function(a,b){return overlap(b)-overlap(a)||Number(b.lastSeen||0)-Number(a.lastSeen||0)||String(a.id).localeCompare(String(b.id));});
    var bots=candidates.filter(function(p){return !real(p)&&(p.kind==='staff'||p.kind==='bot'||p.kind==='member');});
    bots.sort(function(a,b){return Number(b.lastSeen||0)-Number(a.lastSeen||0);});
    return humans.concat(bots).slice(0,limit||6);
  };
})(window);
