/* 📋 پنل زندهٔ مدیر: تأیید/ویرایش پست و استوری + دیدن کاربران — بدون اخلال در اتوماسیون */
(function () {
  "use strict";
  if (window.__gamifyModeration) return;
  window.__gamifyModeration = true;

  var LS_KEY = "gamify2-store-v2";
  var overlay = null;
  var isAdmin = false;
  var serverAdmin = false;
  var state = { tab: "posts", posts: [], stories: [], users: [], overview: null, loading: "" };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function timeAgo(t) {
    var d = Date.now() - (t || 0);
    if (d < 60000) return "لحظاتی پیش";
    if (d < 3600000) return fa(Math.floor(d / 60000)) + " دقیقه پیش";
    if (d < 86400000) return fa(Math.floor(d / 3600000)) + " ساعت پیش";
    return fa(Math.floor(d / 86400000)) + " روز پیش";
  }

  function toast(msg) {
    var d = document.createElement("div");
    d.textContent = msg;
    d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:101999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;border:1px solid #7cd7b6;font-family:Vazirmatn,sans-serif;max-width:min(92vw,400px);";
    document.body.appendChild(d);
    setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
  }

  function headers() {
    var h = { "Content-Type": "application/json" };
    try { var at = localStorage.getItem("gamify2-admin-token"); if (at) h["x-admin-token"] = at; } catch (e) {}
    return h;
  }

  function checkAdmin() {
    var st = readStore();
    var local = !!(st && (st.admin === true || (st.profile && st.profile.role === "admin")));
    if (local) { isAdmin = true; mountFab(); }
    // سرور هم چک شود
    fetch("/api/me", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (me) {
      if (me && me.role === "admin") { serverAdmin = true; isAdmin = true; mountFab(); }
      updateBadge();
    }).catch(function () {});
    return local;
  }

  function updateBadge() {
    var fab = document.getElementById("gamify-mod-fab");
    if (!fab || !isAdmin) return;
    fetch("/api/moderation", { credentials: "include", headers: headers() }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || j.error) {
        // فقط محلی‌ها را بشمار
        var st = readStore();
        var n = st ? ((st.posts || []).filter(function (p) { return p.status === "pending"; }).length + (st.stories || []).filter(function (s) { return s.status === "pending"; }).length) : 0;
        fab.innerHTML = "📋" + (n ? '<span class="gamify-fab-badge">' + fa(n) + "</span>" : "");
        return;
      }
      var total = (j.posts || []).length + (j.stories || []).length;
      fab.innerHTML = "📋" + (total ? '<span class="gamify-fab-badge">' + fa(total) + "</span>" : "");
    }).catch(function () {});
  }

  function refresh() {
    state.loading = "در حال دریافت صف زنده…";
    render();
    var jobs = [];
    jobs.push(fetch("/api/moderation", { credentials: "include", headers: headers() }).then(function (r) { return r.json(); }).then(function (j) {
      if (j && !j.error) { state.posts = j.posts || []; state.stories = j.stories || []; }
      else { state.posts = []; state.stories = []; }
    }).catch(function () { state.posts = []; state.stories = []; }));
    if (state.tab === "users" || state.tab === "overview") {
      jobs.push(fetch("/api/admin?" + (state.tab === "users" ? "view=users" : "view=overview"), { credentials: "include", headers: headers() }).then(function (r) { return r.json(); }).then(function (j) {
        if (state.tab === "users") state.users = Array.isArray(j) ? j : [];
        else state.overview = j && !j.error ? j : null;
      }).catch(function () {}));
    }
    return Promise.all(jobs).then(function () { state.loading = ""; render(); updateBadge(); });
  }

  function decide(kind, id, status) {
    // ۱) سرور
    fetch("/api/moderation?action=decide", { method: "POST", credentials: "include", headers: headers(), body: JSON.stringify({ kind: kind, id: id, status: status }) }).catch(function(){});
    // ۲) محلی (بازی اصلی) — همان لحظه اعمال شود
    try {
      var st = readStore();
      if (st) {
        var changed = false;
        if (kind === "post") (st.posts || []).forEach(function (p) { if (String(p.id) === String(id)) { p.status = status; changed = true; } });
        else (st.stories || []).forEach(function (s) { if (String(s.id) === String(id)) { s.status = status; changed = true; } });
        if (changed) localStorage.setItem(LS_KEY, JSON.stringify(st));
      }
    } catch (e) {}
    toast(status === "approved" ? "✅ منتشر شد" : "🗑️ رد شد");
    setTimeout(refresh, 600);
  }

  function editItem(kind, id) {
    var current = "";
    try {
      var st = readStore();
      if (kind === "post") {
        var srv = state.posts.filter(function (p) { return String(p.id) === String(id); })[0];
        current = srv ? srv.body : ((st.posts || []).filter(function (p) { return String(p.id) === String(id); })[0] || {}).body || "";
      } else {
        var srv2 = state.stories.filter(function (s) { return String(s.id) === String(id); })[0];
        current = srv2 ? (srv2.title + "\n\n— گزینه‌ها: " + (srv2.options || []).join(" / ")) : "";
      }
    } catch (e) {}
    var next = prompt(kind === "post" ? "✏️ ویرایش متن پست:" : "✏️ ویرایش عنوان استوری (سطر اول):", current);
    if (next == null) return;
    var body = kind === "post" ? { kind: kind, id: id, status: "approved", body: next.slice(0, 4000) } : { kind: kind, id: id, status: "approved", title: next.split("\n")[0].slice(0, 500) };
    fetch("/api/moderation?action=edit", { method: "POST", credentials: "include", headers: headers(), body: JSON.stringify(body) }).then(function () {
      try {
        var st2 = readStore();
        if (st2) {
          if (kind === "post") (st2.posts || []).forEach(function (p) { if (String(p.id) === String(id)) p.body = next.slice(0, 4000); });
          else (st2.stories || []).forEach(function (s) { if (String(s.id) === String(id)) s.title = next.split("\n")[0].slice(0, 500); });
          localStorage.setItem(LS_KEY, JSON.stringify(st2));
        }
      } catch (e) {}
      toast("✏️ ویرایش ذخیره شد");
      setTimeout(refresh, 600);
    });
  }

  function userAction(action, userId, userName) {
    if (action === "ban" && !confirm("کاربر «" + userName + "» بن شود؟")) return;
    fetch("/api/admin?action=" + action, { method: "POST", credentials: "include", headers: headers(), body: JSON.stringify({ userId: userId }) }).then(function () {
      toast("✅ انجام شد");
      setTimeout(refresh, 600);
    });
  }

  // ---------- رندر ----------
  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.id = "gamify-mod-overlay";
    overlay.className = "gamify-overlay";
    document.body.appendChild(overlay);
    return overlay;
  }
  function close() { if (overlay) overlay.classList.remove("open"); }
  function open() {
    if (!isAdmin) { toast("⚠️ فقط مدیر"); return; }
    ensureOverlay().classList.add("open");
    refresh();
  }

  function localPending() {
    var st = readStore();
    var lp = [], ls = [];
    if (st) {
      lp = (st.posts || []).filter(function (p) { return p && p.status === "pending"; }).map(function (p) {
        return { id: p.id, userName: p.author || "کاربر", body: p.body, media: p.media || p.image, category: p.category, createdAt: p.at, local: true };
      });
      ls = (st.stories || []).filter(function (s) { return s && s.status === "pending"; }).map(function (s) {
        return { id: s.id, userName: s.author || "کاربر", title: s.title, media: s.media || s.image, options: s.options, category: s.category, createdAt: s.at, local: true };
      });
    }
    // سرور را هم اضافه کن (تکراری‌ها را حذف کن)
    var srvP = state.posts.filter(function (p) { return !lp.some(function (x) { return String(x.id) === String(p.id); }); });
    var srvS = state.stories.filter(function (s) { return !ls.some(function (x) { return String(x.id) === String(s.id); }); });
    return { posts: lp.concat(srvP), stories: ls.concat(srvS) };
  }

  function mediaPreview(value) {
    var v=String(value||'');
    if(/^\/api\/story-media\/v[a-f0-9]{12}$/.test(v))return '<video controls playsinline preload="metadata" style="max-width:100%;max-height:360px" src="'+v+'"></video>';
    if(!/^(https?:\/\/|\/(?!\/)|data:image\/(png|jpeg|jpg|gif|webp|avif);)/i.test(v)) return '';
    var src=esc(v).replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    return '<img loading="lazy" referrerpolicy="no-referrer" alt="پیش‌نمایش تصویر ارسالی" style="display:block;max-width:100%;max-height:360px;object-fit:contain;margin:12px auto;border-radius:12px" src="'+src+'">';
  }
  function postsHtml() {
    var all = localPending().posts;
    if (!all.length) return '<div class="gamify-empty">🎉 صف پست خالی است؛ همه‌چیز تأیید شده!</div>';
    return all.map(function (p) {
      return '<div class="gamify-mod-card"><div class="gamify-mod-head"><b>' + esc(p.userName || "کاربر") + "</b><span>" + (p.local ? "💾 محلی" : "☁️ سرور") + " · " + esc(p.category || "") + " · " + timeAgo(p.createdAt) + "</span></div>" +
        '<p class="gamify-mod-body">' + esc(p.body || "").slice(0, 600) + "</p>" +
        (p.media && /^\/api\/post-media\/v[a-f0-9]{12}$/.test(p.media) ? '<video controls playsinline preload="metadata" style="max-width:100%;max-height:260px" src="' + esc(p.media) + '"></video>' : p.media ? mediaPreview(p.media) : "") +
        '<div class="gamify-row"><button class="gamify-btn sm primary" data-ok="post:' + esc(p.id) + '">✅ تأیید و انتشار</button><button class="gamify-btn sm" data-edit="post:' + esc(p.id) + '">✏️ ویرایش</button><button class="gamify-btn sm danger" data-no="post:' + esc(p.id) + '">🗑️ رد</button></div></div>';
    }).join("");
  }

  function storiesHtml() {
    var all = localPending().stories;
    if (!all.length) return '<div class="gamify-empty">🎉 صف استوری خالی است!</div>';
    return all.map(function (s) {
      var opts = (s.options || []).map(function (o, i) { return "<li>" + (i === s.correct ? "✅ " : "") + esc(o) + "</li>"; }).join("");
      return '<div class="gamify-mod-card"><div class="gamify-mod-head"><b>' + esc(s.userName || "کاربر") + "</b><span>" + (s.local ? "💾 محلی" : "☁️ سرور") + " · " + esc(s.category || "") + " · " + timeAgo(s.createdAt) + "</span></div>" +
        '<p class="gamify-mod-body"><b>❓ ' + esc(s.title || "") + "</b></p>" + (opts ? "<ol class='gamify-mod-opts'>" + opts + "</ol>" : "") +
        mediaPreview(s.media || s.image) +
        (s.explanation ? '<p style="font-size:12px;opacity:.8;">💡 ' + esc(s.explanation).slice(0, 300) + "</p>" : "") +
        '<div class="gamify-row"><button class="gamify-btn sm primary" data-ok="story:' + esc(s.id) + '">✅ تأیید و انتشار</button><button class="gamify-btn sm" data-edit="story:' + esc(s.id) + '">✏️ ویرایش</button><button class="gamify-btn sm danger" data-no="story:' + esc(s.id) + '">🗑️ رد</button></div></div>';
    }).join("");
  }

  function usersHtml() {
    if (!state.users.length) return '<div class="gamify-empty">کاربری در سرور ثبت نشده یا دسترسی نداری.<br><small>کاربران پس از ورود/همگام‌سازی اینجا دیده می‌شوند.</small></div>';
    var online = state.users.filter(function (u) { return u.online; }).length;
    return '<div class="gamify-mod-head" style="margin-bottom:10px;"><b>👥 ' + fa(state.users.length) + " کاربر</b><span>🟢 " + fa(online) + " آنلاین</span></div>" +
      state.users.slice(0, 80).map(function (u) {
        return '<div class="gamify-rank"><b>' + (u.online ? "🟢" : "⚪") + " " + esc(u.name) + (u.role === "admin" ? " 👑" : "") + '</b><span>⭐ ' + fa(u.xp) + " · 🏢 " + esc(u.orgId || "آزاد") + " · " + timeAgo(u.lastSeen) + "</span>" +
          '<span class="gamify-tribe-acts"><button class="gamify-btn sm" data-uadmin="' + esc(u.id) + '" data-name="' + esc(u.name) + '">👑 ادمین</button><button class="gamify-btn sm danger" data-uban="' + esc(u.id) + '" data-name="' + esc(u.name) + '">⛔ بن</button></span></div>';
      }).join("");
  }

  function overviewHtml() {
    if (!state.overview) return '<div class="gamify-empty">داده‌ای نیست.</div>';
    var s = state.overview.stats || {};
    var cards = [["👥 کاربران", s.totalUsers], ["🟢 آنلاین", s.onlineUsers], ["🛡️ قبیله‌ها", s.totalTribes], ["📝 پست منتظر", s.pendingPosts], ["📸 استوری منتظر", s.pendingStories], ["🏆 تورنمنت‌ها", s.totalTournaments], ["⚔️ نبرد فعال", s.activeBattles]]
      .map(function (c) { return '<div class="gamify-stat-card"><b>' + fa(c[1] || 0) + "</b><small>" + c[0] + "</small></div>"; }).join("");
    var recent = (state.overview.recentUsers || []).map(function (u) {
      return '<div class="gamify-rank"><b>' + (u.online ? "🟢" : "⚪") + " " + esc(u.name) + "</b><span>" + timeAgo(u.lastSeen) + "</span></div>";
    }).join("");
    return '<div class="gamify-stat-grid">' + cards + "</div><h3>🕒 آخرین بازدیدها</h3>" + (recent || "—") +
      '<p class="gamify-hint">🤖 اتوماسیون (ربات مدیر) سر جایش است؛ تأیید دستی تو فقط روی مواردی که می‌بینی اثر می‌گذارد و خللی در انتشار خودکار ایجاد نمی‌کند.</p>';
  }

  function render() {
    if (!overlay || !overlay.classList.contains("open")) return;
    var tabs = [["posts", "📝 پست‌ها"], ["stories", "📸 استوری‌ها"], ["users", "👥 کاربران"], ["overview", "📊 نمای کلی"]];
    var body = state.tab === "posts" ? postsHtml() : state.tab === "stories" ? storiesHtml() : state.tab === "users" ? usersHtml() : overviewHtml();
    overlay.innerHTML = '<div class="gamify-modal wide"><div class="gamify-modal-head"><b>📋 پنل زندهٔ مدیر</b><span><button class="gamify-btn sm" data-act="refresh">🔄 تازه‌سازی</button> <button data-act="close">✕</button></span></div>' +
      '<div class="gamify-tabs">' + tabs.map(function (t) { return '<button data-tab="' + t[0] + '" class="' + (state.tab === t[0] ? "active" : "") + '">' + t[1] + "</button>"; }).join("") + "</div>" +
      (state.loading ? '<div class="gamify-loading">' + esc(state.loading) + "</div>" : "") +
      '<div class="gamify-body">' + body + "</div>" +
      '<p class="gamify-hint">🟢 زنده: هر ۱۵ ثانیه خودکار تازه می‌شود · 💾 محلی = داخل مرورگر کاربر · ☁️ سرور = آینهٔ سرور</p></div>';
    overlay.querySelectorAll("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { state.tab = b.getAttribute("data-tab"); refresh(); }); });
    overlay.querySelectorAll('[data-act="close"]').forEach(function (b) { b.addEventListener("click", close); });
    overlay.querySelectorAll('[data-act="refresh"]').forEach(function (b) { b.addEventListener("click", refresh); });
    overlay.querySelectorAll("[data-ok]").forEach(function (b) { b.addEventListener("click", function () { var p = b.getAttribute("data-ok").split(/:(.+)/); decide(p[0], p[1], "approved"); }); });
    overlay.querySelectorAll("[data-no]").forEach(function (b) { b.addEventListener("click", function () { var p = b.getAttribute("data-no").split(/:(.+)/); decide(p[0], p[1], "rejected"); }); });
    overlay.querySelectorAll("[data-edit]").forEach(function (b) { b.addEventListener("click", function () { var p = b.getAttribute("data-edit").split(/:(.+)/); editItem(p[0], p[1]); }); });
    overlay.querySelectorAll("[data-uban]").forEach(function (b) { b.addEventListener("click", function () { userAction("ban", b.getAttribute("data-uban"), b.getAttribute("data-name")); }); });
    overlay.querySelectorAll("[data-uadmin]").forEach(function (b) { b.addEventListener("click", function () { userAction("make-admin", b.getAttribute("data-uadmin"), b.getAttribute("data-name")); }); });
  }

  function mountFab() {
    if (document.getElementById("gamify-mod-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-mod-fab";
    b.textContent = "📋";
    b.title = "پنل زندهٔ مدیر";
    document.body.appendChild(b);
    b.addEventListener("click", open);
    updateBadge();
  }

  function boot() {
    checkAdmin();
    setInterval(checkAdmin, 8000);
    setInterval(updateBadge, 20000);
    setInterval(function () { if (overlay && overlay.classList.contains("open")) refresh(); }, 15000);
    document.addEventListener("click", function (e) { if (overlay && e.target === overlay) close(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && overlay) close(); });
    console.log("%c[gamify] moderation فعال شد ✅", "color:#7cd7b6");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
// SUPPORT-SYNC-START — دست نزن؛ این بلوک را اسکریپت نصب (apply-support-sync.sh) از نو می‌سازد
/* ================= پشتیبانی زندهٔ گیمیفای (نسخهٔ ۱) =================
   مشکل: «ارتباط با مدیر» (تیکت) و «کارخانهٔ سؤال» (پیشنهاد سؤال) فقط در مرورگر
   خودِ کاربر ذخیره می‌شدند؛ هیچ‌وقت به سرور نمی‌رفتند. یعنی مدیر پیام‌ها را
   نمی‌دید و پاسخ هم دست کاربر نمی‌رسید.

   این قطعه:
     ۱) پیام‌های «ارتباط با مدیر» را روی سرور می‌گذارد (از همان مسیر استوری که
        خودِ بازی دارد — بدون rebuild، بدون ری‌استارت).
     ۲) پیشنهاد سؤال‌های «کارخانهٔ سؤال» را هم روی سرور می‌گذارد.
     ۳) برای مدیر یک پنل شیشه‌ای «📮 پشتیبانی» می‌سازد: فهرست پیام‌ها با کادر پاسخ،
        و فهرست پیشنهاد سؤال‌ها با دکمهٔ «✅ تأیید و افزودن به بانک» و «رد».
     ۴) پاسخ مدیر → به‌صورت اعلان واقعی + متن پاسخ در همان صفحهٔ «ارتباط با مدیر»
        برای خودِ کاربر می‌نشیند (حتی روی دستگاه دیگر).
     ۵) سؤال تأییدشده → *در همان لحظه* برای همهٔ کاربران در «بانک سؤال» می‌نشیند
        (بدون انتشار دستی بانک) و به پیشنهاددهنده ۳۰ سکه + اعلان داده می‌شود.

   نکته‌های مهم:
     • رکوردهای فنی با شناسهٔ __eng- شناخته می‌شوند و در فید/استوری کاربران
       نمایش داده نمی‌شوند (فیلترهای 15-realtime.js).
     • برای رسیدن پیام کاربر عادی به سرور، تنظیم «بررسی استوری» باید خاموش باشد:
         node /root/social-sync/social-tool.cjs moderation story off
       (اگر روشن باشد، رکورد در صف تأیید می‌مانَد و به مدیر نمی‌رسد.)
     • این قطعه و بستهٔ لایک/کامنت و بستهٔ نبرد پلاس یک فایل مشترک ندارند؛
       اما هر کدام را rollback کردی، فقط خودش برمی‌گردد.
   ==================================================================== */
(function () {
  try {
    if (window.__gamifySupportSync) return;
    window.__gamifySupportSync = true;

    var LS = "gamify2-store-v2";            // استور خود بازی
    var SENT = "gamify2-support-sent";      // رکوردهایی که من روی سرور گذاشتم
    var SEEN = "gamify2-support-seen";      // رکوردهای سروری که یک‌بار واکنش دادم
    var PREFIX = "__eng-";
    var PUSH_MS = 6000;                     // فاصلهٔ ارسال‌های من
    var POLL_MS = 8000;                     // فاصلهٔ خواندن از سرور
    var TICKETS_PER_HOUR = 6;               // سقف پیام به مدیر در هر ساعت
    var SUGGEST_PER_DAY = 6;                // سقف پیشنهاد سؤال در هر روز
    var ADMIN_FALLBACK_CODE = "";           // (لازم نیست؛ حساب مدیر از role تشخیص داده می‌شود)

    var meCache = { at: 0, id: "", name: "", role: "" };
    var lastToast = {};
    var busyPush = false, busyPull = false;
    var booted = false;

    /* ================= ابزارهای پایه ================= */
    function norm(t) {
      return String(t || "").replace(/[\s\u200c]+/g, " ").replace(/[يى]/g, "ی").replace(/ك/g, "ک").trim().toLowerCase();
    }
    function readStore() {
      try {
        if (typeof window.__gamifyLiveGet === "function") {
          var s = window.__gamifyLiveGet();
          if (s && typeof s === "object") return s;
        }
      } catch (e) {}
      try { return JSON.parse(localStorage.getItem(LS) || "null"); } catch (e) { return null; }
    }
    function writeStore(fn) {
      var ok = false;
      try {
        if (typeof window.__gamifyLiveSet === "function") { window.__gamifyLiveSet(fn); ok = true; }
      } catch (e) { ok = false; }
      try {
        var raw = localStorage.getItem(LS);
        if (raw) {
          var s = JSON.parse(raw) || {};
          localStorage.setItem(LS, JSON.stringify(fn(s)));
          ok = true;
        }
      } catch (e) {}
      return ok;
    }
    function readMap(key) { try { return JSON.parse(localStorage.getItem(key) || "{}") || {}; } catch (e) { return {}; } }
    function writeMap(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) {} }
    function toast(msg) {
      try { if (typeof window.__gamifyToast === "function") { window.__gamifyToast(msg); return; } } catch (e) {}
      try {
        var d = document.createElement("div");
        d.className = "gamify-toast";
        d.textContent = msg;
        d.style.cssText = "position:fixed;z-index:99999;bottom:22px;right:22px;background:#2c2039;color:#fff;border:1px solid #a98cf7;border-radius:14px;padding:10px 14px;font:600 13px Tahoma;box-shadow:0 8px 30px #0008";
        document.body.appendChild(d);
        setTimeout(function () { d.style.opacity = "0"; d.style.transition = "opacity .4s"; setTimeout(function () { d.remove(); }, 450); }, 3200);
      } catch (e) {}
    }
    function toastOnce(key, msg) {
      var t = Date.now();
      if (lastToast[key] && t - lastToast[key] < 60000) return;
      lastToast[key] = t;
      toast(msg);
    }
    function api(path, method, body) {
      var o = { method: method || "GET", credentials: "include", headers: {} };
      if (body !== undefined) { o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body); }
      return fetch(path, o).then(function (r) { return r.json().catch(function () { return null; }); }).catch(function () { return null; });
    }
    function nowMs() { return Date.now(); }

    /* ================= هویت من (از سرور) ================= */
    function myServerId() {
      try {
        if (window.__gamifyServer && typeof window.__gamifyServer.getServerId === "function") {
          var id = window.__gamifyServer.getServerId();
          if (id) return String(id);
        }
      } catch (e) {}
      try {
        var m = JSON.parse(localStorage.getItem("gamify2-server") || "{}") || {};
        if (m.serverId) return String(m.serverId);
      } catch (e) {}
      var st = readStore();
      return (st && st.profile && st.profile.id) ? String(st.profile.id) : "";
    }
    function refreshMe(force) {
      if (!force && meCache.id && nowMs() - meCache.at < 60000) return Promise.resolve(meCache);
      return api("/api/me").then(function (j) {
        if (j && !j.error && j.id) meCache = { at: nowMs(), id: String(j.id), name: String(j.name || ""), role: String(j.role || "player") };
        return meCache;
      });
    }
    function isAdmin() { return meCache.role === "admin"; }

    /* ================= رسانهٔ رکوردها (JSON داخل استوری) ================= */
    function enc(obj) { try { return JSON.stringify(obj).slice(0, 3500); } catch (e) { return "{}"; } }
    function dec(s) { try { var o = JSON.parse(String(s || "")); return (o && typeof o === "object") ? o : null; } catch (e) { return null; } }
    var TITLES = {
      t: "پیام پشتیبانی", tr: "پاسخ پشتیبانی", s: "پیشنهاد سؤال",
      sa: "تأیید پیشنهاد سؤال", sr: "رد پیشنهاد سؤال"
    };
    function postCarrier(kind, key, data) {
      var rowId = PREFIX + kind + "-" + String(key).slice(0, 48);
      return api("/api/feed?type=story", "POST", {
        id: rowId, category: "general", title: TITLES[kind] || "پشتیبانی",
        options: [], correct: 0, explanation: "", media: enc(data)
      }).then(function (j) { return (j && !j.error) ? rowId : null; });
    }
    function rowsToCarriers(rows) {
      if (!Array.isArray(rows)) return [];
      var out = [];
      rows.forEach(function (r) {
          var id = String((r && r.id) || "");
          if (id.indexOf(PREFIX) !== 0) return;
          var m = id.slice(PREFIX.length).split("-")[0];               // t | tr | s | sa | sr
          if (!TITLES[m]) return;
          var data = dec(r.media);
          out.push({
            rowId: id, kind: m, data: data || {},
            userId: String(r.userId || ""), userName: String(r.userName || ""),
            at: Number(r.createdAt || 0) || 0, status: String(r.status || "")
          });
        });
      return out;
    }
    function readCarriers() {
      return api("/api/feed?type=stories").then(function (rows) { return rowsToCarriers(rows); });
    }
    /* پنل مدیر: اگر «بررسی استوری» روشن باشد، پیام کاربران در صف تأیید می‌مانَد؛
       این تابع صف را هم می‌خواند تا هیچ پیامی از چشم مدیر نیفتد. */
    function readCarriersForAdmin() {
      return api("/api/feed?type=pending").then(function (j) {
        var rows = (j && !j.error && Array.isArray(j.stories)) ? j.stories : [];
        return rowsToCarriers(rows);
      }).catch(function () { return []; });
    }
    /* شناسهٔ منطقی: برای tr-… و sa-… و sr-… همان شناسهٔ «موضوع» است */
    function subjectOf(row) { var p = row.rowId.slice(PREFIX.length); var i = p.indexOf("-"); return i < 0 ? p : p.slice(i + 1); }

    /* ================= ۱) فرستادن پیام‌های من به سرور ================= */
    function countIn(windowMs, kindPrefix) {
      var m = readMap(SENT), t = nowMs(), c = 0;
      Object.keys(m).forEach(function (k) {
        if (k.indexOf(kindPrefix) === 0 && t - Number(m[k] || 0) < windowMs) c++;
      });
      return c;
    }
    function markSent(key) { var m = readMap(SENT); m[key] = nowMs(); writeMap(SENT, m); }
    function hasSent(key) { var m = readMap(SENT); return !!m[key]; }

    function pumpTickets() {
      var st = readStore();
      if (!st || !Array.isArray(st.tickets) || !st.tickets.length) return Promise.resolve(0);
      var m = readMap(SENT), sent = 0, jobs = [];
      st.tickets.forEach(function (t) {
        if (!t || !t.id || t.__srv) return;                 // رکورد سروری را دوباره نمی‌فرستیم
        var key = "t-" + t.id;
        if (m[key]) return;
        if (countIn(3600000, "t-") >= TICKETS_PER_HOUR) { toastOnce("cap-t", "⏳ برای امروز چند پیام فرستادی؛ کمی بعد دوباره امتحان کن."); return; }
        jobs.push(postCarrier("t", t.id, { k: "t", sub: String(t.subject || "").slice(0, 120), body: String(t.body || "").slice(0, 1500), at: Number(t.at) || nowMs(), n: (st.profile && st.profile.name) || "" }).then(function (ok) {
          if (ok) { markSent(key); sent++; }
          else toastOnce("fail-t", "📡 پیامت به سرور نرسید؛ خودکار دوباره تلاش می‌شود.");
        }));
      });
      return Promise.all(jobs).then(function () { return sent; });
    }
    function pumpSuggestions() {
      var st = readStore();
      if (!st || !Array.isArray(st.suggestions) || !st.suggestions.length) return Promise.resolve(0);
      var m = readMap(SENT), sent = 0, jobs = [];
      st.suggestions.forEach(function (s) {
        if (!s || !s.id) return;
        var status = String(s.status || "pending");
        if (status !== "pending") return;                    // تأیید/ردشده را دوباره نمی‌فرستیم
        var key = "s-" + s.id;
        if (m[key]) return;
        var opts = Array.isArray(s.options) ? s.options.slice(0, 4) : [];
        if (opts.length !== 4 || String(s.title || "").length < 5) return;
        if (countIn(86400000, "s-") >= SUGGEST_PER_DAY) { toastOnce("cap-s", "⏳ سقف پیشنهاد امروز پر شد؛ فردا ادامه بده."); return; }
        jobs.push(postCarrier("s", s.id, {
          k: "s", cat: String(s.category || "general"), title: String(s.title).slice(0, 300),
          opts: opts.map(function (o) { return String(o).slice(0, 120); }),
          correct: Math.min(3, Math.max(0, Number(s.correct) || 0)),
          expl: String(s.explanation || "").slice(0, 600), at: Number(s.at) || nowMs(),
          n: (st.profile && st.profile.name) || ""
        }).then(function (ok) {
          if (ok) { markSent(key); sent++; }
          else toastOnce("fail-s", "📡 پیشنهاد سؤالت به سرور نرسید؛ خودکار دوباره تلاش می‌شود.");
        }));
      });
      return Promise.all(jobs).then(function () { return sent; });
    }

    /* ================= ۲) خواندن از سرور و نشاندن در بازی ================= */
    function ensureCategory(st, catId) {
      var cats = Array.isArray(st.customCategories) ? st.customCategories : [];
      if (!catId) return st;
      var exists = cats.some(function (c) { return c && String(c.id) === String(catId); });
      var builtin = ["safety", "power", "general", "science", "tech", "work", "earth", "sport", "geo", "history", "lit", "math", "astro", "art", "music", "cinema", "food"];
      if (exists || builtin.indexOf(String(catId)) >= 0) return st;
      return Object.assign({}, st, {
        customCategories: cats.concat([{ id: String(catId), name: String(catId), subtitle: "دستهٔ پیشنهاد کاربران", icon: "book", color: "#a98cf7", tag: "" }])
      });
    }
    function questionOfSuggestion(sid, d) {
      var opts = Array.isArray(d.opts) ? d.opts.slice(0, 4) : [];
      if (opts.length !== 4 || String(d.title || "").length < 5) return null;
      return {
        id: "sug-" + String(sid).slice(0, 40),
        category: String(d.cat || "general"),
        title: String(d.title).slice(0, 300),
        options: opts,
        correct: Math.min(3, Math.max(0, Number(d.correct) || 0)),
        explanation: String(d.expl || "").slice(0, 600),
        seconds: 15
      };
    }
    /* افزودن پرسش تأییدشده به «بانک سؤال» همه (در حافظهٔ همین صفحه) */
    function bankMerge(q) {
      try {
        var b = window.__gamifyBankData;
        if (!b || !Array.isArray(b.questions)) return false;
        var t = norm(q.title);
        var dup = b.questions.some(function (x) { return x && (String(x.id) === String(q.id) || norm(x.title) === t); });
        if (dup) return false;
        b.questions.push({ id: q.id, category: q.category, title: q.title, options: q.options.slice(0, 4), correct: q.correct, explanation: q.explanation, seconds: q.seconds, source: "پیشنهاد کاربر" });
        b.count = (Number(b.count) || 0) + 1;
        try { window.dispatchEvent(new CustomEvent("gamify-bank-updated", { detail: { questions: 1, categories: 0 } })); } catch (e) {}
        return true;
      } catch (e) { return false; }
    }
    function storeMerge(q) {
      return writeStore(function (s) {
        s = s || {};
        var custom = Array.isArray(s.custom) ? s.custom : [];
        var t = norm(q.title);
        var dup = custom.some(function (x) { return x && (String(x.id) === String(q.id) || norm(x.title) === t); });
        if (dup) return s;
        var ns = Object.assign({}, s, { custom: [q].concat(custom) });
        return ensureCategory(ns, q.category);
      });
    }
    function addTicketLocal(t) {
      return writeStore(function (s) {
        s = s || {};
        var list = Array.isArray(s.tickets) ? s.tickets : [];
        if (list.some(function (x) { return x && String(x.id) === String(t.id); })) return s;
        return Object.assign({}, s, { tickets: [t].concat(list) });
      });
    }
    function addSuggestionLocal(sg) {
      return writeStore(function (s) {
        s = s || {};
        var list = Array.isArray(s.suggestions) ? s.suggestions : [];
        if (list.some(function (x) { return x && String(x.id) === String(sg.id); })) return s;
        return Object.assign({}, s, { suggestions: [sg].concat(list) });
      });
    }
    function patchTicket(tid, patch) {
      return writeStore(function (s) {
        s = s || {};
        var list = Array.isArray(s.tickets) ? s.tickets : [];
        return Object.assign({}, s, {
          tickets: list.map(function (t) { return (t && String(t.id) === String(tid)) ? Object.assign({}, t, patch) : t; })
        });
      });
    }
    function patchSuggestion(sid, patch) {
      return writeStore(function (s) {
        s = s || {};
        var list = Array.isArray(s.suggestions) ? s.suggestions : [];
        return Object.assign({}, s, {
          suggestions: list.map(function (x) { return (x && String(x.id) === String(sid)) ? Object.assign({}, x, patch) : x; })
        });
      });
    }

    function pull() {
      var seen = readMap(SEEN);
      var myid = myServerId();
      return readCarriers().then(function (rows) {
        var myTickets = (function () { var st = readStore() || {}; return (st.tickets || []).map(function (t) { return t && t.id; }); })();
        rows.forEach(function (row) {
          var d = row.data || {}, sid = subjectOf(row);
          /* ── پیام‌های خودم که از دستگاه دیگر آمده: در استور همین مرورگر بنشان ── */
          if (row.kind === "t" && myid && row.userId === myid && myTickets.indexOf(sid) < 0) {
            if (!seen["t-" + sid]) { seen["t-" + sid] = 1; addTicketLocal({ id: sid, subject: d.sub || "", body: d.body || "", status: "open", reply: "", at: d.at || row.at, __srv: 1 }); }
          }
          if (row.kind === "s" && myid && row.userId === myid) {
            var st0 = readStore() || {};
            var mine = (st0.suggestions || []).some(function (x) { return x && String(x.id) === String(sid); });
            if (!mine && !seen["s-" + sid]) { seen["s-" + sid] = 1; addSuggestionLocal({ id: sid, category: d.cat || "general", title: d.title || "", options: d.opts || [], correct: Number(d.correct) || 0, explanation: d.expl || "", status: "pending", at: d.at || row.at, __srv: 1 }); }
          }
          /* ── پاسخ مدیر به پیام من ── */
          if (row.kind === "tr" && myTickets.indexOf(sid) >= 0) {
            if (!seen[row.rowId]) {
              seen[row.rowId] = 1;
              var st = readStore() || {};
              var t0 = (st.tickets || []).filter(function (t) { return t && String(t.id) === String(sid); })[0];
              var body = String(d.body || "").slice(0, 1000);
              if (t0 && String(t0.reply || "") !== body) {
                patchTicket(sid, { reply: body, status: "answered", answeredAt: d.at || row.at });
                toastOnce("tr-" + sid, "📩 پاسخ مدیر آمد: «" + body.slice(0, 60) + (body.length > 60 ? "…" : "") + "»");
              }
            }
          }
          /* ── تأیید پیشنهاد سؤال من (و نشستن سؤال در بانک همه) ── */
          if (row.kind === "sa") {
            var q = (d.q && typeof d.q === "object") ? d.q : questionOfSuggestion(sid, d);
            if (q) {
              var added = false;
              try { added = bankMerge(q) || added; } catch (e) {}
              try { added = storeMerge(q) || added; } catch (e) {}
              if (added) toastOnce("sa-" + sid, "🎉 سؤال تأییدشده به بانک سؤال همه اضافه شد!");
            }
            var stx = readStore() || {};
            var mineX = (stx.suggestions || []).some(function (x) { return x && String(x.id) === String(sid) && String(x.status) !== "approved"; });
            if (mineX && !seen["sax-" + sid]) { seen["sax-" + sid] = 1; patchSuggestion(sid, { status: "approved", approvedAt: d.at || row.at }); toastOnce("sax-" + sid, "✅ سؤال پیشنهادی تو تأیید شد و ۳۰ سکه گرفتی!"); }
          }
          /* ── رد پیشنهاد ── */
          if (row.kind === "sr") {
            var st2 = readStore() || {};
            var mine2 = (st2.suggestions || []).some(function (x) { return x && String(x.id) === String(sid) && String(x.status) === "pending"; });
            if (mine2 && !seen["sr-" + sid]) { seen["sr-" + sid] = 1; patchSuggestion(sid, { status: "rejected", reply: String(d.why || "").slice(0, 300) }); toastOnce("sr-" + sid, "🙏 پیشنهادت این بار پذیرفته نشد" + (d.why ? ": " + String(d.why).slice(0, 50) : "")); }
          }
        });
        writeMap(SEEN, seen);
        return rows;
      });
    }

    /* ================= ۳) پنل مدیر «📮 پشتیبانی» ================= */
    var PANEL_ID = "gamify-support-panel", FAB_ID = "gamify-support-fab";
    var adminRows = [];

    function style() {
      if (document.getElementById("gamify-support-style")) return;
      var s = document.createElement("style");
      s.id = "gamify-support-style";
      s.textContent =
        "#" + FAB_ID + "{position:fixed;left:14px;bottom:232px;z-index:9600;display:flex;align-items:center;gap:6px;background:#2c2039;color:#ffd479;border:1px solid #a98cf7;border-radius:14px;padding:8px 12px;font:700 13px Tahoma;cursor:pointer;box-shadow:0 10px 30px #0007}" +
        "#" + FAB_ID + " .gs-badge{background:#e5533d;color:#fff;border-radius:999px;padding:1px 7px;font-size:11px}" +
        "#" + PANEL_ID + "{position:fixed;left:14px;bottom:288px;z-index:9601;width:min(430px,94vw);max-height:70vh;overflow:auto;background:#1d1626;color:#f4eefc;border:1px solid #a98cf7;border-radius:16px;padding:12px;font:13px Tahoma;box-shadow:0 18px 50px #000a}" +
        "#" + PANEL_ID + " h4{margin:0 0 8px;font-size:14px;color:#ffd479}" +
        "#" + PANEL_ID + " .gs-item{background:#271d33;border:1px solid #3b2c4d;border-radius:12px;padding:8px 10px;margin:8px 0}" +
        "#" + PANEL_ID + " .gs-meta{font-size:11px;color:#bda8e0;margin-bottom:4px}" +
        "#" + PANEL_ID + " .gs-body{white-space:pre-wrap;margin-bottom:6px}" +
        "#" + PANEL_ID + " textarea,#" + PANEL_ID + " input{width:100%;background:#170f20;color:#fff;border:1px solid #4b3862;border-radius:10px;padding:7px 9px;font:13px Tahoma;margin-bottom:6px}" +
        "#" + PANEL_ID + " button{background:#7c53c3;color:#fff;border:0;border-radius:10px;padding:6px 10px;font:700 12px Tahoma;cursor:pointer;margin-inline-end:6px}" +
        "#" + PANEL_ID + " button.ok{background:#2f9e6b}" +
        "#" + PANEL_ID + " button.no{background:#a3443a}" +
        "#" + PANEL_ID + " .gs-done{color:#7cd7b6;font-size:11px}";
      document.head.appendChild(s);
    }
    function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
    function when(ts) { try { return new Date(Number(ts) || Date.now()).toLocaleString("fa-IR"); } catch (e) { return ""; } }

    function loadAdminRows() {
      return Promise.all([readCarriers(), readCarriersForAdmin()]).then(function (both) {
        var seenIds = {}, merged = [];
        both[0].concat(both[1]).forEach(function (r) {
          if (!r || !r.rowId || seenIds[r.rowId]) return;
          seenIds[r.rowId] = 1; merged.push(r);
        });
        merged.sort(function (a, b) { return (a.at || 0) - (b.at || 0); });
        adminRows = merged;
        return merged;
      });
    }
    function pendingCounts() {
      var tickets = {}, replies = {}, sugg = {}, decided = {};
      adminRows.forEach(function (r) {
        var sid = subjectOf(r);
        if (r.kind === "t") tickets[sid] = r;
        else if (r.kind === "tr") replies[sid] = 1;
        else if (r.kind === "s") sugg[sid] = r;
        else if (r.kind === "sa" || r.kind === "sr") decided[sid] = r.kind;
      });
      var openT = Object.keys(tickets).filter(function (k) { return !replies[k]; }).length;
      var openS = Object.keys(sugg).filter(function (k) { return !decided[k]; }).length;
      return { openT: openT, openS: openS, tickets: tickets, replies: replies, sugg: sugg, decided: decided };
    }
    function adminReply(tid, text, uid) {
      var body = String(text || "").trim();
      if (body.length < 2) return Promise.resolve(false);
      return postCarrier("tr", tid, { k: "tr", to: tid, body: body.slice(0, 1000), at: nowMs() }).then(function (ok) {
        if (!ok) { toast("⚠️ پاسخ فرستاده نشد؛ دوباره تلاش کن."); return false; }
        /* اعلان واقعی به کاربر — منتظر می‌مانیم تا ثبت شود */
        if (!uid) return true;
        return api("/api/admin?action=notify-user", "POST", { userId: uid, title: "📩 پاسخ مدیر", body: body.slice(0, 90), link: "support" })
          .then(function () { return true; }, function () { return true; });
      });
    }
    function grantCoins(uid, amount) {
      if (!uid) return Promise.resolve(false);
      return api("/api/admin?action=set-coins", "POST", { userId: uid, delta: Number(amount || 0) })
        .then(function (r) { return !!(r && !r.error); })
        .catch(function () { return false; });
    }
    function adminApprove(sid, row) {
      var d = row.data || {};
      var q = questionOfSuggestion(sid, d);
      if (!q) { toast("⚠️ این پیشنهاد کامل نیست (۴ گزینه و متن لازم است)."); return Promise.resolve(false); }
      return postCarrier("sa", sid, { k: "sa", q: q, by: meCache.name || "مدیر", at: nowMs() }).then(function (ok) {
        if (!ok) { toast("⚠️ تأیید ثبت نشد؛ دوباره تلاش کن."); return false; }
        var uid = row.userId;
        var tell = uid
          ? api("/api/admin?action=notify-user", "POST", { userId: uid, title: "🎉 سؤالت تأیید شد", body: "به بانک سؤال اضافه شد و ۳۰ سکه گرفتی!", link: "questions" }).catch(function () { return null; })
          : Promise.resolve(null);
        return tell.then(function () { return grantCoins(uid, 30); }).then(function (paid) {
          toast(paid ? "✅ تأیید شد؛ سؤال در بانک همه نشست و ۳۰ سکه داده شد." : "✅ تأیید شد؛ (سکه را دستی بده — set-coins جواب نداد)");
          return true;
        });
      });
    }
    function adminReject(sid, why, uid) {
      return postCarrier("sr", sid, { k: "sr", why: String(why || "").slice(0, 300), at: nowMs() }).then(function (ok) {
        if (!ok) { toast("⚠️ ثبت نشد؛ دوباره تلاش کن."); return false; }
        if (!uid) return true;
        return api("/api/admin?action=notify-user", "POST", { userId: uid, title: "🙏 پیشنهاد سؤال", body: String(why || "این بار پذیرفته نشد").slice(0, 90), link: "questions" })
          .then(function () { return true; }, function () { return true; });
      });
    }
    function renderPanel() {
      var el = document.getElementById(PANEL_ID);
      if (!el) return;
      var c = pendingCounts();
      var html = "";
      html += "<h4>📮 پرسش‌های کاربران — " + fa(c.openT) + " بی‌پاسخ</h4>";
      var tKeys = Object.keys(c.tickets);
      if (!tKeys.length) html += "<div class='gs-meta'>هنوز پیامی نیامده.</div>";
      tKeys.forEach(function (tid) {
        var r = c.tickets[tid], d = r.data || {};
        var answered = !!c.replies[tid];
        html += "<div class='gs-item' data-t='" + esc(tid) + "'>";
        html += "<div class='gs-meta'>" + esc(r.userName || "کاربر") + " · " + when(d.at || r.at) + (answered ? " · <span class='gs-done'>پاسخ داده شد</span>" : "") + "</div>";
        html += "<div class='gs-body'><b>" + esc(d.sub || "") + "</b><br>" + esc(d.body || "") + "</div>";
        if (!answered) html += "<textarea data-reply rows='2' placeholder='پاسخ تو…'></textarea><button data-send>ارسال پاسخ</button>";
        html += "</div>";
      });
      html += "<h4 style='margin-top:12px'>🧩 پیشنهاد سؤال — " + fa(c.openS) + " در انتظار</h4>";
      var sKeys = Object.keys(c.sugg);
      if (!sKeys.length) html += "<div class='gs-meta'>پیشنهادی نیامده.</div>";
      sKeys.forEach(function (sid) {
        var r = c.sugg[sid], d = r.data || {};
        var st = c.decided[sid];
        html += "<div class='gs-item' data-s='" + esc(sid) + "'>";
        html += "<div class='gs-meta'>" + esc(r.userName || "کاربر") + " · دسته: " + esc(d.cat || "") + (st === "sa" ? " · <span class='gs-done'>تأیید شد</span>" : (st === "sr" ? " · <span class='gs-done'>رد شد</span>" : "")) + "</div>";
        html += "<div class='gs-body'><b>" + esc(d.title || "") + "</b><br>" + esc((d.opts || []).map(function (o, i) { return (i === Number(d.correct) ? "✅ " : "• ") + o; }).join(" | ")) + "</div>";
        if (!st) html += "<button class='ok' data-approve>✅ تأیید و افزودن به بانک</button><button class='no' data-reject>رد</button>";
        html += "</div>";
      });
      html += "<div style='margin-top:8px'><button data-refresh>🔄 بررسی مجدد</button><button data-close>بستن</button></div>";
      el.innerHTML = html;

      el.querySelectorAll("[data-t]").forEach(function (box) {
        var tid = box.getAttribute("data-t");
        var row = c.tickets[tid];
        var btn = box.querySelector("[data-send]");
        if (!btn) return;
        btn.addEventListener("click", function () {
          var txt = (box.querySelector("[data-reply]") || {}).value || "";
          btn.disabled = true; btn.textContent = "در حال ارسال…";
          adminReply(tid, txt, row && row.userId).then(function (ok) {
            if (ok) { toast("📤 پاسخ رفت."); loadAdminRows().then(renderPanel); }
            else { btn.disabled = false; btn.textContent = "ارسال پاسخ"; }
          });
        });
      });
      el.querySelectorAll("[data-s]").forEach(function (box) {
        var sid = box.getAttribute("data-s");
        var row = c.sugg[sid];
        var ap = box.querySelector("[data-approve]"), rj = box.querySelector("[data-reject]");
        if (ap) ap.addEventListener("click", function () { ap.disabled = true; adminApprove(sid, row).then(function () { loadAdminRows().then(renderPanel); }); });
        if (rj) rj.addEventListener("click", function () { rj.disabled = true; adminReject(sid, "", row && row.userId).then(function () { loadAdminRows().then(renderPanel); }); });
      });
      el.querySelector("[data-refresh]").addEventListener("click", function () { loadAdminRows().then(renderPanel); });
      el.querySelector("[data-close]").addEventListener("click", function () { el.remove(); });
    }
    function togglePanel() {
      style();
      var el = document.getElementById(PANEL_ID);
      if (el) { el.remove(); return; }
      el = document.createElement("div");
      el.id = PANEL_ID;
      el.innerHTML = "<div class='gs-meta'>در حال بارگذاری…</div>";
      document.body.appendChild(el);
      loadAdminRows().then(renderPanel);
    }
    function mountAdminFab() {
      if (!isAdmin() || document.getElementById(FAB_ID)) return;
      style();
      var b = document.createElement("button");
      b.id = FAB_ID;
      b.type = "button";
      b.innerHTML = "📮 پشتیبانی<span class='gs-badge' style='display:none'>0</span>";
      b.addEventListener("click", togglePanel);
      document.body.appendChild(b);
      (function tickBadge() {
        if (!document.getElementById(FAB_ID)) return;
        loadAdminRows().then(function () {
          var c = pendingCounts();
          var n = c.openT + c.openS;
          var el = b.querySelector(".gs-badge");
          if (el) { el.textContent = fa(n); el.style.display = n ? "" : "none"; }
        });
        setTimeout(tickBadge, 20000);
      })();
    }

    /* ================= ۴) حلقهٔ کار ================= */
    function cycle() {
      if (!busyPush) {
        busyPush = true;
        Promise.resolve().then(pumpTickets).then(pumpSuggestions).then(function () { busyPush = false; }, function () { busyPush = false; });
      }
      if (!busyPull) {
        busyPull = true;
        refreshMe(false).then(function () { return pull(); }).then(function () {
          if (isAdmin()) mountAdminFab();
          busyPull = false;
        }, function () { busyPull = false; });
      }
    }
    function boot() {
      if (booted) return;
      booted = true;
      refreshMe(true).then(function () {
        mountAdminFab();
        setTimeout(cycle, 2500);
        setInterval(cycle, Math.min(PUSH_MS, POLL_MS));
        document.addEventListener("visibilitychange", function () { if (!document.hidden) cycle(); });
        var tries = 0;
        var wait = setInterval(function () {
          tries++;
          var st = readStore();
          if ((st && st.profile) || tries > 40) { clearInterval(wait); cycle(); }
        }, 500);
      });
    }

    /* ================= دسترسی برای آزمون‌ها/عیب‌یابی ================= */
    window.__gamifySupportTest = {
      PREFIX: PREFIX, TITLES: TITLES,
      readStore: readStore, writeStore: writeStore, readMap: readMap, writeMap: writeMap,
      myServerId: myServerId, refreshMe: refreshMe, isAdmin: isAdmin,
      postCarrier: postCarrier, readCarriers: readCarriers, readCarriersForAdmin: readCarriersForAdmin, subjectOf: subjectOf,
      pumpTickets: pumpTickets, pumpSuggestions: pumpSuggestions, pull: pull, cycle: cycle,
      bankMerge: bankMerge, storeMerge: storeMerge, questionOfSuggestion: questionOfSuggestion,
      adminReply: adminReply, adminApprove: adminApprove, adminReject: adminReject,
      loadAdminRows: loadAdminRows, pendingCounts: pendingCounts, renderPanel: renderPanel,
      togglePanel: togglePanel, mountAdminFab: mountAdminFab,
      panelId: PANEL_ID, fabId: FAB_ID,
      reset: function () { try { localStorage.removeItem(SENT); localStorage.removeItem(SEEN); } catch (e) {} }
    };
    window.__gamifySupportStatus = function () {
      var st = readStore() || {};
      return {
        mine: myServerId(), admin: isAdmin(),
        tickets: (st.tickets || []).length, suggestions: (st.suggestions || []).length,
        sent: Object.keys(readMap(SENT)).length, seen: Object.keys(readMap(SEEN)).length
      };
    };

    /* ================= راه‌اندازی ================= */
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
    try { console.log("%c[پشتیبانی زنده] روشن شد.", "color:#7cd7b6"); } catch (e) {}
  } catch (e) { try { console.warn("[پشتیبانی زنده] خطا:", e && e.message); } catch (e2) {} }
})();
// SUPPORT-SYNC-END
