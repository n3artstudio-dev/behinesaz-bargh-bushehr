/* ============================================================
   گیمیفای ۲ — Service Worker اعلان‌ها
   این فایل پیام‌های پوش را می‌گیرد و اعلان سیستمی نشان می‌دهد،
   حتی وقتی سایت بسته است.
   ============================================================ */
const ICON = "/icons/push-192.png";
const BADGE = "/icons/badge-96.png";

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    try {
      const keys = await self.caches?.keys?.();
      if (keys) await Promise.all(keys.filter((k) => k.startsWith("gm-push")).map((k) => self.caches.delete(k)));
    } catch (e) { /* ignore */ }
    await self.clients.claim();
  })());
});

self.addEventListener("push", (event) => {
  let d = {};
  try {
    d = event.data ? event.data.json() : {};
  } catch (e) {
    try { d = { title: "گیمیفای ۲", body: event.data.text() }; } catch (e2) { d = {}; }
  }
  const title = d.title || "گیمیفای ۲";
  const opts = {
    body: d.body || "",
    icon: d.icon || ICON,
    badge: BADGE,
    tag: d.tag || "gamifi",
    dir: "rtl",
    lang: "fa",
    renotify: false,
    vibrate: [120, 60, 120],
    data: { link: d.link || "/", at: d.at || Date.now() },
  };
  if (d.image) opts.image = d.image;
  event.waitUntil(self.registration.showNotification(title, opts));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const link = (event.notification.data && event.notification.data.link) || "/";
  let url;
  if (/^https?:/i.test(link)) url = link;
  else if (link.indexOf("#") === 0) url = self.location.origin + "/" + link;
  else url = self.location.origin + "/" + String(link).replace(/^\/+/, "");

  event.waitUntil((async () => {
    try {
      const wins = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const c of wins) {
        if (c.url && c.url.indexOf(self.location.origin) === 0) {
          await c.focus();
          try { c.postMessage({ type: "gamifi-open", link }); } catch (e) { /* ignore */ }
          return;
        }
      }
    } catch (e) { /* ignore */ }
    if (self.clients.openWindow) await self.clients.openWindow(url);
  })());
});

/* اتصال رابط برای تست از داخل صفحه */
self.addEventListener("message", (event) => {
  const d = event.data || {};
  if (d && d.type === "gm-notify-test") {
    self.registration.showNotification(d.title || "گیمیفای ۲", {
      body: d.body || "اعلان آزمایشی", icon: ICON, badge: BADGE, dir: "rtl", lang: "fa",
    });
  }
});
