import { spawnSync } from 'node:child_process';
import { statSync } from 'node:fs';
const destination = process.argv[2];
if (!destination || !process.env.DATABASE_URL) throw Error('Backup path and DATABASE_URL required');
const url = new URL(process.env.DATABASE_URL);
if (!['postgres:', 'postgresql:'].includes(url.protocol)) throw Error('PostgreSQL connection required');
const result = spawnSync('pg_dump', ['--format=custom', '--no-owner', '--no-acl', '--file', destination], {
  stdio:'inherit', env:{...process.env,PGHOST:url.hostname,PGPORT:url.port||'5432',PGUSER:decodeURIComponent(url.username),PGPASSWORD:decodeURIComponent(url.password),PGDATABASE:decodeURIComponent(url.pathname.slice(1))}
});
if(result.status!==0 || statSync(destination).size<1024) throw Error('Database backup failed');
const verify=spawnSync('pg_restore',['--list',destination],{stdio:['ignore','ignore','inherit']});
if(verify.status!==0)throw Error('Backup archive verification failed');
console.log('Database backup created and archive directory verified');
