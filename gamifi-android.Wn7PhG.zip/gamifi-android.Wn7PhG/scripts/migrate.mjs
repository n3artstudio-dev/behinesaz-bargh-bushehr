import 'dotenv/config';
import { Pool } from 'pg';
import { readdir, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const pool=new Pool({connectionString:process.env.DATABASE_URL,connectionTimeoutMillis:5000});
const client=await pool.connect();
try {
  await client.query("SELECT pg_advisory_lock(7213105)");
  await client.query('CREATE TABLE IF NOT EXISTS app_migrations(version text PRIMARY KEY, sha256 text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())');
  const directory=new URL('../migrations/',import.meta.url);
  for(const file of (await readdir(directory)).filter(f=>/^\d+.*\.sql$/.test(f)).sort()) {
    const sql=await readFile(new URL(file,directory),'utf8');
    const checksum=createHash('sha256').update(sql).digest('hex');
    const existing=await client.query('SELECT sha256 FROM app_migrations WHERE version=$1',[file]);
    if(existing.rowCount) {
      if(existing.rows[0].sha256!==checksum) throw new Error('Changed applied migration: '+file);
      continue;
    }
    await client.query('BEGIN');
    try {
      await client.query(sql);
      await client.query('INSERT INTO app_migrations(version,sha256) VALUES($1,$2)',[file,checksum]);
      await client.query('COMMIT');
      console.log('Applied '+file);
    } catch(error) { await client.query('ROLLBACK'); throw error; }
  }
} finally {
  await client.query('SELECT pg_advisory_unlock(7213105)').catch(()=>{});
  client.release(); await pool.end();
}
