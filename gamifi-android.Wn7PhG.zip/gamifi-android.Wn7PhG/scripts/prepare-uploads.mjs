import { mkdirSync, existsSync, realpathSync, statSync, chownSync, chmodSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { execFileSync } from 'node:child_process';
const target=process.env.UPLOAD_DIR||'/var/lib/bu-gamifi/uploads';
if(!target.startsWith('/')||resolve(target)!==target||target==='/'||!target.endsWith('/uploads'))throw Error('UPLOAD_DIR must be an absolute directory ending /uploads');
if(existsSync(target)) {
  if(!statSync(target).isDirectory()||realpathSync(target)!==target)throw Error('Inspect symlink or non-directory UPLOAD_DIR before updating');
  execFileSync('tar',['-C',target,'-czf',process.argv[2]+'/uploads.tar.gz','.'],{stdio:'inherit'});
}
const parent=dirname(target);
if(!existsSync(parent)) { mkdirSync(parent,{recursive:true,mode:0o755}); chmodSync(parent,0o755); }
mkdirSync(target,{recursive:true,mode:0o755});
const uid=Number(execFileSync('id',['-u','bugamifi'],{encoding:'utf8'}).trim());
const gid=Number(execFileSync('id',['-g','bugamifi'],{encoding:'utf8'}).trim());
chownSync(target,uid,gid);chmodSync(target,0o750);
console.log('Persistent upload directory prepared; existing media retained');
