import {readFile,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
const live=resolve(process.argv[2]||'');
if(!process.argv[2]||live===process.cwd())throw Error('Separate live path required');
for(const name of ['00-scroll-fix.js','10-sync.js']){
 const source=await readFile(join(live,'public/patches',name),'utf8');
 const target=join('public/patches',name);
 let current=await readFile(target,'utf8');
 for(const marker of ['EARLY-BANK','BANK-SHARE']){
  const pattern=new RegExp('// '+marker+'-START[\\s\\S]*?// '+marker+'-END');
  const block=source.match(pattern)?.[0];
  if(block&&pattern.test(current))current=current.replace(pattern,()=>block);
 }
 await writeFile(target,current);
}
try{await writeFile('public/patches/01-bank.js',await readFile(join(live,'public/patches/01-bank.js')));}
catch(e){if(e.code!=='ENOENT')throw e;}
console.log('Existing exported question bank preserved; database is unchanged.');
