import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, sep } from 'node:path';
// fileURLToPath handles spaces and non-ASCII paths on both Windows and Linux.
const { fileURLToPath }=await import('node:url');
const base=fileURLToPath(new URL('../',import.meta.url));
const manifest=readFileSync(new URL('../MANIFEST.sha256',import.meta.url),'utf8');
let count=0;
for(const line of manifest.split(/\r?\n/).filter(Boolean)) {
  const match=/^([a-f0-9]{64})  (.+)$/.exec(line);if(!match)throw Error('Invalid manifest');
  const path=resolve(base,match[2]);
  if(!path.startsWith(resolve(base)+sep))throw Error('Unsafe manifest path');
  const hash=createHash('sha256').update(readFileSync(path)).digest('hex');
  if(hash!==match[1])throw Error('Release file changed or corrupted: '+match[2]);
  count++;
}
console.log('Release integrity verified: '+count+' files');
