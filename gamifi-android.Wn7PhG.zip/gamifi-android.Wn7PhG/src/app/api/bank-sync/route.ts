import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { json } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";
import { db } from "@/db";
import { questions, categories } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

/* ═══════════════════════════════════════════════════════════════════════════
   POST /api/bank-sync  —  راه‌حلِ بنیادیِ سؤالاتِ دسته
   ─────────────────────────────────────────────────────────────────────────
   یک درخواست (فقط از کنسولِ مدیر، با کد مدیریت):
     ۱) دسته + سؤالاتِ ارسالی را در دیتابیسِ سرور ثبت/به‌روزرسانی می‌کند.
     ۲) بلافاصله بانکِ مشترک (10-sync.js) را از نو می‌سازد تا به همهٔ مرورگرها برسد.
   یعنی: «سؤالِ رویداد برای همه درست شود» — بدون فایلی، بدون مرحلهٔ جدا، همیشه.
   ═══════════════════════════════════════════════════════════════════════ */

const START_LINE = "// BANK-SHARE-START";
const END_LINE = "// BANK-SHARE-END";
const norm = (t: unknown) => String(t ?? "").replace(/[\s\u200c]+/g, " ").replace(/[يى]/g, "ی").replace(/ك/g, "ک").trim();
function toOptions(v: unknown): string[] | null {
  let arr: unknown = v;
  if (typeof arr === "string") { try { arr = JSON.parse(arr); } catch { return null; } }
  if (!Array.isArray(arr)) return null;
  const out = arr.map((x) => String(x == null ? "" : x).trim()).filter((x) => x.length);
  return out.length === 4 ? out : null;
}
function unesc(t: string) { try { return JSON.parse('"' + t.replace(/"/g, '\\"') + '"'); } catch { return t; } }
function readBuiltinCategories(bundlePath: string): { id: string; name: string }[] {
  try {
    const src = fs.readFileSync(bundlePath, "utf8");
    const m = /\byo=\[\{id:"/.exec(src);
    if (!m) return [];
    const seg = src.slice(m.index, m.index + 20000);
    const re = /\{id:"([^"]+)",name:"((?:[^"\\]|\\.)*)",(?:subtitle:"((?:[^"\\]|\\.)*)",)?icon:"([^"]*)",color:"(#[0-9a-fA-F]+)",tag:"((?:[^"\\]|\\.)*)",safety:(\d)/g;
    const out: { id: string; name: string }[] = [];
    let mm: RegExpExecArray | null;
    while ((mm = re.exec(seg)) !== null) { out.push({ id: mm[1], name: unesc(mm[2]) }); if (out.length >= 80) break; }
    return out;
  } catch { return []; }
}

export async function POST(req: Request) {
  const adm = await requireAdmin(req);
  if (!adm) return json({ error: "forbidden", message: "کد مدیریت لازم است." }, 403);
  const body = await req.json().catch(() => ({}));
  const newCats: any[] = Array.isArray(body.categories) ? body.categories : [];
  const newQs: any[] = Array.isArray(body.questions) ? body.questions : [];
  const author = String(body.author || "کنسول مدیر");
  if (!newQs.length) return json({ error: "no-questions", message: "هیچ سؤالی ارسال نشد." }, 400);

  // ۱) دسته‌ها (upsert)
  for (const c of newCats) {
    const id = String(c.id || "cat" + Date.now().toString(36) + Math.floor(Math.random() * 1e4));
    const name = String(c.name || id);
    await db.insert(categories).values({
      id, name, subtitle: String(c.subtitle || ""), icon: String(c.icon || "zap"),
      color: String(c.color || "#a98cf7"), tag: String(c.tag || ""), safety: c.safety ? 1 : 0, active: 1,
    }).onConflictDoUpdate({ target: categories.id, set: { active: 1, name } });
  }

  // ۲) سؤالات (upsert)
  let added = 0, updated = 0, skipped = 0;
  for (const q of newQs) {
    const title = String(q.title || "").trim();
    const opts = toOptions(q.options);
    if (!title || title.length < 3 || !opts) { skipped++; continue; }
    const correct = Math.min(3, Math.max(0, Math.round(Number(q.correct) || 0)));
    const seconds = Math.min(180, Math.max(5, Math.round(Number(q.seconds) || 25)));
    const cat = String(q.category || "general");
    const id = String(q.id || "q" + norm(title).slice(0, 40) + Math.floor(Math.random() * 1e4));
    const expl = String(q.explanation || "");
    const existing = (await db.select().from(questions).where(eq(questions.id, id)).limit(1))[0];
    if (existing) {
      await db.update(questions).set({ category: cat, title, options: opts, correct, explanation: expl, seconds, status: "approved", author }).where(eq(questions.id, id));
      updated++;
    } else {
      await db.insert(questions).values({ id, category: cat, title, options: opts, correct, explanation: expl, source: author, seconds, kind: "text", media: "", status: "approved", author });
      added++;
    }
  }

  // ۳) بازسازی بانکِ مشترک (10-sync.js) — دقیقاً مثل share-bank.cjs
  let embedded = false, sharedCount = 0;
  try {
    const rows = await db.select().from(questions).where(eq(questions.status, "approved"));
    rows.sort((a, b) => String(a.category).localeCompare(String(b.category)) || String(a.id).localeCompare(String(b.id)));
    const seen = new Set<string>();
    const qs: any[] = [];
    for (const r of rows) {
      const t = norm(r.title);
      const options = toOptions(r.options);
      if (!t || t.length < 3 || !options) continue;
      const key = t.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      let correct = Number(r.correct);
      if (!Number.isFinite(correct) || correct < 0 || correct > 3) correct = 0;
      const item: any = { id: String(r.id), category: String(r.category || "general"), title: t, options, correct: Math.round(correct) };
      const ex = String(r.explanation ?? "").trim();
      if (ex) item.explanation = ex;
      const sec = Math.round(Number(r.seconds));
      if (Number.isFinite(sec) && sec >= 5 && sec <= 180 && sec !== 25) item.seconds = sec;
      qs.push(item);
    }
    const dbCats = (await db.select().from(categories)).map((c) => ({
      id: String(c.id), name: norm(c.name || c.id), subtitle: norm(c.subtitle || ""),
      icon: String(c.icon || "book"), color: String(c.color || "#a98cf7"), tag: norm(c.tag || ""), safety: c.safety ? 1 : 0,
    }));
    const appRoot = process.cwd();
    const builtin = readBuiltinCategories(path.join(appRoot, "public", "original", "bundle.js"));
    const builtinIds = new Set(builtin.map((b) => b.id));
    const builtinByName = new Map(builtin.map((b) => [b.name.toLowerCase(), b.id]));
    const alias: Record<string, string> = {};
    const freshCats: any[] = [];
    for (const c of dbCats) {
      if (builtinIds.has(c.id)) continue;
      const sameName = builtinByName.get(c.name.toLowerCase());
      if (sameName) { alias[c.id] = sameName; continue; }
      freshCats.push(c);
    }
    const payload: any = { v: "", generatedAt: new Date().toISOString(), count: qs.length, questions: qs, categories: freshCats };
    if (Object.keys(alias).length) payload.alias = alias;
    payload.v = crypto.createHash("sha1").update(JSON.stringify({ questions: qs, categories: freshCats, alias })).digest("hex").slice(0, 12);
    const dataLine = "window.__gamifyBankData = " + JSON.stringify(payload) + ";";

    const target = path.join(appRoot, "public", "patches", "10-sync.js");
    if (fs.existsSync(target)) {
      let text = fs.readFileSync(target, "utf8");
      let snippet = "";
      const sIdx = text.indexOf(START_LINE);
      const eIdx = text.indexOf(END_LINE);
      if (sIdx >= 0 && eIdx > sIdx) {
        const block = text.slice(sIdx, eIdx);
        const after = block.indexOf(";");
        snippet = block.slice(after + 1).trim();
      }
      const block = [START_LINE + " — دست نزن؛ این بلوک توسط api/bank-sync از نو ساخته می‌شود", dataLine, "", snippet || "(pull snippet)", END_LINE].join("\n");
      const lines = text.split("\n");
      let start = -1, end = -1;
      for (let i = 0; i < lines.length; i++) if (lines[i].trimStart().startsWith(START_LINE)) { start = i; break; }
      if (start >= 0) {
        for (let i = start + 1; i < lines.length; i++) if (lines[i].trim() === END_LINE) { end = i; break; }
        if (end < 0) end = lines.length - 1;
        text = lines.slice(0, start).concat(block.split("\n")).concat(lines.slice(end + 1)).join("\n");
      } else {
        text = (text.endsWith("\n") ? text : text + "\n") + block + "\n";
      }
      fs.writeFileSync(target, text, { mode: 0o644 });
      embedded = true;
      sharedCount = qs.length;
    }
  } catch (e: any) {
    return json({ ok: false, added, updated, skipped, embedded, error: "embed-failed", message: String(e?.message || e) }, 500);
  }

  // ۴) تعدادِ دستهٔ ارسالی
  const catId = String(newQs[0]?.category || "");
  let catCount = 0;
  if (catId) catCount = (await db.select().from(questions).where(and(eq(questions.category, catId), eq(questions.status, "approved")))).length;

  return json({
    ok: true, added, updated, skipped,
    category: catId, categoryCount: catCount,
    sharedInBank: sharedCount, embedded,
    minWarning: catCount < 7 ? "دستهٔ تو کمتر از ۷ سؤال دارد؛ آزمونِ بازی آن را «بی‌ربط» نشان می‌دهد. سؤال بیشتر وارد کن." : null,
  });
}
