import {pool} from '@/db';
import {getSessionUser,json,uid,now} from '@/lib/auth';
import {requireAdmin} from '@/lib/admin';
export async function GET(req:Request){
 const me=await getSessionUser();if(!me)return json({error:'not-authed'},401);
 const admin=await requireAdmin(req),kind=new URL(req.url).searchParams.get('kind')==='league'?'league':'event';
 const rows=await pool.query(`SELECT id,title,category,org_id,starts_at,ends_at,question_count,seconds,active FROM shared_competitions WHERE kind=$1 AND active=true AND ($2::boolean OR org_id='' OR org_id IN(SELECT org_id FROM org_members WHERE user_id=$3 AND status='approved')) UNION ALL SELECT id,title,category,org_id,starts_at,ends_at,CASE WHEN jsonb_array_length(questions)>0 THEN jsonb_array_length(questions) ELSE 7 END,25,active FROM tournaments WHERE $1='event' AND active=true AND ($2::boolean OR org_id='' OR org_id IN(SELECT org_id FROM org_members WHERE user_id=$3 AND status='approved')) ORDER BY starts_at DESC`,[kind,!!admin,me.id]);
 const categories=await pool.query('SELECT id,name FROM categories WHERE active=1 ORDER BY name');
 return json({items:rows.rows.map(r=>({...r,starts_at:Number(r.starts_at),ends_at:Number(r.ends_at)})),categories:categories.rows,admin:!!admin,serverNow:now()});
}
export async function POST(req:Request){
 const admin=await requireAdmin(req);if(!admin)return json({error:'forbidden'},403);
 const b=await req.json().catch(()=>null);if(!b)return json({error:'invalid-body'},400);
 const action=String(b.action||'save'),id=String(b.id||'');
 if(action==='delete'){
  await pool.query('UPDATE shared_competitions SET active=false WHERE id=$1',[id]);await pool.query('UPDATE tournaments SET active=false WHERE id=$1',[id]);return json({ok:true});
 }
 if(action==='archive-all'){
  await pool.query('UPDATE shared_competitions SET active=false WHERE active=true');await pool.query('UPDATE tournaments SET active=false WHERE active=true');return json({ok:true});
 }
 const kind=b.kind==='league'?'league':'event',title=String(b.title||'').trim(),category=String(b.category||'');
 const starts=Number(b.startsAt),ends=Number(b.endsAt),count=Number(b.questionCount??7),seconds=Number(b.seconds??25);
 if(title.length<3||![starts,ends,count,seconds].every(Number.isSafeInteger)||ends<=starts||count<1||count>50||seconds<5||seconds>120)return json({error:'نام، زمان یا تعداد سؤال معتبر نیست'},400);
 const bank=await pool.query("SELECT count(*)::int n FROM questions WHERE category=$1 AND status='approved' AND jsonb_array_length(options)=4",[category]);
 if(bank.rows[0].n<count)return json({error:'در همین دسته سؤال تأییدشدهٔ کافی وجود ندارد'},409);
 const existing=id?(await pool.query('SELECT id FROM shared_competitions WHERE id=$1',[id])).rowCount:0;
  if(id&&!existing){
  const legacy=await pool.query('SELECT id FROM tournaments WHERE id=$1',[id]);
  if(!legacy.rowCount)return json({error:'مسابقه پیدا نشد'},404);
  return json({error:'برای حفظ نتایج، ویرایش قالب رویداد قدیمی از پنل اصلی آن انجام شود؛ حذف و ساخت مجدد لازم نیست.'},409);
 }
 if(!existing&&!admin.me?.id)return json({error:'برای ساخت مسابقه با حساب مدیر وارد شوید'},401);
 if(existing){
  const previous=(await pool.query('SELECT category,question_count,seconds FROM shared_competitions WHERE id=$1',[id])).rows[0];
  const played=await pool.query('SELECT 1 FROM quiz_matches WHERE competition_id=$1 LIMIT 1',[id]);
  if(played.rowCount&&(previous.category!==category||previous.question_count!==count||previous.seconds!==seconds))return json({error:'پس از شروع شرکت‌کنندگان، دسته و تعداد سؤال و زمان پاسخ تغییر نمی‌کند؛ نام و تاریخ قابل ویرایش است.'},409);
 }
 const nextId=id||uid(kind);
 if(existing)await pool.query('UPDATE shared_competitions SET title=$2,category=$3,starts_at=$4,ends_at=$5,question_count=$6,seconds=$7 WHERE id=$1',[id,title.slice(0,120),category,starts,ends,count,seconds]);
 else await pool.query('INSERT INTO shared_competitions(id,kind,title,category,starts_at,ends_at,question_count,seconds,created_by,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[nextId,kind,title.slice(0,120),category,starts,ends,count,seconds,admin.me?.id||null,now()]);
 return json({ok:true,id:nextId});
}
