import { listCompetitions, createCompetition } from "@/lib/competitions";
// /api/events itself remains the original SSE transport.
export const dynamic = "force-dynamic";
export function GET() { return listCompetitions("event"); }
export function POST(req: Request) { return createCompetition(req, "event"); }
