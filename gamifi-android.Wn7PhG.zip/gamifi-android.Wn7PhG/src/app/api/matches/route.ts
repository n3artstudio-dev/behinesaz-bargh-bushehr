import { randomInt } from 'node:crypto';
import type { PoolClient } from 'pg';
import { pool } from '@/db';
import { getSessionUser, json, now, uid } from '@/lib/auth';
import { getJsonSetting } from '@/lib/admin';
import { MODES, choiceIsValid, pointsFor, answeredInTime, dayInTehran } from '@/lib/quiz-rules';

type Question={id:string;title:string;options:string[];correct:number;explanation:string;media?:string};
type Answer={round:number;choice:number;correct:boolean;points:number;elapsed:number;rivalPoints:number};
type Match={id:string;user_id:string;category:string;org_id:string;mode:string;competition_id:string;day:string;status:string;questions:Question[];answers:Answer[];round:number;seconds:number;round_at:string|number;bonus_seconds:number;helps:Record<string,number>;used_helps:Record<string,unknown>;score:number;rival_score:number;rival:{id:string;name:string;avatar:unknown;accuracy:number}|null;reward:unknown};
function visible(m:Match) {
  const q=m.questions[m.round];const answered=m.answers.find(a=>a.round===m.round);
  return {id:m.id,category:m.category,mode:m.mode,status:m.status,competitionId:m.competition_id,round:m.round,total:m.questions.length,seconds:m.seconds,roundAt:Number(m.round_at),deadline:Number(m.round_at)+(m.seconds+m.bonus_seconds)*1000,serverNow:now(),score:m.score,rivalScore:m.rival_score,rival:m.rival?{id:m.rival.id,name:m.rival.name,avatar:m.rival.avatar}:null,helps:m.helps,usedHelps:m.used_helps,reward:m.reward,
    answers:m.answers,question:q?{id:q.id,title:q.title,options:q.options,media:q.media||'',...(answered||m.status==='finished'?{correct:q.correct,explanation:q.explanation}: {})}:null};
}
function shuffle(q:Question):Question {
  const order=[0,1,2,3];for(let i=3;i>0;i--){const j=randomInt(i+1);[order[i],order[j]]=[order[j],order[i]];}
  return {...q,options:order.map(i=>q.options[i]),correct:order.indexOf(q.correct)};
}
async function finish(client:PoolClient,m:Match) {
  const correct=m.answers.filter(a=>a.correct).length;
  const won=!!m.rival&&m.score>m.rival_score;
  const reward={xp:correct*10+(won?30:0),coins:correct*2+(won?20:0)+(m.mode==='daily'?25:0),cups:won?1:0};
  const time=now();
  await client.query("UPDATE quiz_matches SET status='finished',finished_at=$2,reward=$3::jsonb WHERE id=$1",[m.id,time,JSON.stringify(reward)]);
  await client.query('UPDATE users SET xp=coalesce(xp,0)+$2,week_xp=coalesce(week_xp,0)+$2,coins=coalesce(coins,0)+$3,cups=coalesce(cups,0)+$4,played=coalesce(played,0)+1,wins=coalesce(wins,0)+$4,level=floor((coalesce(xp,0)+$2)/250)+1 WHERE id=$1',[m.user_id,reward.xp,reward.coins,reward.cups]);
  await client.query('INSERT INTO coin_ledger(id,user_id,delta,reason,ref,note,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)',[uid('cl'),m.user_id,reward.coins,'quiz',m.id,'server-scored',time]);
  if(m.competition_id&&m.mode==='event')await client.query('INSERT INTO tournament_players(tournament_id,user_id,score,joined_at) SELECT $1,$2,$3,$4 WHERE EXISTS(SELECT 1 FROM tournaments WHERE id=$1) ON CONFLICT(tournament_id,user_id) DO UPDATE SET score=greatest(tournament_players.score,excluded.score)',[m.competition_id,m.user_id,m.score,time]);
  m.status='finished';m.reward=reward;
}
export async function GET(req:Request) {
  const me=await getSessionUser();if(!me)return json({error:'not-authed'},401);
  const competition=new URL(req.url).searchParams.get('standings');
  if(competition){const meta=(await pool.query('SELECT title,ends_at FROM shared_competitions WHERE id=$1 UNION ALL SELECT title,ends_at FROM tournaments WHERE id=$1 LIMIT 1',[competition])).rows[0];if(!meta)return json({error:'مسابقه پیدا نشد'},404);const r=await pool.query(`WITH all_scores AS (SELECT user_id,score FROM quiz_matches WHERE competition_id=$1 AND status='finished' UNION ALL SELECT user_id,score FROM tournament_players WHERE tournament_id=$1), scores AS (SELECT user_id,max(score) AS score FROM all_scores GROUP BY user_id), ranked AS (SELECT user_id,score,rank() OVER(ORDER BY score DESC) AS rank FROM scores) SELECT r.*,u.name FROM ranked r JOIN users u ON u.id=r.user_id ORDER BY r.rank,u.id`,[competition]);return json({title:meta.title,final:Number(meta.ends_at)<=now(),endsAt:Number(meta.ends_at),rank:r.rows.find(x=>x.user_id===me.id)?.rank||null,total:r.rows.length,leaders:r.rows.slice(0,10).map(x=>({id:x.user_id,name:x.name,rank:x.rank,score:x.score}))});}
  const id=new URL(req.url).searchParams.get('id');
  const result=id?await pool.query('SELECT * FROM quiz_matches WHERE id=$1 AND user_id=$2',[id,me.id]):await pool.query("SELECT * FROM quiz_matches WHERE user_id=$1 AND status='active' ORDER BY created_at DESC LIMIT 1",[me.id]);
  return json({match:result.rows[0]?visible(result.rows[0]):null});
}
export async function POST(req:Request) {
  const me=await getSessionUser();if(!me)return json({error:'not-authed'},401);
  const input=await req.json().catch(()=>null);if(!input)return json({error:'invalid-body'},400);
  const action=String(input.action||'start'),client=await pool.connect();
  try {
    await client.query('BEGIN');
    if(action==='start') {
      await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[me.id]);
      const mode=String(input.mode||'practice');if(!MODES.includes(mode as typeof MODES[number]))throw Error('نوع مسابقه معتبر نیست');
      const settings=await getJsonSetting<Record<string,any>>('site-config',{});
      let category=String(input.category||''),count=7,seconds=Number(settings.roundSeconds)||25;
      const competitionId=String(input.competitionId||'');
      if(mode==='event'||mode==='league') {
        if(!competitionId)throw Error('مسابقه مشخص نشده است');
        const competition=(await client.query("SELECT id,category,org_id,starts_at,ends_at,CASE WHEN jsonb_array_length(questions)>0 THEN jsonb_array_length(questions) ELSE 7 END AS question_count,25 AS seconds FROM tournaments WHERE id=$1 AND active=true UNION ALL SELECT id,category,org_id,starts_at,ends_at,question_count,seconds FROM shared_competitions WHERE id=$1 AND active=true LIMIT 1",[competitionId])).rows[0];
        if(!competition||Number(competition.starts_at)>now()||Number(competition.ends_at)<now())throw Error('این مسابقه اکنون باز نیست');
        if(competition.org_id&&!(await client.query("SELECT 1 FROM org_members WHERE user_id=$1 AND org_id=$2 AND status='approved'",[me.id,competition.org_id])).rowCount)throw Error('عضویت تأییدشده در سازمان لازم است');
        category=competition.category;count=competition.question_count;seconds=competition.seconds;
        const previousCompetition=(await client.query('SELECT * FROM quiz_matches WHERE user_id=$1 AND competition_id=$2 ORDER BY created_at ASC LIMIT 1',[me.id,competitionId])).rows[0];
        if(previousCompetition){if(previousCompetition.status==='active'){await client.query('COMMIT');return json(visible(previousCompetition));}throw Error('شما قبلاً در این مسابقه شرکت کرده‌اید. شرکت فقط یک‌بار مجاز است؛ جدول رتبه‌بندی را مشاهده کنید.');}

      }
      const day=mode==='daily'?dayInTehran(now()):'';
      if(day) {
        const previous=(await client.query("SELECT * FROM quiz_matches WHERE user_id=$1 AND mode='daily' AND day=$2",[me.id,day])).rows[0];
        if(previous){await client.query('COMMIT');return json(visible(previous));}
        category=String(settings.dailyCategory||'general');count=Number(settings.dailyCount)||5;
      }
      if(!Number.isInteger(count)||count<1||count>100||!Number.isInteger(seconds)||seconds<5||seconds>120)throw Error('تنظیمات زمان یا تعداد سؤال معتبر نیست');
      const active=(await client.query("SELECT * FROM quiz_matches WHERE user_id=$1 AND status='active' ORDER BY created_at DESC LIMIT 1",[me.id])).rows[0];
      if(active){if(active.mode===mode&&active.category===category&&active.competition_id===competitionId){await client.query('COMMIT');return json(visible(active));}throw Error('یک مسابقهٔ ناتمام دارید؛ ابتدا آن را تمام کنید یا از آن خارج شوید');}
      const bank=await client.query("SELECT id,title,options,correct,explanation FROM questions WHERE category=$1 AND status='approved' AND jsonb_array_length(options)=4 ORDER BY random() LIMIT $2",[category,count]);
      if(bank.rowCount!==count)throw Error('سؤال تأییدشدهٔ کافی در همین دسته وجود ندارد');
      const questions=bank.rows.map(shuffle),lifelines=settings.lifelines?.[mode]||{},helps={fifty:lifelines.fifty===false?0:1,hint:lifelines.hint===false?0:1,time:lifelines.time===false?0:1};
      let rival=null;
      if(!['practice','daily'].includes(mode)) {
        const bot=(await client.query('SELECT id,name,avatar FROM users WHERE is_demo=true AND banned=false ORDER BY random() LIMIT 1')).rows[0];
        if(bot)rival={...bot,accuracy:Math.min(.95,Math.max(.3,Number(settings.botAccuracy)||.65))};
      }
      const id=uid('quiz'),time=now();
      const row=(await client.query('INSERT INTO quiz_matches(id,user_id,category,org_id,mode,competition_id,day,questions,seconds,round_at,helps,rival,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11::jsonb,$12::jsonb,$13) RETURNING *',[id,me.id,category,me.orgId||'',mode,competitionId,day,JSON.stringify(questions),seconds,time+1500,JSON.stringify(helps),JSON.stringify(rival),time])).rows[0];
      await client.query('COMMIT');return json(visible(row),201);
    }
    const m:Match=(await client.query('SELECT * FROM quiz_matches WHERE id=$1 AND user_id=$2 FOR UPDATE',[String(input.id||''),me.id])).rows[0];
    if(!m)throw Error('مسابقه پیدا نشد');
    if(m.status!=='active'){await client.query('COMMIT');return json(visible(m));}
    if(action==='forfeit'){await client.query("UPDATE quiz_matches SET status='abandoned' WHERE id=$1",[m.id]);m.status='abandoned';}
    else {
      if(input.round!==m.round)throw Error('این نوبت تغییر کرده است؛ وضعیت مسابقه را تازه کنید');
      const question=m.questions[m.round],answer=m.answers.find(a=>a.round===m.round);
      if(action==='answer'&&!answer) {
        if(!choiceIsValid(input.choice))throw Error('گزینه معتبر نیست');
        const time=now();if(time<Number(m.round_at))throw Error('زمان پاسخ‌گویی هنوز شروع نشده است');
        const elapsed=Math.max(0,time-Number(m.round_at)),seconds=m.seconds+m.bonus_seconds;
        const correct=answeredInTime(time,Number(m.round_at),seconds)&&input.choice===question.correct;
        let streak=0;for(let i=m.answers.length-1;i>=0&&m.answers[i].correct;i--)streak++;
        const points=pointsFor(correct,elapsed,seconds,streak);
        const rivalPoints=m.rival?pointsFor(randomInt(10000)<m.rival.accuracy*10000,randomInt(1000,seconds*1000),seconds,0):0;
        m.answers.push({round:m.round,choice:input.choice,correct,points,elapsed,rivalPoints});m.score+=points;m.rival_score+=rivalPoints;
        await client.query('UPDATE quiz_matches SET answers=$2::jsonb,score=$3,rival_score=$4 WHERE id=$1',[m.id,JSON.stringify(m.answers),m.score,m.rival_score]);
        if(m.round===m.questions.length-1)await finish(client,m);
      }else if(action==='next') {
        if(!answer)throw Error('ابتدا پاسخ این سؤال را ثبت کنید');
        if(m.round<m.questions.length-1){m.round++;m.round_at=now()+1500;m.bonus_seconds=0;m.used_helps={};await client.query('UPDATE quiz_matches SET round=$2,round_at=$3,bonus_seconds=0,used_helps=$4::jsonb WHERE id=$1',[m.id,m.round,m.round_at,'{}']);}
      }else if(action==='help') {
        const kind=String(input.kind||'');if(answer||now()>Number(m.round_at)+(m.seconds+m.bonus_seconds)*1000||!['fifty','hint','time'].includes(kind)||!m.helps[kind]||m.used_helps[kind])throw Error('این کمک در دسترس نیست');
        m.helps[kind]--;
        if(kind==='time'){m.bonus_seconds+=10;m.used_helps.time=true;}
        if(kind==='fifty')m.used_helps.fifty=[0,1,2,3].filter(i=>i!==question.correct).sort(()=>randomInt(3)-1).slice(0,2);
        if(kind==='hint')m.used_helps.hint=`پاسخ با «${question.options[question.correct].trim().charAt(0)}» شروع می‌شود.`;
        await client.query('UPDATE quiz_matches SET helps=$2::jsonb,used_helps=$3::jsonb,bonus_seconds=$4 WHERE id=$1',[m.id,JSON.stringify(m.helps),JSON.stringify(m.used_helps),m.bonus_seconds]);
      }else if(action!=='answer')throw Error('عملیات معتبر نیست');
    }
    await client.query('COMMIT');return json(visible(m));
  }catch(error){await client.query('ROLLBACK');return json({error:error instanceof Error?error.message:'خطای مسابقه'},400);}finally{client.release();}
}
