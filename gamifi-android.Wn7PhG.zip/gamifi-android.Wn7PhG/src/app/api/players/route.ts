import { and, desc, eq, gte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { pub, json, getSessionUser, now } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";
import { isConnected } from "@/lib/realtime";

const ONLINE_MS = 2 * 60000;

export async function GET(req: Request) {
  await ensureSeed();
  await getSessionUser(); // به‌روزرسانی last_seen
  const url = new URL(req.url);
  const onlineOnly = url.searchParams.get("online") === "1";
  const realOnly = url.searchParams.get("real") === "1";
  const requested=Number(url.searchParams.get("limit")||200); const limit=Number.isFinite(requested)?Math.min(200,Math.max(10,Math.floor(requested))):200;
  const conds = [eq(users.banned, false)];
  if (onlineOnly) conds.push(gte(users.lastSeen, now() - ONLINE_MS));
  if (onlineOnly || realOnly) conds.push(eq(users.isDemo, false), eq(users.banned, false));
  if (realOnly) conds.push(or(ne(users.provider, "guest"), ne(users.phone, ""), ne(users.email, ""), gte(users.lastSeen, now() - 7 * 86400000))!);
  const rows = await db.select().from(users).where(conds.length ? and(...conds) : undefined)
    .orderBy(sql`CASE WHEN ${users.isDemo}=false AND ${users.lastSeen}>${now()-ONLINE_MS} THEN 0 WHEN ${users.isDemo}=true THEN 1 ELSE 2 END`, desc(users.lastSeen), desc(users.xp)).limit(limit);
  return json(rows.map((u) => {
    const p = pub(u);
    // اطلاعات تماس در فهرست عمومی بازیکنان ارسال نمی‌شود
    return { ...p, email: "", phone: "", online: isConnected(u.id) || (u.lastSeen ?? 0) > now() - ONLINE_MS, isBot: !!u.isDemo };
  }));
}
