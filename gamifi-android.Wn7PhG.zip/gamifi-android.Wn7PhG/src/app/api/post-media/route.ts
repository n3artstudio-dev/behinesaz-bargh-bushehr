import { mkdir, writeFile, unlink } from "node:fs/promises";
import { resolve, join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { pool } from "@/db";
import { getSessionUser, json, uid, now } from "@/lib/auth";
import { getJsonSetting, moderationFlags } from "@/lib/admin";
import { publish } from "@/lib/realtime";

export const runtime = "nodejs";
const MAX_BYTES = 50 * 1024 * 1024;
async function policy(story=false) {
  const me = await getSessionUser();
  const site = await getJsonSetting<Record<string,unknown>>("site-config", {});
  const allowed = !!me && (me.role === "admin" || (story ? (site.allowStoryVideo !== false && me.extra?.allowStoryVideo === true) : (site.allowPostVideo === true && me.extra?.allowVideo === true)));
  return { me, allowed };
}
export async function GET(req:Request) {
  const { me, allowed } = await policy(new URL(req.url).searchParams.get("kind")==="story");
  if (!me) return json({error:"not-authed"},401);
  return json({ allowed, maxSeconds:60, maxBytes:MAX_BYTES });
}
export async function POST(req:Request) {
  const story=new URL(req.url).searchParams.get("kind")==="story";
  const { me, allowed } = await policy(new URL(req.url).searchParams.get("kind")==="story");
  if (!me) return json({error:"not-authed"},401);
  if (!allowed) return json({error:"اجازه انتشار ویدئو برای این حساب فعال نیست."},403);
  // Bound the actual stream, including multipart overhead; Content-Length is not trusted.
  const reader = req.body?.getReader();
  if(!reader) return json({error:"فایل ارسال نشده است"},400);
  const chunks:Uint8Array[]=[];let length=0;
  while(true) {
    const part=await reader.read();if(part.done)break;
    length+=part.value.length;
    if(length>MAX_BYTES+65536){await reader.cancel();return json({error:"حداکثر حجم ویدئو ۵۰ مگابایت است"},413);}
    chunks.push(part.value);
  }
  let form:FormData;
  try { form=await new Response(Buffer.concat(chunks),{headers:{"Content-Type":req.headers.get("Content-Type")||""}}).formData(); }
  catch { return json({error:"فرمت ارسال معتبر نیست"},400); }
  const file=form.get("file");
  const body=String(form.get("body")||"").trim().slice(0,story?500:4000);
  const category=String(form.get("category")||"general");
  if(!(file instanceof File)||file.size===0||file.size>MAX_BYTES||body.length<3) return json({error:"ویدئو و متن حداقل سه‌حرفی لازم است"},400);
  const bytes=Buffer.from(await file.arrayBuffer());
  const mp4=bytes.subarray(4,8).toString()==="ftyp";
  const webm=bytes.subarray(0,4).equals(Buffer.from([0x1a,0x45,0xdf,0xa3]));
  if(!mp4&&!webm)return json({error:"فقط MP4 یا WebM پذیرفته می‌شود"},415);
  if(!(await pool.query('SELECT id FROM categories WHERE id=$1',[category])).rowCount)return json({error:"دسته پیدا نشد"},400);
  const directory=process.env.UPLOAD_DIR || "/var/lib/bu-gamifi/uploads";
  await mkdir(resolve(directory),{recursive:true});
  const id=uid("v"),postId=uid("post"),filename=id+(mp4?".mp4":".webm"),path=join(resolve(directory),filename);
  await writeFile(path,bytes,{flag:"wx",mode:0o640});
  let committed=false;
  try {
    let output:string;
    try {output=(await promisify(execFile)(process.env.FFPROBE_PATH||"ffprobe",["-v","error","-protocol_whitelist","file,pipe","-show_entries","format=duration:stream=codec_type,codec_name,duration","-of","json",path],{timeout:15000,maxBuffer:1024*1024})).stdout;}
    catch {return json({error:"ویدئو قابل بررسی نیست؛ نصب ffprobe و سالم بودن فایل را بررسی کنید"},422);}
    const probe=JSON.parse(output);
    const duration=Number(probe.format?.duration);
    if(!Number.isFinite(duration)||duration<=0||duration>60||!probe.streams?.some((s:{codec_type:string;codec_name:string})=>s.codec_type==="video"&&["h264","vp8","vp9","av1"].includes(s.codec_name)))
      return json({error:"ویدئو باید حداکثر ۶۰ ثانیه و با کدک قابل پخش در مرورگر باشد"},400);
    const flags=await moderationFlags(), status=me.role==="admin"||!(story?flags.moderateStories:flags.moderatePosts)?"approved":"pending",at=now(),media=(story?"/api/story-media/":"/api/post-media/")+id;
    const client=await pool.connect();
    try {
      await client.query("BEGIN");
      if(story){
        await client.query('INSERT INTO stories(id,user_id,user_name,category,title,options,correct,explanation,media,status,auto_approved,created_at,expires_at) VALUES($1,$2,$3,$4,$5,$6::jsonb,0,$7,$8,$9,$10,$11,$12)',[postId,me.id,me.name,category,body,'[]','',media,status,!flags.moderateStories,at,at+86400000]);
        await client.query('INSERT INTO story_media(id,story_id,owner_id,filename,mime,bytes,duration,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[id,postId,me.id,filename,mp4?'video/mp4':'video/webm',bytes.length,duration,at]);
      }else{
      await client.query('INSERT INTO posts(id,user_id,user_name,category,body,media,status,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[postId,me.id,me.name,category,body,media,status,at]);
      await client.query('INSERT INTO post_media(id,post_id,owner_id,filename,mime,bytes,duration,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[id,postId,me.id,filename,mp4?"video/mp4":"video/webm",bytes.length,duration,at]);
      }
      await client.query("COMMIT");committed=true;
    }catch(e){await client.query("ROLLBACK");throw e;}finally{client.release();}
    if(status==="approved")publish("*",story?"feed:story":"feed:post",{id:postId,authorId:me.id,author:me.name,avatar:me.avatar,category,body,title:body,options:[],media,at,expiresAt:story?at+86400000:undefined});
    else publish("*","moderation:pending",{kind:story?"story":"post",id:postId});
    return json({ok:true,id:postId,status});
  }finally{if(!committed)await unlink(path).catch(()=>{});}
}
