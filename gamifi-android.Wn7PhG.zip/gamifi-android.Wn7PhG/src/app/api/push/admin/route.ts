import { json } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";
import {
  getVapid, notifyUser, pushErrors, pushSettingGet, pushSettingSet, pushStats, pushTick, queueBroadcast,
} from "@/lib/push";

/**
 * 🛠️ مدیریت اعلان‌ها — فقط برای مدیر
 * GET  ?view=stats            → آمار (مرورگرها، دستگاه‌ها، صف)
 * GET  ?view=keys             → کلید عمومی VAPID (برای تست)
 * POST ?action=broadcast      → { title, body, link, target } اعلان گروهی + پوش
 * POST ?action=test           → { userId? } ارسال آزمایشی
 * POST ?action=tick           → اجرای فوری کارگر (برای تست)
 * POST ?action=setting        → { key, value } کلیدهای push_*
 */
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const adm = await requireAdmin(req);
  if (!adm) return json({ ok: false, error: "forbidden" }, 403);
  const view = new URL(req.url).searchParams.get("view") || "stats";
  if (view === "keys") {
    const v = await getVapid();
    return json({ ok: true, publicKey: v.publicKey });
  }
  const stats = await pushStats();
  return json({
    ok: true, ...stats,
    enabled: (await pushSettingGet("push_enabled", "on")) === "on",
    dailyReminder: (await pushSettingGet("push_daily_reminder", "on")) === "on",
    lastErrors: pushErrors(),
    subject: await pushSettingGet("push_subject", ""),
  });
}

export async function POST(req: Request) {
  const adm = await requireAdmin(req);
  if (!adm) return json({ ok: false, error: "forbidden" }, 403);
  const action = new URL(req.url).searchParams.get("action") || "";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  if (action === "broadcast") {
    const title = String(b.title || "").trim();
    if (!title) return json({ ok: false, error: "عنوان لازم است" }, 400);
    const r = await queueBroadcast({
      title: title.slice(0, 120),
      body: String(b.body || "").slice(0, 500),
      link: String(b.link || "").slice(0, 60),
      kind: b.urgent ? "invite" : "info",
    }, String(b.target || "all"), Number(b.limit) || 3000);
    return json({ ok: true, ...r, by: adm.name });
  }

  if (action === "test") {
    const userId = String(b.userId || "");
    const target = userId || adm.me?.id;
    if (!target) return json({ ok: false, error: "no-target" }, 400);
    const r = await notifyUser(target, {
      title: String(b.title || "🧪 اعلان آزمایشی گیمیفای"),
      body: String(b.body || "این یک اعلان آزمایشی از پنل مدیریت است.").slice(0, 400),
      link: String(b.link || "#feed"),
      tag: "admin-test-" + Date.now(),
    });
    return json({ ok: true, id: r.id, pushed: r.pushed });
  }

  if (action === "tick") {
    const r = await pushTick(Math.max(1, Math.min(100, Number(b.batch) || 60)));
    return json({ ok: true, ...r, stats: await pushStats() });
  }

  if (action === "setting") {
    const key = String(b.key || "");
    if (!key.startsWith("push_")) return json({ ok: false, error: "bad-key" }, 400);
    await pushSettingSet(key, String(b.value ?? "").slice(0, 200));
    return json({ ok: true, key, value: String(b.value ?? "") });
  }

  return json({ ok: false, error: "unknown-action" }, 400);
}
