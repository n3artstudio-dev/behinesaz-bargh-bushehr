import { json } from "@/lib/auth";
import { pendingForDevice } from "@/lib/push";

/**
 * 📲 اعلان‌های تازهٔ یک دستگاه اپ (برای اپ اندروید)
 * GET /api/push/pending?dt=<device-token>&since=<last-ms>&limit=30
 *
 * اپ اندروید هر ۱۵ دقیقه (و هنگام باز شدن) این آدرس را صدا می‌زند و اعلان‌های تازه را
 * به‌صورت اعلان سیستمی نشان می‌دهد. توکن دستگاه، خودش نقش رمز را دارد و کوتاه‌عمر نیست
 * ولی فقط خواندنی است (فقط اعلان‌های همان کاربر را می‌دهد).
 */
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const u = new URL(req.url);
  const dt = (u.searchParams.get("dt") || "").trim();
  const since = Number(u.searchParams.get("since") || 0);
  const limit = Number(u.searchParams.get("limit") || 30);
  const r = await pendingForDevice(dt, since, limit);
  if (!r.ok) return json({ ok: false, error: "bad-token", items: [], now: Date.now() }, 401);
  return json({ ok: true, items: r.items, now: Date.now(), count: r.items.length });
}
