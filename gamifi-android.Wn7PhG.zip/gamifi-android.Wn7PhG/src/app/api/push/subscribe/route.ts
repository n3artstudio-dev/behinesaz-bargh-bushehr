import { getSessionUser, json } from "@/lib/auth";
import { getVapid, pushSettingGet, saveWebSubscription } from "@/lib/push";

/**
 * 📥 ثبت اشتراک مرورگر برای دریافت اعلان
 * بدنه: { endpoint, keys: { p256dh, auth }, ua? }
 * هویت فقط از نشست معتبر خوانده می‌شود (کوکی/token) — نه از بدنهٔ درخواست.
 */
export const dynamic = "force-dynamic";

const hits = new Map<string, number[]>();
function tooMany(key: string, limit = 20): boolean {
  const t = Date.now();
  const arr = (hits.get(key) || []).filter((x) => x > t - 60000);
  if (arr.length >= limit) return true;
  arr.push(t);
  hits.set(key, arr);
  if (hits.size > 4000) hits.clear();
  return false;
}

export async function POST(req: Request) {
  const me = await getSessionUser();
  if (me?.extra?.pushEnabled === false) return json({ok:false,error:"notifications-disabled"},403);
  if (!me) return json({ ok: false, error: "not-authed", message: "برای فعال‌کردن اعلان‌ها اول وارد بازی شو." }, 401);
  if (tooMany(me.id)) return json({ ok: false, error: "rate-limit" }, 429);
  if ((await pushSettingGet("push_enabled", "on")) !== "on") {
    return json({ ok: false, error: "disabled", message: "اعلان‌ها توسط مدیر خاموش شده است." }, 403);
  }
  let b: { endpoint?: string; keys?: { p256dh?: string; auth?: string }; ua?: string } = {};
  try { b = await req.json(); } catch { b = {}; }

  const endpoint = String(b.endpoint || "").trim();
  const p256dh = String(b.keys?.p256dh || "").trim();
  const auth = String(b.keys?.auth || "").trim();
  if (!endpoint || !p256dh || !auth) return json({ ok: false, error: "missing-fields" }, 400);

  const r = await saveWebSubscription(me.id, { endpoint, p256dh, auth, ua: String(b.ua || "") });
  if (!r.ok) return json({ ok: false, error: r.error }, 400);
  return json({ ok: true, key: (await getVapid()).publicKey.slice(0, 8), at: Date.now() });
}
