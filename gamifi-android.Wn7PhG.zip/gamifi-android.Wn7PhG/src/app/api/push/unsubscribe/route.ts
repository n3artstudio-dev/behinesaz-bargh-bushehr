import { getSessionUser, json } from "@/lib/auth";
import { deactivate } from "@/lib/push";

/** 🔕 خاموش‌کردن اعلان‌ها (حذف اشتراک مرورگر یا دستگاه اپ) */
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const me = await getSessionUser();
  let b: { endpoint?: string; deviceId?: string } = {};
  try { b = await req.json(); } catch { b = {}; }
  const n = await deactivate({ endpoint: String(b.endpoint || ""), deviceId: String(b.deviceId || "") });
  return json({ ok: true, removed: n, me: me?.id ?? null });
}
