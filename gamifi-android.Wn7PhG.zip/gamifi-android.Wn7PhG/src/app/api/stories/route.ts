import {ensureBotStory} from "@/lib/bot-stories";
import { pool } from "@/db";
import { getSessionUser, json, now } from "@/lib/auth";
import { STORY_LIFETIME_MS, STORY_MAIN_LIMIT } from "@/lib/story-policy";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed" }, 401);
  await ensureBotStory().catch(e=>console.error("bot-story publication failed",e instanceof Error?e.message:"error"));
  const params = new URL(req.url).searchParams;
  const more = params.get("view") === "more";
  const offset = Number(params.get("offset") || 0);
  if (!Number.isSafeInteger(offset) || offset < 0 || offset > 100000) return json({ error: "invalid-offset" },400);
  const at = now(), limit = more ? 30 : STORY_MAIN_LIMIT;
  const result = await pool.query(`
    WITH active AS (
      SELECT s.*, u.avatar, coalesce(u.is_demo,false) AS is_bot, (v.story_id IS NOT NULL) AS seen,
        row_number() OVER (ORDER BY (v.story_id IS NOT NULL), coalesce(u.is_demo,false), s.created_at DESC, s.id) AS position
      FROM stories s LEFT JOIN users u ON u.id=s.user_id
      LEFT JOIN story_views v ON v.story_id=s.id AND v.user_id=$1
      WHERE s.title NOT IN ('به‌روزرسانی همراهی','به روز رسانی همراهی') AND s.status='approved' AND s.expires_at>$2 AND s.created_at>$3 AND s.created_at<=$2
    )
    SELECT * FROM active WHERE ${more ? "(seen OR position > $4)" : "(NOT seen AND position <= $4)"}
    ORDER BY seen,is_bot,created_at DESC,id LIMIT $5 OFFSET $6`,
    [me.id,at,at-STORY_LIFETIME_MS,STORY_MAIN_LIMIT,limit+1,more?offset:0]);
  return json({ serverNow: at, hasMore: result.rows.length>limit, stories: result.rows.slice(0,limit).map(s=>({
    id:s.id, userId:s.user_id, author:s.user_name, avatar:s.avatar, title:s.title,
    media:s.media, options:s.options, createdAt:Number(s.created_at),
    expiresAt:Math.min(Number(s.expires_at),Number(s.created_at)+STORY_LIFETIME_MS),seen:s.seen,
  })) });
}

export async function POST(req: Request) {
  const me = await getSessionUser();
  if (!me) return json({ error:"not-authed" },401);
  const body = await req.json().catch(()=>null);
  if (!body || typeof body.id!=="string") return json({ error:"invalid-story" },400);
  const at=now();
  const result=await pool.query(`INSERT INTO story_views(story_id,user_id,viewed_at)
    SELECT id,$2,$3 FROM stories WHERE id=$1 AND status='approved' AND expires_at>$3 AND created_at>$4 AND created_at<=$3
    ON CONFLICT(story_id,user_id) DO UPDATE SET viewed_at=story_views.viewed_at RETURNING story_id`,
    [body.id,me.id,at,at-STORY_LIFETIME_MS]);
  if (!result.rowCount) return json({error:"story-expired-or-unavailable"},404);
  if (body.answer !== undefined) {
    if (!Number.isInteger(body.answer) || body.answer<0 || body.answer>3) return json({error:"invalid-answer"},400);
    const answer=await pool.query('SELECT correct,explanation FROM stories WHERE id=$1',[body.id]);
    return json({ok:true,correct:answer.rows[0].correct,explanation:answer.rows[0].explanation});
  }
  return json({ok:true});
}
