import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { Readable } from "node:stream";
import { resolve, basename, join } from "node:path";
import { pool } from "@/db";
import { getSessionUser, json } from "@/lib/auth";
import { requireAdmin } from "@/lib/admin";
export const runtime="nodejs";
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}) {
  const {id}=await params;
  if(!/^v[a-f0-9]{12}$/.test(id))return json({error:"not-found"},404);
  const result=await pool.query('SELECT m.*,p.status,p.expires_at FROM story_media m JOIN stories p ON p.id=m.story_id WHERE m.id=$1',[id]);
  const row=result.rows[0];if(!row)return json({error:"not-found"},404);
  if(row.status!=="approved" || Number(row.expires_at)<=Date.now()) {
    const me=await getSessionUser();
    if(me?.id!==row.owner_id&&!(await requireAdmin(req)))return json({error:"forbidden"},403);
  }
  if(basename(row.filename)!==row.filename)return json({error:"unavailable"},503);
  const path=join(resolve(process.env.UPLOAD_DIR || "/var/lib/bu-gamifi/uploads"),row.filename);
  let size:number;try{size=(await stat(path)).size;}catch{return json({error:"not-found"},404);}
  let start=0,end=size-1,status=200;
  const range=req.headers.get("range");
  if(range) {
    const match=/^bytes=(\d*)-(\d*)$/.exec(range);
    if(!match||(!match[1]&&!match[2]))return new Response(null,{status:416,headers:{"Content-Range":`bytes */${size}`}});
    if(!match[1]){start=Math.max(0,size-Number(match[2]));}else{start=Number(match[1]);if(match[2])end=Math.min(size-1,Number(match[2]));}
    if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=size)return new Response(null,{status:416,headers:{"Content-Range":`bytes */${size}`}});
    status=206;
  }
  return new Response(Readable.toWeb(createReadStream(path,{start,end})) as ReadableStream,{status,headers:{"Content-Type":row.mime,"Content-Length":String(end-start+1),"Accept-Ranges":"bytes","Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff",...(status===206?{"Content-Range":`bytes ${start}-${end}/${size}`}:{})}});
}
