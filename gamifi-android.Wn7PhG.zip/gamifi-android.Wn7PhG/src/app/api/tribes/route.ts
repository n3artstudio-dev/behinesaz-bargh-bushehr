import { desc, eq, like, or, count, sql } from "drizzle-orm";
import { fixAvatar } from "@/lib/avatar-guard";
import { db } from "@/db";
import { tribes, tribeMembers, users, userAchievements, notifications } from "@/db/schema";
import { uid, now, json, getSessionUser, createSession, setAuthCookie } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET: فهرست قبیله‌ها (?q= جست‌وجو, ?mine=1 قبیلهٔ من)
export async function GET(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  const url = new URL(req.url);
  const q = url.searchParams.get("q") || "";
  const mine = url.searchParams.get("mine") === "1";

  if (mine) {
    if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو" }, 401);
    const membership = await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).limit(1);
    if (!membership[0]) return json({ tribe: null });
    const t = (await db.select().from(tribes).where(eq(tribes.id, membership[0].tribeId)).limit(1))[0];
    if (!t) return json({ tribe: null });
    const members = await db.select({ m: tribeMembers, u: users }).from(tribeMembers)
      .leftJoin(users, eq(users.id, tribeMembers.userId)).where(eq(tribeMembers.tribeId, t.id));
    return json({
      tribe: { ...t, memberCount: members.length, myRole: membership[0].role },
      members: members.map((r) => ({
        id: r.u?.id,
        name: r.u?.name,
        avatar: r.u?.avatar,
        xp: r.u?.xp,
        level: r.u?.level,
        role: r.m.role,
        contributedXp: r.m.contributedXp,
        online: (r.u?.lastSeen ?? 0) > now() - 5 * 60000,
      })),
    });
  }

  let rows;
  if (q) {
    rows = await db.select().from(tribes).where(or(like(tribes.name, `%${q}%`), like(tribes.tag, `%${q}%`))).orderBy(desc(tribes.xp)).limit(60);
  } else {
    rows = await db.select().from(tribes).orderBy(desc(tribes.xp)).limit(60);
  }
  const out = [];
  for (const t of rows) {
    const c = await db.select({ c: count() }).from(tribeMembers).where(eq(tribeMembers.tribeId, t.id));
    const isMember = me ? !!(await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).then((r) => r.find((x) => x.tribeId === t.id))) : false;
    out.push({ ...t, memberCount: Number(c[0]?.c ?? 0), isMember });
  }
  return json(out);
}

// POST: ساخت قبیله
export async function POST(req: Request) {
  await ensureSeed();
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  let me = await getSessionUser();

  // اگر هنوز نشست ایجاد نشده ولی پروفایل در درخواست هست:
  if (!me && b.profile && typeof b.profile === "object") {
    const prof = b.profile as Record<string, unknown>;
    const pLocalId = String(prof.id || prof.localId || "");
    const pName = String(prof.name || "بازیکن").slice(0, 40) || "بازیکن";
    if (pLocalId) {
      const existingUser = (await db.select().from(users).where(or(eq(users.id, pLocalId), eq(users.localId, pLocalId))).limit(1))[0];
      if (existingUser) {
        me = existingUser;
      } else {
        const newId = pLocalId || uid("u");
        await db.insert(users).values({
          id: newId,
          localId: pLocalId || newId,
          name: pName,
          avatar: fixAvatar(prof.avatar, pName),
          bio: String(prof.bio || "").slice(0, 300),
          email: String(prof.email || ""),
          phone: String(prof.phone || ""),
          provider: String(prof.provider || "guest"),
          role: "player",
          orgId: String(prof.org || prof.orgId || ""),
          xp: Number(prof.xp) || 0,
          coins: Number(prof.coins) || 50,
          cups: Number(prof.cups) || 0,
          streak: Number(prof.streak) || 0,
          wins: Number(prof.wins) || 0,
          played: Number(prof.played) || 0,
          rating: Number(prof.rating) || 1000,
          weekXp: Number(prof.xp) || 0,
          level: Math.floor((Number(prof.xp) || 0) / 250) + 1,
          interests: Array.isArray(prof.interests) ? (prof.interests as string[]) : [],
          friends: [],
          isPrivate: false,
          banned: false,
          isDemo: false,
          lastSeen: now(),
          lastDaily: "",
          createdAt: now(),
          extra: {},
        }).onConflictDoNothing();
        me = (await db.select().from(users).where(eq(users.id, newId)).limit(1))[0] || null;
      }
    }
  }

  if (!me) {
    return json({ error: "not-authed", message: "ابتدا از بالای صفحه وارد بازی شو 🌱" }, 401);
  }

  const name = String(b.name || "").trim().slice(0, 30);
  if (name.length < 3) return json({ error: "نام قبیله باید دست‌کم ۳ حرف باشد." }, 400);
  const tag = String(b.tag || "").trim().slice(0, 8) || name.slice(0, 3);
  
  // بررسی عضویت قبلی
  const existing = await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).limit(1);
  if (existing[0]) return json({ error: "تو الان عضو یک قبیله هستی! اول از آن خارج شو." }, 400);

  const id = uid("tribe");
  const inviteCode = Math.random().toString(36).slice(2, 8).toUpperCase();
  await db.insert(tribes).values({
    id,
    name,
    tag,
    description: String(b.description || "").slice(0, 300),
    motto: String(b.motto || "با هم قوی‌تریم! 💪").slice(0, 120),
    logoEmoji: String(b.logoEmoji || "🛡️").slice(0, 8),
    logoColor: String(b.logoColor || "#a98cf7").slice(0, 20),
    ownerId: me.id,
    maxMembers: 30,
    wins: 0,
    losses: 0,
    xp: 0,
    rating: 1000,
    isPublic: b.isPublic !== false,
    inviteCode,
    createdAt: now(),
  });
  await db.insert(tribeMembers).values({
    tribeId: id,
    userId: me.id,
    role: "owner",
    contributedXp: 0,
    joinedAt: now(),
  });

  // دستاورد بنیان‌گذار
  try {
    await db.insert(userAchievements).values({ userId: me.id, achievementId: "tribe-founder", unlockedAt: now() }).onConflictDoNothing();
    await db.update(users).set({ xp: sql`${users.xp} + 200`, coins: sql`${users.coins} + 100` }).where(eq(users.id, me.id));
    await db.insert(notifications).values({ id: uid("n"), userId: me.id, title: "🛡️ قبیله‌ات ساخته شد!", body: `«${name}» آمادهٔ نبرد است. دوستانت را دعوت کن!`, link: "#tribes", createdAt: now(), seen: 0 });
  } catch { /* ignore */ }

  const t = (await db.select().from(tribes).where(eq(tribes.id, id)).limit(1))[0];
  const { token } = await createSession(me.id);
  const res = json({ ok: true, tribe: { ...t, memberCount: 1, myRole: "owner" }, serverToken: token });
  return setAuthCookie(res, token);
}
