"use client";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
export default function VideoComposer(){
  const [kind,setKind]=useState("post");
  const [open,setOpen]=useState(false),[allowed,setAllowed]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState("");
  const [categories,setCategories]=useState<{id:string;name:string}[]>([]);
  const dialog=useRef<HTMLDialogElement>(null);
  useEffect(()=>{const show=()=>{setKind('post');setOpen(true);},story=()=>{setKind('story');setOpen(true);};window.addEventListener('gamify:video-compose',show);window.addEventListener('gamify:story-video-compose',story);return()=>{window.removeEventListener('gamify:video-compose',show);window.removeEventListener('gamify:story-video-compose',story);};},[]);
  useEffect(()=>{
    if(!open)return;
    dialog.current?.showModal();setAllowed(false);setMessage('در حال بررسی مجوز…');
    let canceled=false;
    void (async()=>{
      try{
        await window.__gamifyBootstrap;
        const [policy,config]=await Promise.all([fetch('/api/post-media?kind='+kind,{credentials:'include',cache:'no-store'}),fetch('/api/site-config',{cache:'no-store'})]);
        if(!policy.ok||!config.ok)throw Error('ارتباط با سرور برقرار نشد.');
        const p=await policy.json(),c=await config.json();if(canceled)return;
        setAllowed(p.allowed);setCategories(c.categories||[]);setMessage(p.allowed?'حداکثر ۶۰ ثانیه، ۵۰ مگابایت؛ MP4 یا WebM.':'اجازه انتشار ویدئو برای شما فعال نیست؛ با مدیر هماهنگ کنید.');
      }catch(e){if(!canceled)setMessage((e as Error).message);}
    })();
    return()=>{canceled=true;};
  },[open,kind]);
  if(!open)return null;
  return createPortal(<dialog ref={dialog} onCancel={()=>{if(!busy)setOpen(false);}} style={{background:'#241b30',color:'#eee5f5',border:'1px solid #554164',borderRadius:20,padding:24,width:'min(92vw,520px)'}} dir="rtl">
    <h2>{kind==="story"?"انتشار استوری ویدئویی":"انتشار ویدئو"}</h2><p role="status">{message}</p>
    <form onSubmit={async e=>{
      e.preventDefault();if(busy||!allowed)return;
      const form=e.currentTarget;setBusy(true);setMessage('در حال ارسال و بررسی ویدئو…');
      try{const r=await fetch('/api/post-media?kind='+kind,{method:'POST',credentials:'include',body:new FormData(form)});const data=await r.json();if(!r.ok)throw Error(data.error||'ارسال ناموفق بود');form.reset();window.dispatchEvent(new Event("gamify:stories-changed"));setMessage(data.status==='pending'?'ثبت شد؛ پس از تأیید مدیر منتشر می‌شود.':'ویدئو منتشر شد.');}
      catch(error){setMessage((error as Error).message);}finally{setBusy(false);}
    }}>
      <textarea className="field" name="body" required minLength={3} maxLength={4000} placeholder="توضیح ویدئو" disabled={!allowed||busy}/>
      <select className="field" name="category" required disabled={!allowed||busy}><option value="">دسته را انتخاب کنید</option>{categories.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select>
      <input type="file" name="file" accept="video/mp4,video/webm" required disabled={!allowed||busy}/>
      <div style={{display:'flex',gap:10,marginTop:20}}><button className="btn" disabled={!allowed||busy}>ارسال ویدئو</button><button className="btn ghost" type="button" disabled={busy} onClick={()=>setOpen(false)}>بستن</button></div>
    </form>
  </dialog>,document.body);
}
