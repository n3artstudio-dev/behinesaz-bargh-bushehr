/**
 * 🚀 راه‌انداز سرویس‌های زمان اجرا (Next.js Instrumentation)
 * کارگر اعلان‌ها اینجا روشن می‌شود تا هر اعلانی که سایت می‌سازد
 * (دعوت به مبارزه، دعوت قبیله، تأیید پست، پیام مدیر و…) بلافاصله به گوشی برسد.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME === "edge") return;
  try {
    const { startPushWorker } = await import("@/lib/push");
    startPushWorker();
  } catch { /* اگر دیتابیس آماده نبود، سایت باید بدون این سرویس هم بالا بیاید */ }
}
