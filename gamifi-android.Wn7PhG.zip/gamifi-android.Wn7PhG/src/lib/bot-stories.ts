import {pool} from '@/db';
import {getJsonSetting,moderationFlags} from '@/lib/admin';
import {publish} from '@/lib/realtime';
let nextCheck=0;
/** Shared server publication; never accepts a client-selected author. */
export async function ensureBotStory(){
 const at=Date.now();if(at<nextCheck)return;nextCheck=at+60000;
 const config=await getJsonSetting<Record<string,unknown>>('site-config',{});
 if(config.botStoriesEnabled===false||config.staffActivity===false||config.botEnabled===false)return;
 const raw=Number(config.botStoryIntervalMinutes||40),minutes=Number.isFinite(raw)?Math.max(10,Math.min(1440,raw)):40;
 const bucket=Math.floor(at/(minutes*60000)),id='bot-story-'+bucket;
 const c=await pool.connect();
 try{
  await c.query('BEGIN');
  const lock=await c.query('SELECT pg_try_advisory_xact_lock(20261022,1) AS ok');if(!lock.rows[0].ok){await c.query('ROLLBACK');return;}
  if((await c.query('SELECT 1 FROM stories WHERE id=$1',[id])).rowCount){await c.query('COMMIT');return;}
  const u=(await c.query("SELECT id,name,avatar FROM users WHERE is_demo=true AND coalesce(banned,false)=false ORDER BY random() LIMIT 1")).rows[0];
  if(!u){await c.query('COMMIT');return;}
  // Use only approved bank questions; robots do not fabricate content.
  const q=(await c.query("SELECT id,title,category,options,correct,explanation FROM questions WHERE status='approved' AND jsonb_array_length(options)=4 ORDER BY random() LIMIT 1")).rows[0];
  if(!q){await c.query('COMMIT');return;}
  const flags=await moderationFlags(),status=flags.moderateStories?'pending':'approved';
  await c.query('INSERT INTO stories(id,user_id,user_name,category,title,options,correct,explanation,media,status,auto_approved,created_at,expires_at) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT DO NOTHING',[id,u.id,u.name,q.category,q.title,JSON.stringify(q.options),q.correct,q.explanation||'','',status,!flags.moderateStories,at,at+86400000]);
  await c.query('COMMIT');
  if(status==='pending')publish('*','moderation:pending',{id,kind:'story'});else publish('*','feed:story',{id,kind:'story',authorId:u.id,author:u.name,avatar:u.avatar,title:q.title,category:q.category,options:q.options,at,expiresAt:at+86400000});
 }catch(e){await c.query('ROLLBACK');nextCheck=Date.now()+60000;throw e;}finally{c.release();}
}