/**
 * 🔔 موتور اعلان‌های گیمیفای ۲
 *
 * این فایل قلب سیستم اعلان است:
 *  ۱) ذخیرهٔ اشتراک مرورگرها (Web Push) و دستگاه‌های اپ اندروید
 *  ۲) ارسال پوش به مرورگر با موتور داخلی (بدون بستهٔ npm بیرونی)
 *  ۳) «کارگر اعلان»: هر ۱۵ ثانیه اعلان‌های تازه‌ای که هر جای سایت ساخته می‌شوند
 *     (دعوت به مبارزه، دعوت قبیله، تأیید پست/استوری، پیام مدیر و…) را می‌بیند و
 *     برای کاربر به گوشی/مرورگر می‌فرستد. بنابراین هیچ‌کدام از کدهای قبلی سایت
 *     نیاز به تغییر ندارند؛ فقط کافی است یک ردیف در جدول notifications درج شود.
 *
 * همهٔ پرس‌وجوها روی همان pool اتصال موجود سایت اجرا می‌شوند (بدون وابستگی تازه).
 */
import { pool } from "@/db";
import { randomBytes, randomUUID } from "node:crypto";
import { publish } from "@/lib/realtime";
import { isSafeEndpoint, newVapidKeys, sendWebPush, type VapidKeys } from "@/lib/webpush";

const VAPID_KEY = "push_vapid";
const SINCE_KEY = "push_since";
const WORKER_MS = 15000;

export type PushKind = "web" | "device";
export type SubRow = {
  id: string; user_id: string; kind: PushKind; endpoint: string; p256dh: string;
  auth: string; token: string; ua: string; active: number; fails: number;
  created_at: number; last_seen: number;
};

let vapidCache: VapidKeys | null = null;
let schemaReady = false;

/* ------------------------------------------------------------------ */
/*  جدول‌ها                                                            */
/* ------------------------------------------------------------------ */

export async function ensurePushSchema(): Promise<void> {
  if (schemaReady) return;
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS push_subs (
        id text PRIMARY KEY,
        user_id text NOT NULL,
        kind text NOT NULL DEFAULT 'web',
        endpoint text NOT NULL,
        p256dh text NOT NULL DEFAULT '',
        auth text NOT NULL DEFAULT '',
        token text NOT NULL DEFAULT '',
        ua text NOT NULL DEFAULT '',
        active integer NOT NULL DEFAULT 1,
        fails integer NOT NULL DEFAULT 0,
        created_at bigint NOT NULL,
        last_seen bigint NOT NULL DEFAULT 0
      )`);
    await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS push_subs_uniq ON push_subs (kind, endpoint)`);
    await pool.query(`CREATE INDEX IF NOT EXISTS push_subs_user_idx ON push_subs (user_id, active)`);
    await pool.query(`ALTER TABLE notifications ADD COLUMN IF NOT EXISTS push_sent integer NOT NULL DEFAULT 0`);
    schemaReady = true;
  } catch { /* بدون جدول هم سایت باید کار کند */ }
}

/** در زمان نصب: اعلان‌های قدیمی پوش نشوند (جلوگیری از سیل اعلان) */
export async function markExistingAsSent(): Promise<number> {
  try {
    const r = await pool.query(
      `UPDATE notifications SET push_sent = 1 WHERE push_sent = 0 OR push_sent IS NULL`);
    const t = Date.now();
    await pool.query(
      `INSERT INTO settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
      [SINCE_KEY, String(t)]);
    return r.rowCount ?? 0;
  } catch {
    return 0;
  }
}

async function sinceMs(): Promise<number> {
  try {
    const r = await pool.query(`SELECT value FROM settings WHERE key = $1 LIMIT 1`, [SINCE_KEY]);
    const v = Number(r.rows[0]?.value || 0);
    if (v > 0) return v;
  } catch { /* ignore */ }
  return Date.now() - 86400000;
}

async function settingGet(key: string, def: string): Promise<string> {
  try {
    const r = await pool.query(`SELECT value FROM settings WHERE key = $1 LIMIT 1`, [key]);
    return r.rows[0]?.value ?? def;
  } catch { return def; }
}

async function settingSet(key: string, value: string): Promise<void> {
  try {
    await pool.query(
      `INSERT INTO settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
      [key, value]);
  } catch { /* ignore */ }
}

/* ------------------------------------------------------------------ */
/*  کلیدهای VAPID                                                      */
/* ------------------------------------------------------------------ */

export async function getVapid(): Promise<VapidKeys> {
  if (vapidCache) return vapidCache;
  await ensurePushSchema();
  try {
    const r = await pool.query(`SELECT value FROM settings WHERE key = $1 LIMIT 1`, [VAPID_KEY]);
    if (r.rows[0]?.value) {
      const j = JSON.parse(String(r.rows[0].value)) as VapidKeys;
      if (j.publicKey && j.privateKey) { vapidCache = j; return j; }
    }
  } catch { /* ignore */ }
  const fresh = newVapidKeys();
  try {
    await pool.query(
      `INSERT INTO settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING`,
      [VAPID_KEY, JSON.stringify(fresh)]);
    const r = await pool.query(`SELECT value FROM settings WHERE key = $1 LIMIT 1`, [VAPID_KEY]);
    if (r.rows[0]?.value) {
      const j = JSON.parse(String(r.rows[0].value)) as VapidKeys;
      if (j.publicKey && j.privateKey) { vapidCache = j; return j; }
    }
  } catch { /* ignore */ }
  vapidCache = fresh;
  return fresh;
}

/* ------------------------------------------------------------------ */
/*  اشتراک‌ها                                                          */
/* ------------------------------------------------------------------ */

export async function saveWebSubscription(userId: string, s: {
  endpoint: string; p256dh: string; auth: string; ua?: string;
}): Promise<{ ok: boolean; error?: string }> {
  await ensurePushSchema();
  if (!isSafeEndpoint(s.endpoint)) return { ok: false, error: "unsafe-endpoint" };
  if (!s.p256dh || !s.auth) return { ok: false, error: "missing-keys" };
  try {
    await pool.query(
      `INSERT INTO push_subs (id, user_id, kind, endpoint, p256dh, auth, token, ua, active, fails, created_at, last_seen)
       VALUES ($1,$2,'web',$3,$4,$5,'',$6,1,0,$7,$7)
       ON CONFLICT (kind, endpoint) DO UPDATE SET
         user_id = EXCLUDED.user_id, p256dh = EXCLUDED.p256dh, auth = EXCLUDED.auth,
         ua = EXCLUDED.ua, active = 1, fails = 0, last_seen = EXCLUDED.last_seen`,
      [randomUUID(), userId, s.endpoint, s.p256dh, s.auth, String(s.ua || "").slice(0, 300), Date.now()]);
    // 🧹 هر کاربر حداکثر ۱۰ اشتراک مرورگر فعال داشته باشد (اشتراک‌های مرده پاک می‌شوند)
    await pool.query(
      `UPDATE push_subs SET active = 0 WHERE kind = 'web' AND user_id = $1 AND id NOT IN (
         SELECT id FROM push_subs WHERE kind = 'web' AND user_id = $1 AND active = 1
         ORDER BY last_seen DESC LIMIT 10)`, [userId]);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String((e as Error)?.message || e) };
  }
}

/** ثبت دستگاه اپ اندروید؛ خروجی توکن مخصوص دستگاه است (برای دریافت اعلان در پس‌زمینه) */
export async function saveDevice(userId: string, deviceId: string, ua = ""): Promise<{ ok: boolean; token?: string; error?: string }> {
  await ensurePushSchema();
  const id = String(deviceId || "").trim();
  if (!/^[A-Za-z0-9._:-]{8,80}$/.test(id)) return { ok: false, error: "bad-device-id" };
  try {
    const existing = await pool.query(
      `SELECT token, user_id FROM push_subs WHERE kind = 'device' AND endpoint = $1 LIMIT 1`, ["device:" + id]);
    let token = String(existing.rows[0]?.token || "");
    if (!token) token = randomBytes(24).toString("hex");
    if (existing.rows[0]) {
      await pool.query(
        `UPDATE push_subs SET user_id = $1, active = 1, last_seen = $2, ua = $3 WHERE kind = 'device' AND endpoint = $4`,
        [userId, Date.now(), String(ua).slice(0, 300), "device:" + id]);
    } else {
      await pool.query(
        `INSERT INTO push_subs (id, user_id, kind, endpoint, p256dh, auth, token, ua, active, fails, created_at, last_seen)
         VALUES ($1,$2,'device',$3,'','',$4,$5,1,0,$6,$6)`,
        [randomUUID(), userId, "device:" + id, token, String(ua).slice(0, 300), Date.now()]);
    }
    return { ok: true, token };
  } catch (e) {
    return { ok: false, error: String((e as Error)?.message || e) };
  }
}

export async function deactivate(param: { endpoint?: string; deviceId?: string }): Promise<number> {
  await ensurePushSchema();
  try {
    if (param.endpoint) {
      const r = await pool.query(
        `UPDATE push_subs SET active = 0 WHERE kind = 'web' AND endpoint = $1`, [param.endpoint]);
      return r.rowCount ?? 0;
    }
    if (param.deviceId) {
      const r = await pool.query(
        `UPDATE push_subs SET active = 0 WHERE kind = 'device' AND endpoint = $1`, ["device:" + param.deviceId]);
      return r.rowCount ?? 0;
    }
  } catch { /* ignore */ }
  return 0;
}

export async function subsOf(userId: string): Promise<SubRow[]> {
  try {
    const r = await pool.query(`SELECT * FROM push_subs WHERE user_id = $1 AND active = 1`, [userId]);
    return r.rows as SubRow[];
  } catch { return []; }
}

/** اعلان‌های تازه برای دستگاه اپ (پول‌کردن با توکن دستگاه) */
export async function pendingForDevice(token: string, since: number, limit = 30) {
  await ensurePushSchema();
  const t = String(token || "");
  if (!/^[a-f0-9]{16,80}$/i.test(t)) return { ok: false as const, items: [], userId: "" };
  try {
    const s = await pool.query(
      `SELECT user_id FROM push_subs WHERE kind = 'device' AND token = $1 AND active = 1 LIMIT 1`, [t]);
    const userId = String(s.rows[0]?.user_id || "");
    if (!userId) return { ok: false as const, items: [], userId: "" };
    await pool.query(`UPDATE push_subs SET last_seen = $1 WHERE token = $2`, [Date.now(), t]);
    const r = await pool.query(
      `SELECT id, title, body, link, created_at FROM notifications
        WHERE user_id = $1 AND created_at > $2 ORDER BY created_at ASC LIMIT $3`,
      [userId, Math.max(0, Number(since) || 0), Math.max(1, Math.min(50, Number(limit) || 30))]);
    return { ok: true as const, items: r.rows, userId };
  } catch {
    return { ok: false as const, items: [], userId: "" };
  }
}

export async function markSeen(userId: string, ids: string[] | "all"): Promise<number> {
  try {
    if (ids === "all") {
      const r = await pool.query(`UPDATE notifications SET seen = 1 WHERE user_id = $1 AND seen = 0`, [userId]);
      return r.rowCount ?? 0;
    }
    const list = (ids || []).slice(0, 100).filter((x) => typeof x === "string" && x.length < 60);
    if (!list.length) return 0;
    const r = await pool.query(`UPDATE notifications SET seen = 1 WHERE user_id = $1 AND id = ANY($2)`, [userId, list]);
    return r.rowCount ?? 0;
  } catch { return 0; }
}

/* ------------------------------------------------------------------ */
/*  ارسال                                                              */
/* ------------------------------------------------------------------ */

const perUserLimit = new Map<string, number[]>();
function rateOk(userId: string, limit = 12): boolean {
  const t = Date.now();
  const arr = (perUserLimit.get(userId) || []).filter((x) => x > t - 60000);
  if (arr.length >= limit) return false;
  arr.push(t);
  perUserLimit.set(userId, arr);
  if (perUserLimit.size > 5000) perUserLimit.clear();
  return true;
}

export type PushMsg = { title: string; body?: string; link?: string; tag?: string; image?: string; kind?: "invite" | "info" };

/** ارسال پوش به همهٔ مرورگرهای ثبت‌شدهٔ یک کاربر */
export async function pushToUser(userId: string, msg: PushMsg): Promise<number> {
  const subj = await settingGet("push_subject", "");
  const base = (process.env.BASE_URL || "").replace(/\/+$/, "");
  const subject = subj || (base ? base + "/" : "mailto:admin@bu.gamifi.ir");
  const subs = await subsOf(userId);
  let sent = 0;
  for (const s of subs) {
    if (s.kind !== "web") continue;
    const r = await sendWebPush(
      { endpoint: s.endpoint, p256dh: s.p256dh, auth: s.auth },
      { title: msg.title, body: msg.body || "", link: msg.link || "", tag: msg.tag || "", image: msg.image || "", at: Date.now() },
      await getVapid(),
      { subject, ttl: 86400, urgency: msg.kind === "invite" ? "high" : "normal" },
    );
    if (r.ok) { sent++; continue; }
    rememberError(r.status, String(r.error || ""), s.endpoint);
    if (r.gone) {
      try { await pool.query(`UPDATE push_subs SET active = 0 WHERE id = $1`, [s.id]); } catch { /* ignore */ }
    } else {
      try { await pool.query(`UPDATE push_subs SET fails = fails + 1, active = CASE WHEN fails >= 8 THEN 0 ELSE active END WHERE id = $1`, [s.id]); } catch { /* ignore */ }
    }
  }
  return sent;
}

/**
 * ساخت اعلان برای یک کاربر: در «صندوق اعلان» ذخیره می‌شود،
 * زنده به صفحهٔ بازش فرستاده می‌شود و پوش هم می‌رود.
 * (اعلان‌هایی که خودِ سایت با درج مستقیم می‌سازد را کارگرِ پس‌زمینه می‌فرستد.)
 */
export async function notifyUser(userId: string, msg: PushMsg): Promise<{ id: string; pushed: number }> {
  await ensurePushSchema();
  const id = "n" + randomUUID().replace(/-/g, "").slice(0, 12);
  try {
    await pool.query(
      `INSERT INTO notifications (id, user_id, title, body, link, created_at, seen, push_sent)
       VALUES ($1,$2,$3,$4,$5,$6,0,1)`,
      [id, userId, String(msg.title).slice(0, 200), String(msg.body || "").slice(0, 600), String(msg.link || "").slice(0, 80), Date.now()]);
  } catch { /* ignore */ }
  try {
    publish([userId], "notify", { id, title: msg.title, body: msg.body || "", link: msg.link || "", at: Date.now() });
  } catch { /* ignore */ }
  const pushed = rateOk(userId) ? await pushToUser(userId, { ...msg, tag: id }) : 0;
  return { id, pushed };
}

/* ------------------------------------------------------------------ */
/*  کارگر پس‌زمینه                                                     */
/* ------------------------------------------------------------------ */

let workerRunning = false;

async function claimAndSend(batch = 20): Promise<{ sent: number; rows: number }> {
  const since = await sinceMs();
  const claimed = await pool.query(
    `UPDATE notifications SET push_sent = 2 WHERE id IN (
       SELECT id FROM notifications
        WHERE push_sent = 0 AND created_at > $1
        ORDER BY created_at ASC LIMIT $2
     ) RETURNING id, user_id, title, body, link`,
    [since, batch]);
  const rows = claimed.rows as { id: string; user_id: string; title: string; body: string; link: string }[];
  if (!rows.length) return { sent: 0, rows: 0 };

  // یک پوش برای هر کاربر (اگر چند اعلان هم‌زمان دارد، خلاصه می‌شود)
  const byUser = new Map<string, typeof rows>();
  for (const r of rows) {
    const arr = byUser.get(r.user_id) || [];
    arr.push(r);
    byUser.set(r.user_id, arr);
  }
  let sent = 0;
  for (const [userId, list] of byUser) {
    const first = list[0];
    const msg: PushMsg = list.length > 1
      ? { title: first.title, body: `${first.body}\nو ${list.length - 1} اعلان دیگر…`, link: first.link, tag: "digest", kind: /دعوت|دعوت به|چالش|نبرد/.test(first.title) ? "invite" : "info" }
      : { title: first.title, body: first.body, link: first.link, tag: first.id, kind: /دعوت|چالش|نبرد/.test(first.title) ? "invite" : "info" };
    if (rateOk(userId)) sent += await pushToUser(userId, msg);
  }
  await pool.query(`UPDATE notifications SET push_sent = 1 WHERE id = ANY($1)`, [rows.map((r) => r.id)]);
  return { sent, rows: rows.length };
}

/** یادآور روزانهٔ پاداش (فقط برای کاربرانی که اشتراک پوش دارند و امروز جایزه نگرفته‌اند) */
async function dailyReminder(): Promise<number> {
  const enabled = await settingGet("push_daily_reminder", "on");
  if (enabled !== "on") return 0;
  // ساعت محلی تهران
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Tehran", hour: "2-digit", minute: "2-digit" }).format(new Date());
  const [hh, mm] = parts.split(":").map(Number);
  if (hh !== 19 || mm > 10) return 0;
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tehran" }).format(new Date());
  const last = await settingGet("push_daily_last", "");
  if (last === today) return 0;
  await settingSet("push_daily_last", today);
  try {
    const t0 = Date.now();
    const win = 1296000000; // ۱۵ روز اخیر
    const rows = await pool.query(
      `SELECT DISTINCT s.user_id FROM push_subs s
        JOIN users u ON u.id = s.user_id
       WHERE s.active = 1 AND u.banned = false AND (u.last_seen > $1 OR u.last_seen IS NULL)
         AND NOT EXISTS (SELECT 1 FROM daily_claims d WHERE d.user_id = s.user_id AND d.day = $2)
       LIMIT 4000`, [t0 - win, today]);
    let sent = 0;
    for (const r of rows.rows as { user_id: string }[]) {
      if (!rateOk(r.user_id)) continue;
      sent += await pushToUser(r.user_id, {
        title: "🎁 جایزهٔ امروزت آماده است",
        body: "وارد گیمیفای شو و جایزهٔ روزانه‌ات را بگیر؛ زنجیرهٔ روزهات را نشکن!",
        link: "#arena",
        tag: "daily-" + today,
      });
    }
    return sent;
  } catch { return 0; }
}

let lastDailyCheck = 0;

/** یک دور کار: فرستادن اعلان‌های تازهٔ ساخته‌شده توسط سایت */
export async function pushTick(batch = 20): Promise<{ sent: number; rows: number }> {
  if (workerRunning) return { sent: 0, rows: 0 };
  workerRunning = true;
  try {
    await ensurePushSchema();
    const r = await claimAndSend(batch);
    if (Date.now() - lastDailyCheck > 60000) {
      lastDailyCheck = Date.now();
      await dailyReminder().catch(() => 0);
    }
    return r;
  } finally {
    workerRunning = false;
  }
}

/** راه‌اندازی کارگر (یک‌بار در هر پردازه) */
export function startPushWorker(): void {
  const g = globalThis as typeof globalThis & { __gamifyPushWorker?: boolean };
  if (g.__gamifyPushWorker) return;
  g.__gamifyPushWorker = true;
  const loop = () => { pushTick().catch(() => { /* ignore */ }); };
  setTimeout(loop, 8000);
  setInterval(loop, WORKER_MS);
  if (typeof (setInterval(loop, WORKER_MS) as unknown as { unref?: () => void }).unref === "function") {
    /* در محیط سرور نگه‌داشتن interval لازم است؛ unref نمی‌کنیم */
  }
}

/**
 * 📣 اعلان سراسری/گروهی از پنل مدیریت
 * برای همهٔ کاربران هدف یک ردیف اعلان ساخته می‌شود (در صندوق اعلان‌شان می‌ماند)
 * و کارگر پس‌زمینه بلافاصله پوش را می‌فرستد.
 */
export async function queueBroadcast(
  msg: PushMsg,
  target = "all",
  limit = 3000,
): Promise<{ queued: number; pushed: number }> {
  await ensurePushSchema();
  const title = String(msg.title || "").slice(0, 200);
  const body = String(msg.body || "").slice(0, 600);
  const link = String(msg.link || "").slice(0, 80);
  if (!title) return { queued: 0, pushed: 0 };

  const params: unknown[] = [title, body, link, Date.now(), Math.max(1, Math.min(5000, limit))];
  let cond = "u.banned = false";
  if (target.startsWith("user:")) {
    params.push(target.slice(5));
    cond += ` AND u.id = $${params.length}`;
  } else if (target === "real") {
    cond += ` AND (coalesce(u.phone,'') <> '' OR coalesce(u.email,'') <> '' OR coalesce(u.provider,'guest') <> 'guest')`;
  } else if (target === "guest") {
    cond += ` AND coalesce(u.provider,'guest') = 'guest'`;
  } else if (target === "subs") {
    cond += ` AND EXISTS (SELECT 1 FROM push_subs s WHERE s.user_id = u.id AND s.active = 1)`;
  } else if (target === "online") {
    params.push(Date.now() - 300000);
    cond += ` AND u.last_seen > $${params.length}`;
  }

  let queued = 0;
  try {
    const r = await pool.query(
      `INSERT INTO notifications (id, user_id, title, body, link, created_at, seen, push_sent)
       SELECT 'n' || substr(md5(random()::text || u.id || clock_timestamp()::text), 1, 12), u.id, $1, $2, $3, $4, 0, 0
         FROM users u
        WHERE ${cond}
        LIMIT $5
       RETURNING user_id`, params);
    queued = r.rowCount ?? 0;
  } catch { /* ignore */ }

  try {
    if (target.startsWith("user:")) publish([target.slice(5)], "notify", { title, body, link, at: Date.now(), broadcast: true });
    else publish("*", "notify", { title, body, link, at: Date.now(), broadcast: true });
  } catch { /* ignore */ }

  // چند دور فوری؛ بقیه را کارگر در دورهای بعد می‌فرستد
  let pushed = 0;
  for (let i = 0; i < 3; i++) {
    const t = await pushTick(60).catch(() => ({ sent: 0, rows: 0 }));
    pushed += t.sent;
    if (t.rows === 0) break;
  }
  return { queued, pushed };
}

/** 📋 حلقهٔ کوچک خطاهای ارسال (برای عیب‌یابی در پنل مدیریت) */
const lastErrors: { at: number; status: number; error: string; host: string }[] = [];
export function pushErrors() {
  return lastErrors.slice(-10);
}
function rememberError(status: number, error: string, endpoint: string) {
  let host = "";
  try { host = new URL(endpoint).host; } catch { host = String(endpoint).slice(0, 40); }
  lastErrors.push({ at: Date.now(), status, error, host });
  if (lastErrors.length > 40) lastErrors.splice(0, lastErrors.length - 40);
}

/** آمار برای پنل مدیریت */
export async function pushStats(): Promise<Record<string, number>> {
  await ensurePushSchema();
  try {
    const r = await pool.query(`
      SELECT
        (SELECT count(*) FROM push_subs WHERE active = 1 AND kind = 'web')::int AS web_active,
        (SELECT count(*) FROM push_subs WHERE active = 1 AND kind = 'device')::int AS devices_active,
        (SELECT count(*) FROM push_subs WHERE active = 0)::int AS inactive,
        (SELECT count(*) FROM notifications WHERE push_sent = 0)::int AS queue`);
    const row = r.rows[0] || {};
    return {
      web_active: Number(row.web_active || 0),
      devices_active: Number(row.devices_active || 0),
      inactive: Number(row.inactive || 0),
      queue: Number(row.queue || 0),
      errors: pushErrors().length,
    };
  } catch { return { web_active: 0, devices_active: 0, inactive: 0, queue: 0 }; }
}

export { settingGet as pushSettingGet, settingSet as pushSettingSet };
