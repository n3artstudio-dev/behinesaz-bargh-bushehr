export const MODES = ['ranked','computer','friendly','practice','daily','event','league'] as const;
export type QuizMode = typeof MODES[number];
export function pointsFor(correct:boolean,elapsed:number,seconds:number,streak:number) {
  if(!correct)return 0;
  return 100+Math.max(0,Math.min(50,Math.round(50*(1-Math.max(0,elapsed)/(seconds*1000)))))+Math.min(30,Math.max(0,streak)*10);
}
export function choiceIsValid(choice:unknown):choice is number {
  return Number.isInteger(choice)&&Number(choice)>=-1&&Number(choice)<=3;
}
export function answeredInTime(now:number,startedAt:number,seconds:number){return now>=startedAt&&now<=startedAt+seconds*1000;}
export function dayInTehran(time:number){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit'}).format(time);}
