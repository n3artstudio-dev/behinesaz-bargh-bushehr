export type SessionProfile = { id: string; name: string; serverToken?: string; [key: string]: unknown };
type Fetcher = (input: string, init?: RequestInit) => Promise<Response>;

/** One server identity per browser session. A database outage never creates a fake profile. */
export function createSessionClient(fetcher: Fetcher, token: () => string = () => "") {
  let pending: Promise<SessionProfile> | null = null;
  let profile: SessionProfile | null = null;
  async function read(response: Response): Promise<SessionProfile> {
    if (!response.ok) throw new Error(`session-http-${response.status}`);
    const result = await response.json();
    if (!result || typeof result.id !== "string") throw new Error("invalid-session-response");
    return result;
  }
  return {
    reset() { profile = null; },
    ensure(): Promise<SessionProfile> {
      if (profile) return Promise.resolve(profile);
      if (pending) return pending;
      pending = (async () => {
        const headers: Record<string, string> = {};
        const existing = token();
        if (existing) headers["x-gamify-token"] = existing;
        const response = await fetcher("/api/me", { credentials: "include", cache: "no-store", headers });
        // Only absence of authentication creates a guest; 500/network failures propagate.
        const resolved = response.status === 401
          ? await fetcher("/api/auth/guest", { method: "POST", credentials: "include", headers })
          : response;
        profile = await read(resolved);
        return profile;
      })().finally(() => { pending = null; });
      return pending;
    },
  };
}
